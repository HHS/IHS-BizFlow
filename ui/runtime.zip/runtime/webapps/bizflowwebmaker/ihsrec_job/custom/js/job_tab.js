/*Job Announcement tab, HR Only tab*/
var JOB_TAB = {
    initialized: false,
    hideComponentsOnInit: ['otherNumberOfDaysInAdvertisement_layout_group','numberOfDaysInAd_layout_group',
        'cutOffDate_layout_group','otherRecruitment_layout_group',
        'conditionWait_layout_group', 'conditionWaitMonth_layout_group'],

    init: function () {
        if(!this.isAvailable()) return;

    },
    render: function () {
        try{
            // if(!this.isAvailable()) return;

            if(!this.initialized){
                this.populateData();
                $.each(this.hideComponentsOnInit, function(i, v){
                    hyf.util.hideComponent(v);
                });
            }

            if(!this.initialized || FormState.isDirty('numberOfDaysInAdvertisement')){
                var numberOfDaysInAdvertisement = FormState.getState('numberOfDaysInAdvertisement');
                if (numberOfDaysInAdvertisement && numberOfDaysInAdvertisement.value.toUpperCase() === 'OTHER') {
                    hyf.util.showComponent('otherNumberOfDaysInAdvertisement_layout_group');
                    hyf.util.setMandatoryConstraint('otherNumberOfDaysInAdvertisement', true);
                    $('#otherNumberOfDaysInAdvertisement').focus();
                } else {
                    FormState.doActionNoRender(StateAction.reset('otherNumberOfDaysInAdvertisement'));
                    hyf.util.hideComponent('otherNumberOfDaysInAdvertisement_layout_group');
                    hyf.util.setMandatoryConstraint('otherNumberOfDaysInAdvertisement', false);
                }
            }

            if(!this.initialized || FormState.isDirty('announcementCloseMode')){
                var announcementCloseMode = FormState.getState('announcementCloseMode');
                if(announcementCloseMode){
                    if(announcementCloseMode.value.toUpperCase() === 'OPEN CONTINUOUS' ||
                        announcementCloseMode.value.toUpperCase() === 'OPEN UNTIL FILLED' ){
                        hyf.util.showComponent('cutOffDate_layout_group');
                    }else{
                        FormState.doActionNoRender(StateAction.reset('cutOffDate'));
                        hyf.util.hideComponent('cutOffDate_layout_group');
                    }

                    if(announcementCloseMode.value.toUpperCase() === 'TIME LIMITED'){
                        hyf.util.showComponent('numberOfDaysInAd_layout_group');
                    }else{
                        hyf.util.hideComponent('numberOfDaysInAd_layout_group');
                    }
                }else{
                    hyf.util.hideComponent('cutOffDate_layout_group');
                    hyf.util.hideComponent('numberOfDaysInAd_layout_group');
                }
            }

            // if(FormState.isDirty('additionalRecruitment')){
            //     var additionalRecruitment = FormState.getState('additionalRecruitment');
            //     if(additionalRecruitment){
            //         if(1<additionalRecruitment.value.split(',').length
            //            || -1<_.indexOf(['ADVERTISING ON/AT','SCHOOL/UNIVERSITY POSTING', 'SOCIAL MEDIA', 'NATIVE AMERICAN/ALASKAN NATIVE GROUPS', 'OTHER'], additionalRecruitment.value.toUpperCase())){
            //             hyf.util.showComponent('otherRecruitment_layout_group');
            //         }else{
            //             FormState.doActionNoRender(StateAction.reset('otherRecruitment'));
            //             hyf.util.hideComponent('otherRecruitment_layout_group');
            //         }
            //     }
            // }

            if(FormState.isDirty('additionalRecruitment_input')){
                var additionalRecruitment_input = FormState.getState('additionalRecruitment_input');
                if ('' != additionalRecruitment_input.value) {
                    var additionalRecruitment = FormState.getState('additionalRecruitment');
                    regenerateSelectedValues('additionalRecruitment',additionalRecruitment?additionalRecruitment.value:undefined);
                }
            }

            if(FormState.isDirty('additionalRecruitment')){
                selectedValues = FormState.getState('additionalRecruitment');
                if('' != selectedValues.value
                    && (1<selectedValues.value.split(',').length
                        || -1<_.indexOf(['ADVERTISING ON/AT','SCHOOL/UNIVERSITY POSTING', 'SOCIAL MEDIA', 'NATIVE AMERICAN/ALASKAN NATIVE GROUPS', 'OTHER'], selectedValues.value.toUpperCase()))){
                    hyf.util.showComponent('otherRecruitment_layout_group');
                }else{
                    FormState.doActionNoRender(StateAction.reset('otherRecruitment'));
                    hyf.util.hideComponent('otherRecruitment_layout_group');
                }
            }

            if(!this.initialized || FormState.isDirty('completedJobAnalysisDated072017')){
                var completedJobAnalysisDated072017 = FormState.getState('completedJobAnalysisDated072017');
                if(typeof completedJobAnalysisDated072017 === 'undefined'){
                    FormState.doActionNoRender(StateAction.changeCheckbox('completedJobAnalysisDated072017', true));
                    completedJobAnalysisDated072017 = FormState.getState('completedJobAnalysisDated072017');
                }

                if(completedJobAnalysisDated072017 && isTrue(completedJobAnalysisDated072017.value)){
                    FormState.doActionNoRender(StateAction.reset('specializedExperience'));
                    hyf.util.hideComponent('specialized_experience_layout_group');
                }else{
                    hyf.util.showComponent('specialized_experience_layout_group');
                }
            }

            if(!this.initialized || FormState.isDirty('conditionRequireLicensure')){
                var conditionRequireLicensure = FormState.getState('conditionRequireLicensure');
                if(conditionRequireLicensure && isTrue(conditionRequireLicensure.value)){
                    hyf.util.showComponent('conditionWait_layout_group');
                }else{
                    FormState.doActionNoRender(StateAction.reset('conditionWait', ETYPE.CHECKBOX));
                    hyf.util.hideComponent('conditionWait_layout_group');
                }
            }

            if(!this.initialized || FormState.isDirty('conditionWait')){
                var conditionWait = FormState.getState('conditionWait');
                if(conditionWait && isTrue(conditionWait.value)){
                    hyf.util.showComponent('conditionWaitMonth_layout_group');
                }else{
                    FormState.doActionNoRender(StateAction.reset('conditionWaitMonth', ETYPE.SELECT));
                    hyf.util.hideComponent('conditionWaitMonth_layout_group');
                }
            }

            if(FormState.isDirty('recruitmentEnticements_input')){
                var recruitmentEnticements = FormState.getState('recruitmentEnticements_input');
                if ('' != recruitmentEnticements.value) {
                    var selectedValues = FormState.getState('recruitmentEnticements');
                    regenerateSelectedValues('recruitmentEnticements',selectedValues?selectedValues.value:undefined);
                }
            }

            if(FormState.isDirty('otherNumberOfDaysInAdvertisement')){
                var otherNumberOfDaysInAdvertisement = FormState.getState('otherNumberOfDaysInAdvertisement');
                if ('' != otherNumberOfDaysInAdvertisement.value) {
                    if(0 === _.toSafeInteger(otherNumberOfDaysInAdvertisement.value)){
                        bootbox.alert({message:'Please enter only numbers and greater than 0 in the Number of Days in Advertisement field.',
                            callback: function(){
                                setTimeout(function() {
                                    $('#otherNumberOfDaysInAdvertisement').focus();
                                }, 1);
                            }});
                    }
                }
            }
        }catch(e){
            //skip for debug
        }

        this.initialized = true;
    },
    isAvailable: function() {
        return IHS_REQUEST_MAIN.isStrategicConsultationActivity();
    },
    populateData: function(){
        var numberOfVacancies= FormState.getState('numberOfVacancies');
        if(numberOfVacancies){
            $('#numberOfVacancies_output').html(numberOfVacancies.value);
        }

        this.populateAdvertiseGradesAndTargetGrades();

        var recruitmentEnticements = FormState.getState('recruitmentEnticements');
        if (recruitmentEnticements && 0<recruitmentEnticements.value.length) {
            var selectedValues = FormState.getState('recruitmentEnticements');
            regenerateSelectedValues('recruitmentEnticements',selectedValues?selectedValues.value:undefined);
        }

        var additionalRecruitment = FormState.getState('additionalRecruitment');
        if (additionalRecruitment && 0<additionalRecruitment.value.length) {
            var selectedValues = FormState.getState('additionalRecruitment');
            regenerateSelectedValues('additionalRecruitment',selectedValues?selectedValues.value:undefined);
        }
    },
    populateAdvertiseGradesAndTargetGrades: function(){
        var selectedGrade = FormState.getState('selectGrades');
        if(typeof selectedGrade === 'undefined' || 0===selectedGrade.value.length){
            $('#advertiseGradeCheckbox_container').html('');
            $('#targetGrade_container').html('');
            return;
        }

        var data = [];
        var grades = selectedGrade.value.split(',');
        $.each(grades, function(i, v){
            var p = v.indexOf(':');
            data.push((0 < p)?v.substr(0, p):v);
        });
        var view = {items:[]};
        data = data.sort();
        $.each(data, function(i, v){
            view.items.push({index: i+1, value: v, label: v});
        });

        var template = $('#advertiseGradeCheckboxTmpl').val();
        Mustache.parse(template, ['[[',']]']);
        var rendered = Mustache.render(template, view);
        $('#advertiseGradeCheckbox_container').html(rendered);
        if(data.length === 1)
        {
            $('#advertiseGradeCheckbox1').prop('checked', 'checked');
            FormState.doActionNoRender(StateAction.changeText('advertiseGrade', data[0]));
        }

        var savedAdvertiseGrade = FormState.getState('advertiseGrade');
        if(savedAdvertiseGrade && 0<savedAdvertiseGrade.value.length){
            var arrayOfSavedAdvertiseGrade = savedAdvertiseGrade.value.split(',');
            $.each(arrayOfSavedAdvertiseGrade, function(i,v){
                if(0<v.length){
                    $('input[name=advertiseGradeCheckbox][value='+v+']').prop('checked', true);
                }
            });
        }

        template = $('#targetGradeTmpl').val();
        Mustache.parse(template, ['[[',']]']);
        rendered = Mustache.render(template, view);
        $('#targetGrade_container').html(rendered);

        $('input[name=advertiseGradeCheckbox]').on('click', function (e) {
            var checkedValues = [];
            $.each($('input[name=advertiseGradeCheckbox]:checked'), function(i,v){
                checkedValues.push(v.value);
            });
            FormState.doAction(StateAction.changeText("advertiseGrade", checkedValues.join()));
        });

        $('input[name=targetGrade]').on('click', function (e) {
            FormState.doAction(StateAction.changeRadio(e.target.name, e.target.value));
        });

        var targetGrade = FormState.getState('targetGrade');
        if(targetGrade && 0<targetGrade.value.length){
            var arrayOfTargetGrade = targetGrade.value.split(',');
            $.each(arrayOfTargetGrade, function(i,v){
                if(0<v.length){
                    $('input[name=targetGrade][value='+v+']').prop('checked', 'checked');
                }
            });
        }else{
            // default: checked a highest grade
            var highestGrade = data[data.length-1];
            $('input[name=targetGrade][value=' + highestGrade +']').prop('checked', 'checked');
            FormState.doActionNoRender(StateAction.changeRadio('targetGrade', highestGrade));
        }
    },
};
/**
 * HR Only Tab
 */
var HRONLY_TAB = {
    initialized: false,
    hideComponentsOnInit: ['payTableNumber_layout_group'],
    init: function () {
        if(!this.isAvailable()) return;
    },
    render: function () {
        try{
            // if(!this.isAvailable()) return;

            if(!this.initialized){
                $.each(this.hideComponentsOnInit, function(i, v){
                    hyf.util.hideComponent(v);
                });
            }

            if(!this.initialized || FormState.isDirty('specialSalaryRate')){
                var specialSalaryRate = FormState.getState('specialSalaryRate');
                if (specialSalaryRate && specialSalaryRate.value.toUpperCase() === 'Y') {
                    hyf.util.showComponent('payTableNumber_layout_group');
                } else {
                    FormState.doActionNoRender(StateAction.reset('payTableNumber'));
                    hyf.util.hideComponent('payTableNumber_layout_group');
                }
            }
        }catch(e){
            //skip for debug
        }

        this.initialized = true;
    },
    isAvailable: function() {
        return IHS_REQUEST_MAIN.isStrategicConsultationActivity();
    }
};
/**
 * Approvals Tab
 */
var APPROVALS_TAB = {
    initialized: false,
    init: function () {
        if(!this.isAvailable()) return;
    },
    render: function () {
        try{
            // if(!this.isAvailable()) return;

            if(!this.initialized){
                if(IHS_REQUEST_MAIN.isStrategicConsultationActivity())
                {
                    if(!IHS_REQUEST_MAIN.isHiringManager()){
                        hyf.util.hideComponent('concurHiringManager_layout_group');
                    }
                    if(!IHS_REQUEST_MAIN.isHRSpecialist()){
                        hyf.util.hideComponent('approvals_hr_specialist_layout_group');
                    }
                }

                hyf.util.enableComponent('button_exchange_hr');
                hyf.util.enableComponent('button_returnToClassification');

                var concurHiringManager = FormState.getState('concurHiringManager');
                if(concurHiringManager && isTrue(concurHiringManager.value)){
                    hyf.util.disableComponent('button_exchange_hr');
                    hyf.util.disableComponent('button_returnToClassification');
                    var sign = FormState.getState('concurHiringManagerSignature');
                    var date = FormState.getState('concurrenceDateHiringManager');
                    $('#output_concurHiringManagerSignature').html(sign.value);
                    $('#output_concurrenceDateHiringManager').html(date.value);
                }

                var approveHRSpecialist = FormState.getState('approveHRSpecialist');
                if(approveHRSpecialist && isTrue(approveHRSpecialist.value)){
                    hyf.util.hideComponent('button_submitToHR');
                    hyf.util.disableComponent('button_exchange_mgr');
                    hyf.util.disableComponent('button_returnToClassification');
                    var sign = FormState.getState('approveHRSpecialistSignature');
                    var date = FormState.getState('concurrenceDateHRSpecialist');
                    $('#output_approveHRSpecialistSignature').html(sign.value);
                    $('#output_concurrenceDateHRSpecialist').html(date.value);
                }

            } else {
                if(FormState.isDirty('concurHiringManager')){
                    var concurHiringManager = FormState.getState('concurHiringManager');
                    if(concurHiringManager){
                        if(isTrue(concurHiringManager.value)){
                            $('#concurHiringManager').prop('disabled', true);
                            setTimeout(function(){$('#concurHiringManager').prop('disabled', false);}, 2345);
                            hyf.util.disableComponent('button_exchange_hr');
                            hyf.util.disableComponent('button_returnToClassification');
                            var name = $('#h_currentUserName').val();
                            var today = APPROVALS_TAB.today();
                            APPROVALS_TAB.signing('output_concurHiringManagerSignature', name);
                            setTimeout(function(){APPROVALS_TAB.signing('output_concurrenceDateHiringManager', today);},1000);
                            FormState.doActionNoRender(StateAction.changeText('concurHiringManagerSignature', name));
                            FormState.doActionNoRender(StateAction.changeText('concurrenceDateHiringManager', today));
                        }else{
                            hyf.util.enableComponent('button_exchange_hr');
                            hyf.util.enableComponent('button_returnToClassification');
                            $('#output_concurHiringManagerSignature').html('');
                            $('#output_concurrenceDateHiringManager').html('');
                            FormState.doActionNoRender(StateAction.reset('concurHiringManagerSignature'));
                            FormState.doActionNoRender(StateAction.reset('concurrenceDateHiringManager'));
                        }
                    }
                }

                if(FormState.isDirty('approveHRSpecialist')){
                    var approveHRSpecialist = FormState.getState('approveHRSpecialist');
                    if(approveHRSpecialist){
                        if(isTrue(approveHRSpecialist.value)){
                            $('#approveHRSpecialist').prop('disabled', true);
                            setTimeout(function(){$('#approveHRSpecialist').prop('disabled', false);}, 2345);
                            hyf.util.hideComponent('button_submitToHR');
                            hyf.util.disableComponent('button_exchange_mgr');
                            hyf.util.disableComponent('button_returnToClassification');
                            var name = $('#h_currentUserName').val();
                            var today = APPROVALS_TAB.today();
                            APPROVALS_TAB.signing('output_approveHRSpecialistSignature', name);
                            setTimeout(function(){APPROVALS_TAB.signing('output_concurrenceDateHRSpecialist', today);}, 1000);
                            FormState.doActionNoRender(StateAction.changeText('approveHRSpecialistSignature', name));
                            FormState.doActionNoRender(StateAction.changeText('concurrenceDateHRSpecialist', today));
                        }else{
                            hyf.util.showComponent('button_submitToHR');
                            hyf.util.enableComponent('button_exchange_mgr');
                            hyf.util.enableComponent('button_returnToClassification');
                            $('#output_approveHRSpecialistSignature').html('');
                            $('#output_concurrenceDateHRSpecialist').html('');
                            FormState.doActionNoRender(StateAction.reset('approveHRSpecialistSignature'));
                            FormState.doActionNoRender(StateAction.reset('concurrenceDateHRSpecialist'));
                        }
                    }
                }

                if(FormState.isDirty('concurHiringManager') || FormState.isDirty('approveHRSpecialist')) {
                    hyf.util.enableComponent('button_exchange_hr');
                    hyf.util.enableComponent('button_returnToClassification');
                    var concurHiringManager = FormState.getState('concurHiringManager');
                    var approveHRSpecialist = FormState.getState('approveHRSpecialist');
                    if (concurHiringManager || approveHRSpecialist) {
                        if(isTrue(concurHiringManager.value) || isTrue(approveHRSpecialist.value)){
                            hyf.util.disableComponent('button_exchange_hr');
                            hyf.util.disableComponent('button_returnToClassification');
                        }
                    }
                }
            }

        }catch(e){
            //skip for debug
        }

        this.initialized = true;
    },
    isDirtyField: function(field) {
        var f = FormState.getState(field);
        return (f && f.dirty);
    },
    isAvailable: function() {
        return IHS_REQUEST_MAIN.isStrategicConsultationActivity();
    },
    signing: function(target, message, index){
        index = index ? index:0;
        if(index === 0){
            $('#'+target).html('');
        }
        if (index < message.length) {
            $('#'+target).append(message[index++]);
            setTimeout(function () { APPROVALS_TAB.signing(target, message, index); }, Math.random()*100);
        }
    },
    today: function(){
        var now = new Date();
        return (now.getMonth()+1) + '/' + now.getDate() + '/' + now.getFullYear();
    }
};
/**
 * Close-out Tab
 */
var CLOSEOUT_TAB = {
    initialized: false,
    init: function () {
    },
    render: function () {
        if(!this.initialized){
            $('#button_SendToArchive').off('click').click(function (e) {
                completeWorkitem('Submit', true);
            });
            this.initialized = true;
        }
    }
};
function removeSelectedItem(e){
    var $this = $(e);
    var fieldName = $this.attr('_fieldName');
    var index = $this.attr('_index');
    var deleteValue = $('#' + fieldName + index + '_value').text();

    var $f = $('#'+fieldName);
    var selectedValues = $f.val();
    var data = selectedValues.split(',');
    _.remove(data, function(s){
        return deleteValue === s;
    });

    var dataStr = data.join();
    $f.val(dataStr);

    $('#' + fieldName + index + '_item').remove();
    if(data.length === 0){
        $('#' + fieldName + '_selected_value_place_holder').hide();
    }

    //FormState.doActionNoRender(StateAction.changeText(fieldName, dataStr));
    FormState.doAction(StateAction.changeText(fieldName, dataStr));
}

function regenerateSelectedValues(fieldName, selectedValues, templateId){
    var inputField = FormState.getState(fieldName+'_input');
    var data = [];
    if(selectedValues && 0<selectedValues.length){
        data = selectedValues.split(',');
    }
    if(inputField && 0<inputField.value.length){
        data.push(inputField.value);
    }
    data = unique(data);
    data = data.sort();
    var view = {items:[]};
    $.each(data, function(i, v){
        view.items.push({fieldName: fieldName, index: i+1, label: v});
    });

    var $inputField = $('#' + fieldName + '_input');
    var $placeHolder = $('#' + fieldName + '_selected_value_place_holder');
    if(0<data.length){
        $placeHolder.removeClass('hide');
        $placeHolder.show();
        templateId = (templateId)?templateId:'simpleItemsTmpl';
        var template = $('#'+templateId).val();
        Mustache.parse(template, ['[[',']]']);
        var rendered = Mustache.render(template, view);
        $(".selectedValueContainer", $placeHolder).html(rendered);

        var dataStr = data.join(',');
        var $fieldName = $('#'+fieldName);
        $fieldName.val(dataStr);
        FormState.doActionNoRender(StateAction.changeText(fieldName, dataStr));
        FormState.doActionNoRender(StateAction.reset(fieldName+'_input'));

        // check Mandatory
        if($inputField.attr('_required') === 'true'){
            $inputField.removeAttr('_required');
            $inputField.attr('_required_org', 'true');
        }
    }else{
        $placeHolder.hide();
        $(".selectedValueContainer", $placeHolder).html('');

        // check Mandatory
        if($inputField.attr('_required_org') === 'true'){
            $inputField.attr('_required', 'true');
        }
    }
}