/*Job Announcement tab, HR Only tab*/
var JOB_TAB = {
    initialized: false,
    hideComponentsOnInit: ['otherNumberOfDaysInAdvertisement_layout_group','numberOfDaysInAd_layout_group',
                            'cutOffDate_layout_group','otherRecruitment_layout_group',
                            'conditionWait_layout_group', 'conditionWaitMonth_layout_group'],

    init: function () {
        if(!this.isAvailable()) return;

    },
    render: function () {
        try{
            if(!this.isAvailable()) return;

            if(!this.initialized){
                this.populateData();
                $.each(this.hideComponentsOnInit, function(i, v){
                    hyf.util.hideComponent(v);
                });
            }

            if(FormState.isDirty('workSchedule') || FormState.isDirty('numberOfHoursWorkedPerWeek')){
                var workSchedule = FormState.getState('workSchedule');
                var numberOfHoursWorkedPerWeek = FormState.getState('numberOfHoursWorkedPerWeek');
                var dirtyFieldId = FormState.isDirty('workSchedule') ? 'workSchedule' : 'numberOfHoursWorkedPerWeek';
                if(0<workSchedule.value.length && numberOfHoursWorkedPerWeek && 0<numberOfHoursWorkedPerWeek.value.length){
                    if(workSchedule.value.toUpperCase() === 'FULL TIME'){
                        if(numberOfHoursWorkedPerWeek && _.toSafeInteger(numberOfHoursWorkedPerWeek.value) < 33){
                            FormState.doActionNoRender(StateAction.reset(dirtyFieldId, ETYPE.SELECT));
                            bootbox.alert({message:'Please select the correct number of hours worked per week.',
                                callback: function(){
                                    setTimeout(function() {$('#'+dirtyFieldId).focus();}, 1);
                                }});
                        }
                    } else {
                        if(numberOfHoursWorkedPerWeek && _.toSafeInteger(numberOfHoursWorkedPerWeek.value) >= 33){
                            FormState.doActionNoRender(StateAction.reset(dirtyFieldId, ETYPE.SELECT));
                            bootbox.alert({message:'Please select the correct number of hours worked per week.',
                                callback: function(){
                                    setTimeout(function() {$('#'+dirtyFieldId).focus();}, 1);
                                }});
                        }
					}
                } else if(workSchedule.value.toUpperCase() !== 'FULL TIME'){
                    if(numberOfHoursWorkedPerWeek && _.toSafeInteger(numberOfHoursWorkedPerWeek.value) >= 33){
                        FormState.doActionNoRender(StateAction.reset(dirtyFieldId, ETYPE.SELECT));
                        bootbox.alert({message:'Please select the correct number of hours worked per week.',
                            callback: function(){
                                setTimeout(function() {$('#'+dirtyFieldId).focus();}, 1);
                            }});
                    }
                }
            }

            if(!this.initialized || FormState.isDirty('numberOfDaysInAdvertisement')){
                var numberOfDaysInAdvertisement = FormState.getState('numberOfDaysInAdvertisement');
                if (numberOfDaysInAdvertisement && numberOfDaysInAdvertisement.value.toUpperCase() === 'OTHER') {
                    hyf.util.showComponent('otherNumberOfDaysInAdvertisement_layout_group');
                    hyf.util.setMandatoryConstraint('otherNumberOfDaysInAdvertisement', true);
                    $('#otherNumberOfDaysInAdvertisement').focus();
                } else {
                    FormState.doActionNoRender(StateAction.reset('otherNumberOfDaysInAdvertisement'));
                    hyf.util.hideComponent('otherNumberOfDaysInAdvertisement_layout_group');
                    hyf.util.setMandatoryConstraint('otherNumberOfDaysInAdvertisement', false);
                }
            }

            if(!this.initialized || FormState.isDirty('announcementCloseMode')){
                var announcementCloseMode = FormState.getState('announcementCloseMode');
                if(announcementCloseMode){
                    if(announcementCloseMode.value.toUpperCase() === 'OPEN CONTINUOUS' ||
                        announcementCloseMode.value.toUpperCase() === 'OPEN UNTIL FILLED' ){
                        hyf.util.showComponent('cutOffDate_layout_group');
                    }else{
                        FormState.doActionNoRender(StateAction.reset('cutOffDate', ETYPE.DATE));
                        hyf.util.hideComponent('cutOffDate_layout_group');
                    }

                    if(announcementCloseMode.value.toUpperCase() === 'TIME LIMITED'){
                        hyf.util.showComponent('numberOfDaysInAd_layout_group');
                    }else{
                        hyf.util.hideComponent('numberOfDaysInAd_layout_group');
                    }
                }else{
                    hyf.util.hideComponent('cutOffDate_layout_group');
                    hyf.util.hideComponent('numberOfDaysInAd_layout_group');
                }
            }

            if(!this.initialized || FormState.isDirty('additionalRecruitment')){
                var additionalRecruitment = FormState.getState('additionalRecruitment');
                if(additionalRecruitment){
                    if(-1<_.indexOf(['ADVERTISING ON/AT','SCHOOL/UNIVERSITY POSTING', 'SOCIAL MEDIA', 'OTHER'], additionalRecruitment.value.toUpperCase())){
                        hyf.util.showComponent('otherRecruitment_layout_group');
                    }else{
                        FormState.doActionNoRender(StateAction.reset('otherRecruitment'));
                        hyf.util.hideComponent('otherRecruitment_layout_group');
                    }
                }
            }

            if(!this.initialized || FormState.isDirty('completedJobAnalysisDated072017')){
                var completedJobAnalysisDated072017 = FormState.getState('completedJobAnalysisDated072017');
                if(completedJobAnalysisDated072017 && isTrue(completedJobAnalysisDated072017.value)){
                    FormState.doActionNoRender(StateAction.reset('specializedExperience'));
                    hyf.util.hideComponent('specialized_experience_layout_group');
                }else{
                    hyf.util.showComponent('specialized_experience_layout_group');
                }
            }

            if(!this.initialized || FormState.isDirty('conditionRequireLicensure')){
                var conditionRequireLicensure = FormState.getState('conditionRequireLicensure');
                if(conditionRequireLicensure && isTrue(conditionRequireLicensure.value)){
                    hyf.util.showComponent('conditionWait_layout_group');
                }else{
                    FormState.doActionNoRender(StateAction.reset('conditionWait', ETYPE.CHECKBOX));
                    hyf.util.hideComponent('conditionWait_layout_group');
                }
            }

            if(!this.initialized || FormState.isDirty('conditionWait')){
                var conditionWait = FormState.getState('conditionWait');
                if(conditionWait && isTrue(conditionWait.value)){
                    hyf.util.showComponent('conditionWaitMonth_layout_group');
                }else{
                    FormState.doActionNoRender(StateAction.reset('conditionWaitMonth', ETYPE.SELECT));
                    hyf.util.hideComponent('conditionWaitMonth_layout_group');
                }
            }

            if(FormState.isDirty('recruitmentEnticements_input')){
                var recruitmentEnticements = FormState.getState('recruitmentEnticements_input');
                if ('' != recruitmentEnticements.value) {
                    var selectedValues = FormState.getState('recruitmentEnticements');
                    regenerateSelectedValues('recruitmentEnticements',selectedValues?selectedValues.value:undefined);
                }
            }

            if(FormState.isDirty('otherNumberOfDaysInAdvertisement')){
                var otherNumberOfDaysInAdvertisement = FormState.getState('otherNumberOfDaysInAdvertisement');
                if ('' != otherNumberOfDaysInAdvertisement.value) {
                    if(0 === _.toSafeInteger(otherNumberOfDaysInAdvertisement.value)){
                        bootbox.alert({message:'Please enter only numbers and greater than 0 in the Number of Days in Advertisement field.',
                            callback: function(){
                                setTimeout(function() {
                                    $('#otherNumberOfDaysInAdvertisement').focus();
                                }, 1);
                            }});
                    }
                }
            }
        }catch(e){
            //skip for debug
        }

        this.initialized = true;
    },
    isAvailable: function() {
        return IHS_REQUEST_MAIN.isStrategicConsultationActivity();
    },
    populateData: function(){
        var numberOfVacancies= FormState.getState('numberOfVacancies');
        if(numberOfVacancies){
            $('#numberOfVacancies_output').html(numberOfVacancies.value);
        }
        this.populateNumberOfHoursWorkedPerWeek(40);
        this.populateAdvertiseGradesAndTargetGrades();

        var recruitmentEnticements = FormState.getState('recruitmentEnticements');
        if (recruitmentEnticements && 0<recruitmentEnticements.value.length) {
            var selectedValues = FormState.getState('recruitmentEnticements');
            regenerateSelectedValues('recruitmentEnticements',selectedValues?selectedValues.value:undefined);
        }

    },
    populateAdvertiseGradesAndTargetGrades: function(){
        var selectedGrade = FormState.getState('selectGrades');
        var data = [];
        var grades = selectedGrade.value.split(',');
        $.each(grades, function(i, v){
            var p = v.indexOf(':');
            data.push((0 < p)?v.substr(0, p):v);
        });
        var view = {items:[]};
        data = data.sort();
        $.each(data, function(i, v){
            view.items.push({index: i+1, value: v, label: v});
        });

        var template = $('#advertiseGradeTmpl').val();
        Mustache.parse(template, ['[[',']]']);
        var rendered = Mustache.render(template, view);
        $('#advertiseGrade_container').html(rendered);
        if(data.length === 1)
        {
            $('#advertiseGrade1').prop('checked', 'checked');
        }

        template = $('#targetGradeTmpl').val();
        Mustache.parse(template, ['[[',']]']);
        rendered = Mustache.render(template, view);
        $('#targetGrade_container').html(rendered);
        // default: checked a highest grade
        $('input[name=targetGrade][value=' + data[data.length-1]+']').prop('checked', 'checked');

        $('input[name=advertiseGrade]').on('click', function (e) {
            var checked = $('#' + e.target.id).prop('checked');
            FormState.doAction(StateAction.changeCheckbox(e.target.id, checked));
        });
        $('input[name=targetGrade]').on('click', function (e) {
            FormState.doAction(StateAction.changeRadio(e.target.name, e.target.value));
        });
    },
    populateNumberOfHoursWorkedPerWeek: function(defaultValue){
        var items = [];
        for(var i=1; i<=40; i++){
            items.push({value: i, text: i});
        }
        populateSelectOptions('numberOfHoursWorkedPerWeek', items, defaultValue, SelectOptionConfig_SelectOne);
    }
};
/**
 * HR Only Tab
 */
var HRONLY_TAB = {
    initialized: false,
    hideComponentsOnInit: ['payTableNumber_layout_group'],
    init: function () {
        if(!this.isAvailable()) return;
    },
    render: function () {
        try{
            if(!this.isAvailable()) return;

            if(!this.initialized){
                $.each(this.hideComponentsOnInit, function(i, v){
                    hyf.util.hideComponent(v);
                });

                hyf.calendar.setDateConstraint('priorityPlacementProgramStartDate', 'Minimum', 'LastYear');
                hyf.calendar.setDateConstraint('priorityPlacementProgramStartDate', 'Maximum', 'NextYear');
                hyf.calendar.setDateConstraint('priorityPlacementProgramEndDate', 'Minimum', 'LastYear');
                hyf.calendar.setDateConstraint('priorityPlacementProgramEndDate', 'Maximum', 'NextYear');
            }

            if(!this.initialized || FormState.isDirty('specialSalaryRate')){
                var specialSalaryRate = FormState.getState('specialSalaryRate');
                if (specialSalaryRate && specialSalaryRate.value.toUpperCase() === 'Y') {
                    hyf.util.showComponent('payTableNumber_layout_group');
                } else {
                    FormState.doActionNoRender(StateAction.reset('payTableNumber'));
                    hyf.util.hideComponent('payTableNumber_layout_group');
                }
            }

            if(!this.initialized || FormState.isDirty('priorityPlacementProgramStartDate')){
                var priorityPlacementProgramStartDate = FormState.getState('priorityPlacementProgramStartDate');
                if (priorityPlacementProgramStartDate && 0<priorityPlacementProgramStartDate.value.length) {
                    hyf.calendar.setDateConstraint('priorityPlacementProgramEndDate', 'Minimum', priorityPlacementProgramStartDate);
                    try{
                        var maxDate = new Date(priorityPlacementProgramStartDate.value);
                        maxDate.setFullYear(maxDate.getFullYear()+1);
                        var maxDateStr = (maxDate.getMonth()+1) + '/' + (maxDate.getDate()) + '/' + maxDate.getFullYear();
                        hyf.calendar.setDateConstraint('priorityPlacementProgramEndDate', 'Maximum', maxDateStr);
                    }catch(e){}
                } else {
                    hyf.calendar.setDateConstraint('priorityPlacementProgramEndDate', 'Minimum', 'LastYear');
                    hyf.calendar.setDateConstraint('priorityPlacementProgramEndDate', 'Maximum', 'NextYear');
                }
            }

        }catch(e){
            //skip for debug
        }

        this.initialized = true;
    },
    isAvailable: function() {
        return IHS_REQUEST_MAIN.isStrategicConsultationActivity();
    }
};
/**
 * Approvals Tab
 */
var APPROVALS_TAB = {
    initialized: false,
    init: function () {
        if(!this.isAvailable()) return;
    },
    render: function () {
        try{
            if(!this.isAvailable()) return;

            if(!this.initialized){
                if(IHS_REQUEST_MAIN.isHiringManager()){
                    hyf.util.hideComponent('approvals_hr_specialist_layout_group');
                }else {
                    hyf.util.hideComponent('concurHiringManager_layout_group');
                }

                var concurHiringManager = FormState.getState('concurHiringManager');
                if(concurHiringManager && isTrue(concurHiringManager.value)){
                    hyf.util.disableComponent('button_exchange_hr');
                    hyf.util.disableComponent('button_returnToClassification');
                    var sign = FormState.getState('concurHiringManagerSignature');
                    var date = FormState.getState('concurrenceDateHiringManager');
                    $('#output_concurHiringManagerSignature').html(sign.value);
                    $('#output_concurrenceDateHiringManager').html(date.value);
                }

                var approveHRSpecialist = FormState.getState('approveHRSpecialist');
                if(approveHRSpecialist && isTrue(approveHRSpecialist.value)){
                    hyf.util.disableComponent('button_exchange_mgr');
                    hyf.util.disableComponent('button_returnToClassification');
                    var sign = FormState.getState('approveHRSpecialistSignature');
                    var date = FormState.getState('concurrenceDateHRSpecialist');
                    $('#output_approveHRSpecialistSignature').html(sign.value);
                    $('#output_concurrenceDateHRSpecialist').html(date.value);
                }

            } else {
                if(FormState.isDirty('concurHiringManager')){
                    var concurHiringManager = FormState.getState('concurHiringManager');
                    if(concurHiringManager){
                        if(isTrue(concurHiringManager.value)){
                            $('#concurHiringManager').prop('disabled', true);
                            setTimeout(function(){$('#concurHiringManager').prop('disabled', false);}, 2345);
                            hyf.util.disableComponent('button_exchange_hr');
                            hyf.util.disableComponent('button_returnToClassification');
                            var name = $('#h_currentUserName').val();
                            var today = APPROVALS_TAB.today();
                            APPROVALS_TAB.signing('output_concurHiringManagerSignature', name);
                            setTimeout(function(){APPROVALS_TAB.signing('output_concurrenceDateHiringManager', today);},1000);
                            FormState.doActionNoRender(StateAction.changeText('concurHiringManagerSignature', name));
                            FormState.doActionNoRender(StateAction.changeText('concurrenceDateHiringManager', today));
                        }else{
                            hyf.util.enableComponent('button_exchange_hr');
                            hyf.util.enableComponent('button_returnToClassification');
                            $('#output_concurHiringManagerSignature').html('');
                            $('#output_concurrenceDateHiringManager').html('');
                            FormState.doActionNoRender(StateAction.reset('concurHiringManagerSignature'));
                            FormState.doActionNoRender(StateAction.reset('concurrenceDateHiringManager'));
                        }
                    }
                }

                if(FormState.isDirty('approveHRSpecialist')){
                    var approveHRSpecialist = FormState.getState('approveHRSpecialist');
                    if(approveHRSpecialist){
                        if(isTrue(approveHRSpecialist.value)){
                            $('#approveHRSpecialist').prop('disabled', true);
                            setTimeout(function(){$('#approveHRSpecialist').prop('disabled', false);}, 2345);
                            hyf.util.disableComponent('button_exchange_mgr');
                            hyf.util.disableComponent('button_returnToClassification');
                            var name = $('#h_currentUserName').val();
                            var today = APPROVALS_TAB.today();
                            APPROVALS_TAB.signing('output_approveHRSpecialistSignature', name);
                            setTimeout(function(){APPROVALS_TAB.signing('output_concurrenceDateHRSpecialist', today);}, 1000);
                            FormState.doActionNoRender(StateAction.changeText('approveHRSpecialistSignature', name));
                            FormState.doActionNoRender(StateAction.changeText('concurrenceDateHRSpecialist', today));
                        }else{
                            hyf.util.enableComponent('button_exchange_mgr');
                            hyf.util.enableComponent('button_returnToClassification');
                            $('#output_approveHRSpecialistSignature').html('');
                            $('#output_concurrenceDateHRSpecialist').html('');
                            FormState.doActionNoRender(StateAction.reset('approveHRSpecialistSignature'));
                            FormState.doActionNoRender(StateAction.reset('concurrenceDateHRSpecialist'));
                        }
                    }
                }
            }

        }catch(e){
            //skip for debug
        }

        this.initialized = true;
    },
    isDirtyField: function(field) {
        var f = FormState.getState(field);
        return (f && f.dirty);
    },
    isAvailable: function() {
        return IHS_REQUEST_MAIN.isStrategicConsultationActivity();
    },
    signing: function(target, message, index){
        index = index ? index:0;
        if(index === 0){
            $('#'+target).html('');
        }
        if (index < message.length) {
            $('#'+target).append(message[index++]);
            setTimeout(function () { APPROVALS_TAB.signing(target, message, index); }, Math.random()*100);
        }
    },
    today: function(){
        var now = new Date();
        return (now.getMonth()+1) + '/' + now.getDate() + '/' + now.getFullYear();
    }
};
function isTrue(val){
    if(typeof val === 'boolean'){
        return val;
    } else if(typeof val === 'string' && val.toLowerCase() === 'true') {
        return true;
    }
    return false;
}
function removeSelectedItem(e){
    var $this = $(e);
    var fieldName = $this.attr('_fieldName');
    var index = $this.attr('_index');

    var $f = $('#'+fieldName);
    var selectedValues = $f.val();
    var data = selectedValues.split(',');
    data.splice(index-1, 1);
    var dataStr = data.join();
    $f.val(dataStr);
    FormState.doActionNoRender(StateAction.changeText(fieldName, dataStr));

    $('#' + fieldName + index + '_item').remove();
    if(data.length === 0){
        $('#' + fieldName + '_selected_value_place_holder').hide();
    }
}

function regenerateSelectedValues(fieldName, selectedValues, templateId){
    var inputField = FormState.getState(fieldName+'_input');
    var data = [];
    if(selectedValues && 0<selectedValues.length){
        data = selectedValues.split(',');
    }
    if(inputField && 0<inputField.value.length){
        data.push(inputField.value);
    }
    data = jQuery.unique(data);
    data = data.sort();
    var view = {items:[]};
    $.each(data, function(i, v){
        view.items.push({fieldName: fieldName, index: i+1, label: v});
    });

    var $inputField = $('#' + fieldName + '_input');
    var $placeHolder = $('#' + fieldName + '_selected_value_place_holder');
    if(0<data.length){
        $placeHolder.removeClass('hide');
        $placeHolder.show();
        templateId = (templateId)?templateId:'simpleItemsTmpl';
        var template = $('#'+templateId).val();
        Mustache.parse(template, ['[[',']]']);
        var rendered = Mustache.render(template, view);
        $(".selectedValueLayoutGroup", $placeHolder).html(rendered);

        var dataStr = data.join(',');
        var $fieldName = $('#'+fieldName);
        $fieldName.val(dataStr);
        FormState.doActionNoRender(StateAction.changeText(fieldName, dataStr));
        FormState.doActionNoRender(StateAction.reset(fieldName+'_input'));

        // check Mandatory
        if($inputField.attr('_required') === 'true'){
            $inputField.removeAttr('_required');
            $inputField.attr('_required_org', 'true');
        }
    }else{
        $placeHolder.hide();
        $(".selectedValueLayoutGroup", $placeHolder).html('');

        // check Mandatory
        if($inputField.attr('_required_org') === 'true'){
            $inputField.attr('_required', 'true');
        }
    }
}