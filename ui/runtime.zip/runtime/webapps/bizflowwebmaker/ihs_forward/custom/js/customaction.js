function openForwardToClassifier(param){
	var items = getBizCoveComponent(param.bizcoveid).getSelectedItems();
	if(items)
	{
		if(1==items.length)
		{
            var data = items[0];
			
			if (data.isrequeststatus != 'Pending Classification' && data.isrequeststatus != 'Modify Classification') {
				notify("This request cannot be forwarded. You can forward when it is in Pending Classification or Modify Classification status.", "warn");
			} else {
				var url = "/bizflowwebmaker/ihs_forward/bizflowEntry.do?procid="+data.procid+"&activityid="+data.actseq+"&workitemseq="+data.witemseq+"&bizcoveid="+param.bizcoveid+"&_t="+(new Date()).getTime();
				var w = openPopup(url, "Forward", "Forward", 600, 400, true, false);
			}
		}
		else
		{
			notify("More than one item cannot be selected for this action. Please select only one item.", "warn");
		}
	}
	else
	{
		notify("In order to proceed with this action, please select at least one item.", "warn");
	}
}