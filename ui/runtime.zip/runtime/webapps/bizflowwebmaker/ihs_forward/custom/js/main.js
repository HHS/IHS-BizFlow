var RESPONSE_FORWARD_ID = 4;

function populateInformation() {
    var xml = $('#h_formData').val();
    var x2js = new X2JS();
    if (xml != null && xml.length > 0) {
        var json = x2js.xml_str2json(xml);
        $.each(json.formData.items.item, function (i, v) {
            if (v.id === 'positionTitle') {
                $('#positionTitle').text(v.value);
            }else if (v.id === 'adminCode') {
                $('#adminCode').text(v.value);
                $('#h_admincode').val(v.value);
            }else if (v.id === 'HRClassifier') {
                $('#currentHRClassifier').text(v.text);
                $('#h_currenthrclassifier').val(v.value);
            }
        });
    }
}

function populateHRClassifiers() {
    var adminCode = $('#h_admincode').val();
    var currentHRClassifier = $('#h_currenthrclassifier').val();
    $.ajax({
        url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchClassifier.do',
        data: {searchString: adminCode},
        dataType: 'xml',
        cache: false,
        success: function (xmlResponse) {
            var data = $('record', xmlResponse).map(function () {
                return {
                    value: '',
                    memberid: $('MEMBERID', this).text(),
                    name: $('NAME', this).text(),
                    email: $('EMAIL', this).text()
                };
            }).get();
            if (data.length > 0) {
                var currentMemberId = '';
                try{
                    var s = sessionStorage.getItem('HWSESSIONINFO');
                    s = s.substring(s.indexOf('USERID="')+8);
                    currentMemberId = s.substring(0, s.indexOf('"'));
                }catch (e) {
                }

                $('#HRClassifier').html('');
                $('#HRClassifier').append('<option value="">Select One</option>');
                data.forEach(function (value) {
                    if (currentHRClassifier != value.memberid || currentMemberId != value.memberid) {
                        $('#HRClassifier').append('<option value="' + value.memberid + '">' + value.name + ' (' + value.email + ')</option>');
                    }
                });
            }
        }
    });
}

function forward() {
    $.blockUI();
    var newClassifier = $('#HRClassifier option:selected');
    var classifierID = newClassifier.val();
    var classifierName = newClassifier.text();
    if (10 != classifierID.length) {
        $.unblockUI();
        alert('Please select an HR Classifier to forward.');
        $('#HRClassifier').focus();
        return;
    }
    $('#h_classifierid').val(classifierID);
    $('#h_classifiername').val(classifierName);
    BFUtility.callPartialPage(null, 'forward.do', null, 'partial_page_container_group');
}

function completeWorkitem() {
    $.ajax({
        url: '/bizflow/_scriptlibrary/completeworkitem.jsp',
        method: 'POST',
        data: {
            serverid: '0000001001',
            processid: $('#h_processid').val(),
            activityid: $('#h_activityid').val(),
            workitemseq: $('#h_workitemseq').val(),
            respid: RESPONSE_FORWARD_ID,
            priority: 100,
            commentcheck: 'F'
        },
        dataType: 'json',
        cache: false,
        success: function (resultObj) {
            if (resultObj.success) {
                var caller = getModalCaller();
                if (caller) {
                    if (caller.refreshData) {
                        caller.refreshData();
                    } else if (caller.refreshBizcove) {
                        caller.refreshBizcove($('#h_bizcoveid').val());
                    }
                }
                alert("This work item has been successfully forwarded.");
                closeWindow();
            }
            else {
                alert(resultObj.message, "error");
            }
        }
    });
}

$(document).ready(function () {
    populateInformation();
    populateHRClassifiers();

    $('#cancelBtn').click(function () {
        closeWindow();
    });

    $('#forwardBtn').click(function () {
        forward();
    });
});

