var RESPONSE_FORWARD_ID = 4;
function populateInformation(){

}
function populateHRClassifiers(adminCode, priorSelectedClassifier){
	$.ajax({
		url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchClassifier.do',
        data: {searchString:adminCode},
		dataType: 'xml',
		cache: false,       
		success: function (xmlResponse){
			var data = $('record', xmlResponse ).map(function(){
				return {                                                                                
					value: '',
					memberid: $('MEMBERID', this ).text(),
					name: $('NAME', this ).text(),
					email: $('EMAIL', this ).text()                                      
				};
			}).get();
		if(data.length > 0){
			$('#HRClassifier').html('');
			$('#HRClassifier').append('<option value="">Select One</option>');
			data.forEach(function(value){
				if (priorSelectedClassifier == value.memberid) {
					$('#HRClassifier').append('<option selected value="'+ value.memberid +'">' + value.name +' (' + value.email + ')</option>');
				} else {
					$('#HRClassifier').append('<option value="'+ value.memberid +'">' + value.name +' (' + value.email + ')</option>');
				}
			});
		}
		}
	});
}
function forward(){
	var classifierID = $('#HRClassifier option:selected').val();
    //submit
}
function completeWorkitem(){
	$.ajax({
		url: '/bizflow/_scriptlibrary/completeworkitem.jsp',
        method: 'POST',
        data: {serverid: '0000001001', processid: processid, activityid: activityid, workitemseq: workitemseq, respid: RESPONSE_FORWARD_ID, priority:100, commentcheck:'F'},
		dataType: 'json',
		cache: false,
		success: function (resultObj){
                if(resultObj.success)
                {
                    debugger;
                    //caller.refreshData();
                }
                else
                {
                    alert(resultObj.message, "error");
                }
		}
	});
}
$(document).ready(function(){
    populateInformation();
	populateHRClassifiers();
	
    $('#cancelBtn').click(function(){
    });
    
    $('#forwardBtn').click(function(){
        forward();
    });
});

