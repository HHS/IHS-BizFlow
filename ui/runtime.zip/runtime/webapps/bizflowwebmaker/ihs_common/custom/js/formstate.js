/* global $ Redux _ CP_dateSelected X2JS */
/* eslint camelcase:0, no-unused-vars:0 no-global-assign:0 */
// import { createStore } from 'redux';
// var createStore = require('redux').createStore;
var ETYPE = {
    CHECKBOX: 'checkbox',
    DATE: 'date',
    PVARIABLE: 'pvariable',
    RADIO: 'radio',
    SELECT: 'select',
    TEXTBOX: 'textbox',
    VARIABLE: 'variable'};
function FormStateException (message) {
    this.message = message;
    this.name = 'FormState Exception';
}
var StateAction = new function () {
    var clearAllFlag = function () {
        return {type: 'CLEAR_ALL_FLAG'};
    };
    var makeAllDirty = function () {
        return {type: 'MAKE_ALL_DIRTY'};
    };
    var changeVariable = function (id, value) {
        return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.VARIABLE, value: value};
    };
    var changePVariable = function (id, value) {
        return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.PVARIABLE, value: value};
    };
    var changeSelect = function (id, value, text) {
        return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.SELECT, value: value, text: text};
    };
    var changeCheckbox = function (id, value) {
        return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.CHECKBOX, value: value};
    };
    var changeRadio = function (id, value) {
        return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.RADIO, value: value};
    };
    var changeText = function (id, value) {
        return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.TEXTBOX, value: value};
    };
    var changeDate = function (id, value) {
        return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.DATE, value: value};
    };
    /**
     * Reset value
     * @param id element Id
     * @param etype (Optional) ETYPE. Default value is ETYPE.TEXTBOX if not defined.
     * @param value  (Optional)
     * @param text  (Optional)
     */
    var reset = function (id, etype, value, text) {
        if(_.isUndefined(etype)){
            etype = ETYPE.TEXTBOX;
        }

        var state = {type: 'CHANGE_VALUE', id: id, etype: etype};
        if(_.isUndefined(value)){
            state['value'] = '';
        }else{
            state['value'] = value;
        }

        if(etype === ETYPE.SELECT){
            state['text'] = _.isUndefined(text)?'': text;
        } else if(etype === ETYPE.CHECKBOX){
            state['value'] = _.isUndefined(text)?'false': text;
        } else if(etype === ETYPE.RADIO){
            state['value'] = _.isUndefined(text)?'': text;
        }
        return state;
    };
    return {
        makeAllDirty: makeAllDirty,
        clearAllFlag: clearAllFlag,
        changeVariable: changeVariable,
        changeSelect: changeSelect,
        changeCheckbox: changeCheckbox,
        changeRadio: changeRadio,
        changeText: changeText,
        changeDate: changeDate,
        reset: reset
    }
}();

var FormState = new function () {
    // --------------------------------------------
    // Private
    // --------------------------------------------
    var store = null;
    var renderers = [];
    var trackHistory = true;

    var updateForm = function () {
        var state = getState();
        _.forEach(state.items, function (o) {
            if (o.needRender) {
                if (o.etype === ETYPE.CHECKBOX) {
                    $('#' + o.id).prop('checked', isTrue(o.value));
                } else if (o.etype === ETYPE.RADIO) {
                    var radios = $('input:radio[name=' + o.id + ']');
                    radios.filter('[value="' + o.value + '"]').prop('checked', true);
                } else if (o.etype !== ETYPE.VARIABLE && o.etype !== ETYPE.PVARIABLE) {
                    $('#' + o.id).val(o.value);
                }
            }
        });
    };
    var isTrue = function(val) {
        if(typeof val === 'boolean'){
            return val;
        } else if(typeof val === 'string' && val.toLowerCase() === 'true') {
            return true;
        }
        return false;
    };
    // MUST BE PURE FUNCTION
    var clearAllFlag = function (state, needRender, dirty) {
        var newItems = state.items.map(function (entry, id) {
            return _.assign({}, entry, {id: entry.id, needRender: needRender, dirty: dirty});
        });
        var newState = {items: newItems, history: state.history};
        return newState;
    };
    var addHistory = function (entry, newEntry) {
        if (entry.value !== newEntry.value) {
            var historyItem = _.assign({}, entry);
            if (!_.isUndefined(historyItem.history)) {
                delete historyItem.history;
            }
            if (_.isUndefined(newEntry.history)) {
                newEntry.history = [];
            }
            newEntry.history.push(historyItem);
        }
    };

    // MUST BE PURE FUNCTION
    var changeState = function (state, action, needRender, dirty) {
        var targetState = _.find(state.items, function (o) {
            return o.id === action.id;
        });
        var foundTargetState = false;
        if (!_.isUndefined(targetState)) {
            foundTargetState = true;
        }

        var newItems;
        var newEntry = {};
        if (foundTargetState) {
            newItems = state.items.map(function (entry, id) {
                if (entry.id === action.id) {
                    if (entry.etype === ETYPE.SELECT) {
                        newEntry = _.assign({}, entry, {value: action.value, text: action.text, needRender: needRender, dirty: dirty});
                        if (trackHistory) {
                            addHistory(entry, newEntry);
                        }
                        return newEntry;
                    } else if (entry.etype === ETYPE.CHECKBOX || entry.etype === ETYPE.RADIO || entry.etype === ETYPE.TEXTBOX || entry.etype === ETYPE.VARIABLE || entry.type === ETYPE.PVARIABLE || entry.etype === ETYPE.DATE) {
                        newEntry = _.assign({}, entry, {value: action.value, needRender: needRender, dirty: dirty});
                        if (trackHistory) {
                            addHistory(entry, newEntry);
                        }
                        return newEntry;
                    }
                } else {
                    return entry;
                }
            });
        } else {
            var initialEntry = {};
            if (action.etype === ETYPE.SELECT) {
                initialEntry = {id: action.id, etype: action.etype, value: '', text: '', needRender: needRender, dirty: dirty};
                newEntry = {id: action.id, etype: action.etype, value: action.value, text: action.text, needRender: needRender, dirty: dirty};
                if (trackHistory) {
                    addHistory(initialEntry, newEntry);
                }
                newItems = state.items.concat([newEntry]);
            } else if (action.etype === ETYPE.CHECKBOX || action.etype === ETYPE.RADIO || action.etype === ETYPE.TEXTBOX || action.etype === ETYPE.VARIABLE || action.etype === ETYPE.PVARIABLE || action.etype === ETYPE.DATE) {
                initialEntry = {id: action.id, etype: action.etype, value: '', needRender: needRender, dirty: dirty}
                newEntry = {id: action.id, etype: action.etype, value: action.value, needRender: needRender, dirty: dirty};
                if (trackHistory) {
                    addHistory(initialEntry, newEntry);
                }
                newItems = state.items.concat([newEntry]);
            }
        }
        var newState = {items: newItems, history: state.history};
        return newState;
    };
    // MUST BE PURE FUNCTION
    var formReducer = function (state, action) {
        if (_.isUndefined(state)) {
            state = {items: [], history: []};
        }

        var newState;
        switch (action.type) {
            case 'CHANGE_VALUE': {
                newState = changeState(state, action, true, true);
                break;
            }
            case 'CLEAR_ALL_FLAG': {
                newState = clearAllFlag(state, false, false);
                break;
            }
            case 'MAKE_ALL_DIRTY': {
                newState = clearAllFlag(state, true, true);
                break;
            }
            default: {
                newState = state;
            }
        }
        return newState;
    };

    var original_CP_dateSelected = function () {};
    if (!_.isUndefined(CP_dateSelected)) {
        original_CP_dateSelected = CP_dateSelected;
    }
    var bindElements = function () {
        // CP_dateSelecte is a javascript function provided by WebMaker.
        // This function is called whenever clicking on date in calendar.
        // Below code is hooking this function so that we can change date state after date is selected.
        CP_dateSelected = function (index, year, month, day) {
            original_CP_dateSelected(index, year, month, day);
            var value = $('#' + index).val();
            doAction(StateAction.changeDate(index, value));
        };
        $('select').on('change', function (e) {
            doAction(StateAction.changeSelect(e.target.id,
                e.target.options[e.target.options.selectedIndex].value,
                e.target.options[e.target.options.selectedIndex].text));
        });
        $('textarea').on('keyup', function (e) {
            doAction(StateAction.changeText(e.target.id, e.target.value));
        });
        $('input.textbox[_type="string"]').not('.ui-autocomplete-input').on('keyup', function (e) {
            doAction(StateAction.changeText(e.target.id, e.target.value));
        });
        $('input.textbox[_type="date"], textarea').on('keyup', function (e) {
            doAction(StateAction.changeDate(e.target.id, e.target.value));
        });
        $('input.checkbox').on('click', function (e) {
            var checked = $('#' + e.target.id).prop('checked');
            doAction(StateAction.changeCheckbox(e.target.id, checked));
        });
        $('input:radio').on('click', function (e) {
            doAction(StateAction.changeRadio(e.target.name, e.target.value));
        });
    };
    // --------------------------------------------
    // Public
    // --------------------------------------------
    var doRender = function () {
        if (renderers.length > 0) {
            _.forEach(renderers, function (renderer) {
                if (typeof renderer === 'function') {
                    renderer();
                } else {
                    throw new FormStateException('registered renderer is not a function.');
                }
            });
        } else {
            throw new FormStateException('No registered renderer found.');
        }
        updateForm();
        doAction(StateAction.clearAllFlag(), false); // it should be false when calling doAction from doRender
    };

    var getFinalStateXML = function() {
        var config = {history: false};
        if(arguments.length === 3) {
            config['activityName'] = arguments[0];
            config['memberID'] = arguments[1];
            config['memberName'] = arguments[2];
            if (_.isUndefined(arguments[0]) && _.isUndefined(arguments[1]) && _.isUndefined(arguments[2])) {
                config.history = false;
            }else{
                config.history = true;
            }
        } else if(arguments.length === 1 && typeof arguments[0] === 'object') {
            config = _.assign(config, arguments[0]);
        }

        var state = getFinalState(config);
        _.forEach(state.items, function (node) {
            delete node.history;
            delete node.needRender;
            delete node.dirty;
        });

        _.forEach(state.history, function (node) {
            if (node.changedItems != null) {
                _.forEach(node.changedItems, function (changedNode) {
                    delete changedNode.needRender;
                    delete changedNode.dirty;
                })
            }
        });

        state.items = {item: state.items};
        state.history = {item: state.history};

        var x2js = new X2JS();
        var jsonWrapperObject = {formData: state};
        var xml = x2js.json2xml_str(jsonWrapperObject);

        return xml;
    };

    var getFinalState = function (config) {
        if (store) {
            var config = _.assign({history: true, activityName:'', memberID:'', memberName:''}, config);
            var state = store.getState();
            var finalState = _.assign({}, state);

            if (_.isUndefined(finalState.history)) {
                finalState.history = [];
            } else {
                if (!(finalState.history instanceof Array)) {
                    var historyItem = finalState.history;
                    finalState.history = [];
                    finalState.history.push(historyItem);
                }
            }

            if (config.history) {
                var changedItems = [];
                _.forEach(finalState.items, function (o) {
                    if (o.history && o.history.length > 0) {
                        if (o.history[o.history.length - 1].value !== o.value) {
                            delete o.history;
                            changedItems.push(o);
                        }
                    }
                });

                if (changedItems.length > 0) {
                    finalState.history.push({date: new Date(), activityName: config.activityName, memberID: config.memberID, memberName: config.memberName, changedItems: changedItems});
                }
            }
            return finalState;
        } else {
            throw new FormStateException('FormState is not initialized. FormState.store is null');
        }
    };
    var getState = function (elementID) {
        if (store) {
            if (_.isUndefined(elementID)) {
                return store.getState();
            } else {
                var state = store.getState();
                return _.find(state.items, function (o) { return o.id === elementID; });
            }
        } else {
            throw new FormStateException('FormState is not initialized. FormState.store is null');
        }
    };
    var addRenderer = function (renderer) {
        if (typeof renderer === 'function') {
            var rendererItem = _.find(renderers, function (o) {
                return o === renderer;
            });
            if (_.isUndefined(rendererItem)) {
                renderers.push(renderer);
            }
        } else {
            throw new FormStateException('renderer should be a function.');
        }
    };
    var doActions = function (actions, needRender) {
        _.forEach(actions, function (action, index) {
            store.dispatch(action);
        });
        if (_.isUndefined(needRender) || needRender === true) {
            doRender();
        }
    };
    var doAction = function (action, needRender) {
        store.dispatch(action);
        if (_.isUndefined(needRender) || needRender === true) {
            doRender();
        }
    };
    var doActionNoRender = function (action) {
        doAction(action, false);
    };
    var doActionsNoRender = function (actions) {
        doActions(actions, false);
    };
    var isDirty = function(elementID) {
        var f = FormState.getState(elementID);
        return (f && f.dirty);
    };
    var init = function (renderer, defaultState) {
        if (typeof Redux !== 'object') {
            throw new FormStateException('Redux is not initialized. Check whether you include redux.js');
        }
        if (typeof _ !== 'function') {
            throw new FormStateException('lodash is not initialized. Check whether you include lodash.min.js');
        }
        if (!_.isFunction(renderer)) {
            throw new FormStateException('Invalid parameter. renderer is not a function.')
        }
        if (_.isUndefined(defaultState) || typeof defaultState !== 'object') {
            defaultState = {items: [], history: []};
        }

        store = Redux.createStore(formReducer, defaultState);
        addRenderer(renderer);
        bindElements();

        doAction(StateAction.makeAllDirty(), false);//doAction method in init() should be passed a 2nd param false, else it's infinite loop
    };

    var initWithXML = function (renderer, previousStateXML) {
        var defaultState = {items: [], history: []};
        var x2js = new X2JS();
        if (previousStateXML != null && previousStateXML.length > 0) {
            var formDataObject = x2js.xml_str2json(previousStateXML);
            if (typeof formDataObject.formData.history !== 'object' || formDataObject.formData.history === '') {
                formDataObject.formData.history = [];
            }
            defaultState.history = formDataObject.formData.history.item;
            if (formDataObject.formData.items.item instanceof Array) {
                defaultState.items = formDataObject.formData.items.item;
            } else {
                var item = formDataObject.formData.items.item;
                defaultState.items = [];
                defaultState.items.push(item);
            }
        }

        init(renderer, defaultState);
    };

    return {
        init: init,
        initWithXML: initWithXML,
        addRenderer: addRenderer,
        getState: getState,
        getFinalStateXML: getFinalStateXML,
        doActions: doActions,
        doAction: doAction,
        doActionsNoRender: doActionsNoRender,
        doActionNoRender: doActionNoRender,
        doRender: doRender,
        isDirty: isDirty
    };
}();

// var testForm = {
//     renderer: function () {
//         var select3 = FormState.getState('select3');
//         var select4 = FormState.getState('select4');

//         if (select3 && select3.dirty) {
//             if (select3.text === 'Show Below') {
//                 $('#select3_below').show();
//             } else {
//                 $('#select3_below').hide();
//                 FormState.doActions([
//                     StateAction.changeText('text4', 'Cleared'),
//                     StateAction.changeValue('text5', 'Cleared')], false);
//             }
//         }

//         if (select4 && select4.dirty) {
//             if (select4.text === 'Show Below') {
//                 $('#select4_below').show();
//             } else {
//                 $('#select4_below').hide();
//                 FormState.doAction(StateAction.changeText('text5', 'Cleared'), false);
//             }
//         }
//     },

//     onload: function () {
//         var defaultState = {
//             items: [
//                 {id: 'select1', etype: 'select', value: '2', text: '2'},
//                 {id: 'select2', etype: 'select', value: '3', text: '3'},
//                 {id: 'radio1', etype: 'radio', value: 'Y'},
//                 {id: 'check1', etype: 'checkbox', value: false},
//                 {id: 'check2', etype: 'checkbox', value: true},
//                 {id: 'date1', etype: 'date', value: '11/11/2017', text: '11/10/2017'},
//                 {id: 'text1', etype: 'textbox', value: 'text1a'},
//                 {id: 'text2', etype: 'textbox', value: 'text2a'},
//                 {id: 'text3', etype: 'textbox', value: 'text3a'},
//                 {id: 'select3', etype: 'select', value: '1', text: 'Show Below'},
//                 {id: 'select4', etype: 'select', value: '1', text: 'Show Below'},
//                 {id: 'text4', etype: 'textbox', value: 'Initial Value for text4'},
//                 {id: 'text5', etype: 'textbox', value: 'Initial Value for text5'}
//             ],
//             history: []
//         };
//         FormState.init(testForm.renderer, defaultState);
//         //FormState.init(testForm.renderer);

//         var processID = 1000;
//         $('input.button').on('click', function (e) {
//             if (e.target.id === 'button1') {
//                 console.log(FormState.getState());
//                 alert(JSON.stringify(FormState.getState()));
//                 console.log(FormState.getFinalState({history:true, activityName:'Activity', memberID:'0000000101', memberName:'Peter Lee'}));
//             } else if (e.target.id === 'button2') {
//                 FormState.doActions([
//                     StateAction.changeSelect('select1', '1', 'Show All'),
//                     StateAction.changeSelect('select2', '', 'Select One'),
//                     StateAction.changeRadio('radio1', 'Y'),
//                     StateAction.changeCheckbox('check1', false),
//                     StateAction.changeCheckbox('check2', false),
//                     StateAction.changeValue('date1', ''),
//                     StateAction.changeText('text1', ''),
//                     StateAction.changeText('text2', ''),
//                     StateAction.changeText('text3', ''),
//                     StateAction.changeSelect('select3', '1', 'Show Below'),
//                     StateAction.changeSelect('select4', '1', 'Show Below'),
//                     StateAction.changeText('text4', 'Cleared'),
//                     StateAction.changeText('text5', 'Cleared')
//                 ])
//             } else if (e.target.id === 'button3') {
//                 FormState.doAction(StateAction.changeVariable('processID', processID++), false);
//             }
//         });
//     }
// }
