var TRACK_TAB = {
    initialized: false,
	track_request_details : {},
    init: function (){ 	
		TRACK_TAB.setJobNumberAutoComplete();
		
    },
    render: function () {
		if(!TRACK_TAB.initialized){
			var job_codeNumber = FormState.getState('interface_job_requisitionNumber');
			if(job_codeNumber && job_codeNumber.dirty){
				TRACK_TAB.loadJobNumberDetails(undefined, TRACK_TAB.populatePageData);
			}		
			TRACK_TAB.initialized = true;
		}
		
    },
	renderPositionNumberGroup : function(numb){
		var count = numb ? parseInt(numb) + 1 : 1,vac = numb ? parseInt(numb) : 1;
		for (var fieldGroup = count; fieldGroup <= 5; fieldGroup++){
           hyf.util.hideComponent('positionNumberGroup_' + fieldGroup);
        }
		for (var fieldGroup = 1; fieldGroup <= vac; fieldGroup++){
           hyf.util.showComponent('positionNumberGroup_' + fieldGroup);
        }
	},
	loadJobNumberDetails: function (request, response){
		 var url = '/bizflowwebmaker/ihsrec_Track/loadTrackRequest.do?searchString=';// + $('#interface_job_requisitionNumber').val();
		 if($('#interface_job_requisitionNumber').val() != undefined){
			 url += $('#interface_job_requisitionNumber').val();
		 }
		$.ajax({
                    url:  url,
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
								JOB_OPEN_NUMBER : $('JOB_OPEN_NUMBER', this).text(),
								
								POSTING_TITLE : $('POSTING_TITLE', this).text(),
								ADMIN_CODE : $('ADMIN_CODE', this).text(),
								GEO_LOCATION_CODE : $('GEO_LOCATION_CODE', this).text(),
								REQUEST_DATE : $('REQUEST_DATE', this).text(),
								APPROVER_NAME : $('APPROVER_NAME', this).text(),
								OPEN_LOCATION_DESC : $('OPEN_LOCATION_DESC', this).text(),
								AUTH_DATE: $('AUTH_DATE', this).text(),
								APPROVER_EMPID : $('APPROVER_EMPID', this).text(),
								OPEN_STATUS_CODE : $('OPEN_STATUS_CODE', this).text(),
								OPEN_STATUS : $('OPEN_STATUS', this).text(),
								OPEN_STATUS_DATE : $('OPEN_STATUS_DATE', this).text(),
								OPEN_STATUS_LAST_UPDATED : $('OPEN_STATUS_LAST_UPDATED', this).text(),
								NUMBER_OF_VACANCIES : $('NUMBER_OF_VACANCIES', this).text(),
								CAN : $('CAN', this).text(),
								POSITION_NUMBER : $('POSITION_NUMBER', this).text(),
								JOB_CODE : $('JOB_CODE', this).text(),
								NAME_OF_EMP_REQUESTED : $('NAME_OF_EMP_REQUESTED', this).text(),
								POSITION_VACATED : $('POSITION_VACATED', this).text(),
								POSITION_VICE_NAME : $('POSITION_VICE_NAME', this).text(),
								APPORVAL_COMMENTS : $('APPORVAL_COMMENTS', this).text(),
								NEW_HIRE_PAY_PLAN_SERIES_GRADE : $('NEW_HIRE_PAY_PLAN_SERIES_GRADE',this).text(),
								REMARKS : $('REMARKS', this).text(),
								NEW_HIRE_NAME : $('NEW_HIRE_NAME', this).text(),
								NEW_HIRE_POSITION_TITLE : $('NEW_HIRE_POSITION_TITLE', this).text(),
								NEW_HIRE_DUTE_STATION : $('NEW_HIRE_DUTE_STATION', this).text(),
								NEW_HIRE_SEND_OFFER : $('NEW_HIRE_SEND_OFFER', this).text(),
								NEW_HIRE_EFFECTIVE_DATE : $('NEW_HIRE_EFFECTIVE_DATE', this).text(),
								NEW_HIRE_NUMBER : $('NEW_HIRE_NUMBER', this).text(),
								CERTIFICATE_NUMBER : $('CERTIFICATE_NUMBER', this).text(),
								CERTIFICATE_ISSUE_DATE : $('CERTIFICATE_ISSUE_DATE', this).text(),
								CERTIFICATE_DUE_DATE : $('CERTIFICATE_DUE_DATE', this).text(),
								CERTIFICATE_RETURN_DATE : $('CERTIFICATE_RETURN_DATE', this).text(),
								REQUEST_NUMBER : $('REQUEST_NUMBER', this).text(),
								ANNOUNCEMENT_NUMBER :  $('ANNOUNCEMENT_NUMBER', this).text(),
								VACANCY_TYPE : $('VACANCY_TYPE', this).text(),
								JOA_DATE : $('JOA_DATE', this).text(),
								ANNOUNCEMENT_DATE :  $('ANNOUNCEMENT_DATE', this).text(),
								ANNOUNCEMENT_CLOSE_DATE : $('ANNOUNCEMENT_CLOSE_DATE', this).text(),
								ANNOUNCEMENT_TYPE: $('ANNOUNCEMENT_TYPE', this).text(),
								ANNOUNCEMENT_LOCATION :$('ANNOUNCEMENT_LOCATION', this).text()
                            };
                        }).get();
                        response(data);
						
                    }
                });
	},
	 setJobNumberAutoComplete: function () {		 
        $('#interface_job_requisitionNumber').autocomplete({
            source: function (request, response) {
                TRACK_TAB.loadJobNumberDetails(request, response);
            },
            minLength: 3,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var dl = ui.item.JOB_OPEN_NUMBER;
                $('#interface_job_requisitionNumber').val(dl);
				TRACK_TAB.populatePageData([ui.item]);
				FormState.doAction(StateAction.changeText('interface_job_requisitionNumber', dl), false);
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
         .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>'+item.JOB_OPEN_NUMBER + ', ' + item.ANNOUNCEMENT_LOCATION+'</a>')
                .appendTo(ul);
        };
    }
	,
	populatePageData : function(inputData){
			if(inputData && Array.isArray(inputData)){
			$('#interface_postingTitle').text(inputData[0].JOB_OPEN_NUMBER);			
			$('#interface_geo_Loc').text(inputData[0].GEO_LOCATION_CODE);
			$('#approverName').text(inputData[0].APPROVER_NAME);
			$('#interface_authorizeDate').text(inputData[0].AUTH_DATE.substr(0,10));
			$('#interface_openStatus_code').text(inputData[0].OPEN_STATUS_CODE);
			$('#interface_jobOpenStatusDate').text(inputData[0].OPEN_STATUS_DATE.substr(0,10));
			$('#interface_pplanSeries_grade').text(inputData[0].NEW_HIRE_PAY_PLAN_SERIES_GRADE);
			$('#interface_adminCode_desc').text(inputData[0].ADMIN_CODE);
			$('#interface_openDate').text(inputData[0].REQUEST_DATE.substr(0,10));
			$('#interface_LocDesc').text(inputData[0].OPEN_LOCATION_DESC);
			$('#interface_approverEmpID').text(inputData[0].APPROVER_EMPID);
			$('#interface_openingStatus').text(inputData[0].OPEN_STATUS);
			$('#interface_statusLastUpdated').text(inputData[0].OPEN_STATUS_LAST_UPDATED.substr(0,10));
			$('#interface_number_of_vacancies').text(inputData[0].NUMBER_OF_VACANCIES);
			$('#can_numb').text(inputData[0].CAN);
			$('#interface_positionNumber').text(inputData[0].POSITION_NUMBER);
			$('#interface_jobCode').text(inputData[0].JOB_CODE);
			$('#interface_ehrp_viceName').text(inputData[0].POSITION_VICE_NAME);
			$('#interface_positionVacated').text(inputData[0].POSITION_VACATED);
			$('#interface_approvalComments').text(inputData[0].APPORVAL_COMMENTS);
			$('#interface_remarks').text(inputData[0].REMARKS);
			
			$('#interface_req_number').text(inputData[0].REQUEST_NUMBER);
			$('#interface_vacancyType').text(inputData[0].VACANCY_TYPE);
			$('#interface_annNumber').text(inputData[0].ANNOUNCEMENT_NUMBER);
			$('#interface_joaDate').text(inputData[0].JOA_DATE.substr(0,10));
			$('#interface_annDate').text(inputData[0].ANNOUNCEMENT_DATE.substr(0,10));
			$('#interface_announceCloseDate').text(inputData[0].ANNOUNCEMENT_CLOSE_DATE.substr(0,10));
			$('#interface_annType').text(inputData[0].ANNOUNCEMENT_TYPE);
			$('#interface_location').text(inputData[0].ANNOUNCEMENT_LOCATION);
			
			$('#newHireName').text(inputData[0].NEW_HIRE_NAME);
			$('#interface_positionTitle').text(inputData[0].NEW_HIRE_POSITION_TITLE);
			$('#interface_dutyLoc').text(inputData[0].NEW_HIRE_DUTE_STATION);
			$('#interface_sendOffer').text(inputData[0].NEW_HIRE_SEND_OFFER);
			$('#interface_effectiveDate').text(inputData[0].NEW_HIRE_EFFECTIVE_DATE.substr(0,10));
			$('#interface_newHireNo').text(inputData[0].NEW_HIRE_NUMBER);
			
			var certs = [];
				certs.push({'CERTIFICATE_NUMBER':inputData[0].CERTIFICATE_NUMBER,
				'CERTIFICATE_ISSUE_DATE' : inputData[0].CERTIFICATE_ISSUE_DATE.substr(0,10),
				'CERTIFICATE_DUE_DATE' : inputData[0].CERTIFICATE_DUE_DATE.substr(0,10),
				'CERTIFICATE_RETURN_DATE' : inputData[0].CERTIFICATE_RETURN_DATE.substr(0,10)});
			TRACK_TAB.populateCertificateTable(certs);	
			TRACK_TAB.renderPositionNumberGroup(1);
			}			
	},
	populateCertificateTable : function(cellObjArray){
		if(cellObjArray && Array.isArray(cellObjArray)){
			$('#certificates').html('');
			if(cellObjArray.length > 0){
				cellObjArray.forEach(function(el,index){
					var row = '<tr"><td style="font-weight:normal !important;">' +cellObjArray[index].CERTIFICATE_NUMBER + '</td>'
                    + '<td style="font-weight:normal !important;">' +  cellObjArray[index].CERTIFICATE_ISSUE_DATE  +'</td>'
                    +'<td style="font-weight:normal !important;">' + cellObjArray[index].CERTIFICATE_DUE_DATE + '</td>'
                    +'<td style="font-weight:normal !important;">'+ cellObjArray[index].CERTIFICATE_RETURN_DATE  +'</td>' 
					+'</tr>';
					$('#certificates').append(row);
				});
			}else{
				var row = '<tr><td style="font-weight:none !important;">' +cellObjArray[0].CERTIFICATE_NUMBER + '</td>'
                    + '<td style="font-weight:none !important;">' +  cellObjArray[0].CERTIFICATE_ISSUE_DATE  +'</td>'
                    +'<td style="font-weight:none !important;">' + cellObjArray[0].CERTIFICATE_DUE_DATE + '</td>'
                    +'<td style="font-weight:none !important;">'+ cellObjArray[0].CERTIFICATE_RETURN_DATE  +'</td>' 
					+'</tr>';
					$('#certificates').append(row);
			}
			
		}
		
	}
};