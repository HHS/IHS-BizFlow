/* eslint no-unused-vars:0 */

var BFLog = new function () {
    // logLevel
    //      ERROR
    //      INFO
    //      DEBUG
    var logLevel = 'ERROR';

    var setLogLevel = function (level) {
        if (level === 'ERROR' || level === 'INFO' || level === 'DEBUG') {
            logLevel = level;
        } else {
            logLevel = 'ERROR';
        }
    };
    var getLogLevel = function () {
        return logLevel;
    };
    var _log = function (message) {
       // var callerLine = new Error().stack.split('\n')[4];
        console.log(message);
    };
    var debugLog = function (message) {
        if (logLevel === 'DEBUG') {
            _log(message);
        }
    };
    var infoLog = function (message) {
        if (logLevel === 'DEBUG' || logLevel === 'INFO') {
            _log(message);
        }
    }
    var errorLog = function (message) {
        if (logLevel === 'DEBUG' || logLevel === 'INFO' || logLevel === 'INFO') {
            _log(message);
        }
    };

    var log = function (level, message) {
        if (level === 'DEBUG') {
            debugLog(message);
        } else if (level === 'INFO') {
            infoLog(message);
        } else {
            errorLog(message);
        }
    }

    return {
        getLogLevel: getLogLevel,
        setLogLevel: setLogLevel,
        log: log
    }
}();
