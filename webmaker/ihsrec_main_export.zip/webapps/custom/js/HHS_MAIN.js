/* global $ TabManager BFUtility BFActivityOption BFLog FormState StateAction bootbox hyf LookupManager */

var activityList = [{
    name: 'Activity 1',
    usergroup: [],
    tabs: ['tab1', 'tab9'],
    readonly: ['tab1']
}, {
    name: 'Activity 2',
    usergroup: [],
    tabs: ['tab1', 'tab3'],
    readonly: []
}];

var HHS_MAIN = {
    tabList: [{
        id: 'tab1',
        targetUrl: '/HHS_MAIN/showTab1.do',
        targetGroup: 'partial_tab1',
        name: 'Tab 1',
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function () {
            // $('#tab1 img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').show();
        },
        postDisableTab: function () {
            // $('#tab1 img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').hide();
        },
        postClearTabContents: function () {
            // $('#RI_OA_APRV_ITEM').val('NA');
        },
        renderer: function () {
        }
        // onInit: function() {
        // }
    }, {
        id: 'tab9',
        targetUrl: '/ihs_common/showAttachment.do',
        targetGroup: 'partial_tab3',
        name: 'Documents',
        loaded: false,
        completed: false,
        disabledHeader: false
    }],

    addButtonHandler: function (buttonID, validationRequired, buttonOptions, confirmMessage) {
        if (buttonID != null && buttonOptions != null) {
            $('#' + buttonID).off('click').click(function () {
                if (validationRequired === true) {
                    var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
                    for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                        var validated = TabManager.validateTab(activeTabs[tabIndex]);
                        if (validated === false) {
                            return;
                        }
                    }

                    var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
                    if (mandatoryDocumentsValid !== 'true') {
                        TabManager.enableTabHeader('tab3');
                        TabManager.enableTab('tab3');
                        $('#' + TabManager.getAnchorID('tab3')).click();
                        bootbox.alert('Please upload the missing required document(s).');
                        return;
                    }
                }

                if (confirmMessage != null && confirmMessage.length > 0) {
                    bootbox.dialog({
                            message: '<p class="bootbox-body">' + confirmMessage + '</p>',
                            onEscape: true,
                            buttons: [{
                                label: 'Yes',
                                className: 'btn-success',
                                callback: function () {
                                    buttonOptions.forEach(function (option) {
                                        if (option.id === 'pv_requestStatusDate') {
                                            option.value = BFUtility.getNowUTCString();
                                        }
                                        $('#' + option.id).val(option.value);
                                    })
                                    BFUtility.greyOutScreen(true);
                                    // TabManager.enableTabsForSubmission();
                                    BFUtility.submitFormPage(buttonID, 'saveNewForm');
                                }
                            }, {
                                label: 'No',
                                className: 'btn-danger'
                            }]
                        });
                } else {
                    buttonOptions.forEach(function (option) {
                        if (option.id === 'pv_requestStatusDate') {
                            option.value = BFUtility.getNowUTCString();
                        }
                        $('#' + option.id).val(option.value);
                    })
                    BFUtility.greyOutScreen(true);
                    BFUtility.submitFormPage(buttonID, 'saveNewForm');
                }
            });
        } else {
            BFLog.log('DEBUG', 'STRATCONMAIN - addButtonHandler() - buttonID or buttonOption is null.');
        }
    },
    initBasedOnActivity: function () {
        if (BFUtility.isReadOnly() === true) {
            $('#bottomSection').hide();
            return;
        }

        BFLog.log('DEBUG', 'STRATONMAIN - initBasedOnActivity - START');

        // var activityName = BFActivityOption.getActivityName();
        // if (activityName === 'Activity 1') {
        //     if (BFUtility.isCurrentUserMemberOf('Selecting Officials') === true) {
        //         $('#button_cr_send_2').hide();
        //         p2wMain.addButtonHandler('button_cr_notify_2', true, [{
        //             id: 'WIH_complete_requested', value: 'true'
        //         }, {
        //             id: 'pv_requestStatus', value: 'Request Created'
        //         }, {
        //             id: 'pv_requestStatusDate', value: ''
        //         }, {
        //             id: 'pv_selectOfficialReviewReq', value: 'No'
        //         }]);
        //     } else {
        //         $('#button_cr_notify_2').hide();
        //         p2wMain.addButtonHandler('button_cr_send_2', true, [{
        //             id: 'WIH_complete_requested', value: 'true'
        //         }, {
        //             id: 'pv_requestStatus', value: 'Request Created'
        //         }, {
        //             id: 'pv_requestStatusDate', value: ''
        //         }, {
        //             id: 'pv_selectOfficialReviewReq', value: 'Yes'
        //         }]);
        //     }
        //     $('#actionButton_CreateRequest_2').removeClass('hide');
        // } else if (activityName === 'Activity 2') {
        //     p2wMain.addButtonHandler('button_rr_notify_2', true, [{
        //         id: 'WIH_complete_requested', value: 'true'
        //     }, {
        //         id: 'pv_requestStatusDate', value: ''
        //     }]);
        //     $('#actionButton_ReviewRequest_2').removeClass('hide');
        // } else {
        //     BFLog.log('DEBUG', 'STRATCONMAIN - initBasedOnActivity() - No activity name matched [' + activityName + ']');
        // }

        BFLog.log('DEBUG', 'STRATONMAIN - initBasedOnActivity - END');
    },
    // Request Type in General Tab
    resetRequestType: function () {
        var requestTypeLabel = $('#SG_RT_ID option:selected').text();
        var requestTypeValue = $('#SG_RT_ID option:selected').val();

        if (requestTypeValue !== '') {
            $('#requestType').text(requestTypeLabel);
        } else {
            $('#requestType').text('');
        }
        TabManager.resetTabs();
    },
    // This function will be called after getRequestNumber.do is completed.
    resetRequestNumber: function () {
        var requestNumber = $('#h_response_requestNumber').val();
        // $('#h_requestNumber').val(requestNumber);
        FormState.doAction(StateAction.changeVariable('requestNumber', requestNumber));
        $('#pv_requestStatus').val('Request Created');

        // $('#requestNumber').text(requestNumber);
        // $('#output_requestStatus').text('Request Created');
        var requestedStatusDate = $('#h_now').val();
        $('#pv_requestStatusDate').val(requestedStatusDate);
    },

    loadForm: function () {
        var xml = $('#h_formData').val();
        FormState.initWithXML(HHS_MAIN.renderer, xml);
        _.forEach(HHS_MAIN.tabList, function (tab) {
            if (typeof tab.renderer === 'function') {
                FormState.addRenderer(tab.renderer);
            }
        });
        FormState.doRender();
    },

    onAllTabLoaded: function () {
        BFLog.log('DEBUG', 'Received HHS_ALL_TAB_LOADED!');

        //
        // Code to remove certain tab based on certain condition.
        //
        // TabManager.clearTabContent(tabID);
        // TabManager.hideTabHeader(tabID);
        // BFActivityOption.removeTabFromCurrentActivity(activityName, tabID);

        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        BFUtility.initMaxSize(tabs);
        BFUtility.setDateIconTabOrder(tabs);

        HHS_MAIN.showHidePreNextButtons();
        $(document).on('ON_TAB_CHANGE', HHS_MAIN.onTabChange);
    },

    onTabChange: function () {
        if (BFUtility.isReadOnly() === false) {
            // var requestNumber = FormState.getState('requestNumber');
            // if (typeof requestNumber === 'undefined' || requestNumber.value == null || requestNumber.value.length === 0) {
            //     $('#h_now').val(BFUtility.getNowUTCString());
            //     BFUtility.callPartialPage(null, 'getRequestNumber.do', 'system', 'layoutForResponse');
            // };

            var activityName = BFActivityOption.getActivityName();
            var memberID = $('#h_currentUserMemberID').val();
            var memberName = $('#h_currentUserName').val();
            var xml = FormState.getFinalStateXML(activityName, memberID, memberName);
            $('#h_formData').val(xml);

            BFUtility.callPartialPage(null, 'saveTabContent.do', null, 'layoutForResponse2');
        }

        HHS_MAIN.showHidePreNextButtons();
    },

    renderer: function () {
        // var requestNumber = FormState.getState('requestNumber');
        // if (requestNumber && requestNumber.value && requestNumber.dirty === true) {
        //     $('#requestNumber').text(requestNumber.value);
        // }
    },

    showHidePreNextButtons: function () {
        var selectedTabID = TabManager.getSelectedTabID();
        var activeTabs = BFActivityOption.getTabList();

        var currentTabIndex = 0;
        for (var index = 0; index < activeTabs.length; index++) {
            if (activeTabs[index] === selectedTabID) {
                currentTabIndex = index;
                break;
            }
        }

        if (currentTabIndex === 0) {
            hyf.util.disableComponent('button_Previous');
            hyf.util.enableComponent('button_Next');
        } else if (currentTabIndex === activeTabs.length - 1) {
            hyf.util.enableComponent('button_Previous');
            hyf.util.disableComponent('button_Next');
        } else {
            BFUtility.enableComponents(['button_Previous', 'button_Next'])
        }
    },
    saveForm: function (e) {
        $('#h_currentTabID').val(TabManager.getSelectedTabID()); // store current tabid to reset after page reload

        var activityName = BFActivityOption.getActivityName();
        var memberID = $('#h_currentUserMemberID').val();
        var memberName = $('#h_currentUserName').val();
        var xml = FormState.getFinalStateXML(activityName, memberID, memberName);

        $('#h_formData').val(xml);
        BFUtility.saveForm(e);
    },

    //
    // Main ENTRY POINT
    //
    init: function () {
        BFLog.setLogLevel('DEBUG');
        BFLog.log('DEBUG', 'HHS_MAIN - init START');

        BFActivityOption.init(activityList);

        if (BFUtility.isReadOnly() === true) {
            var activityName = BFActivityOption.getActivityName();
            var readonlyTabs = ['tab1', 'tab2', 'tab3'];
            BFActivityOption.setReadOnlyTabList(activityName, readonlyTabs);
        }

        LookupManager.init();

        TabManager.initTab(HHS_MAIN.tabList, HHS_MAIN.loadForm);
        $(document).on('HHS_ALL_TAB_LOADED', HHS_MAIN.onAllTabLoaded);

        $('#button_SaveWorkitem').on('click', HHS_MAIN.saveForm);
        $('#button_Previous').off('click').click(function (e) {
            TabManager.loadPreviousTab();
        });
        $('#button_Next').off('click').click(function (e) {
            TabManager.loadNextTab();
        });

        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString); // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = BFUtility.getDateString(false, 'mm/dd/yyyy', newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        // // Request Number
        // var requestNumber = $('#h_requestNumber').val();
        // $('#requestNumber').text(requestNumber);

        // // Request Status
        // var requestStatus = $('#pv_requestStatus').val();
        // $('#output_requestStatus').text(requestStatus);

        hyf.util.disableComponent('button_Previous');
        hyf.util.enableComponent('button_Next');

        HHS_MAIN.initBasedOnActivity();

        // set focus on the current tab
        $('a.selectedTab').focus();

        BFLog.log('DEBUG', 'HHS_MAIN - init END');
    }
}
