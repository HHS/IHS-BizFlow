/* global $ TabManager BFUtility BFActivityOption BFLog FormState StateAction bootbox hyf LookupManager */
var Activity_HRActionRequest = 'HR Action Request';
var Activity_Classification = 'Classification';
var Activity_StrategicConsultation = 'Strategic Consultation';
var Activity_UpdateHRActionRequest = 'Update HR Action Request';
var Activity_UpdateClassification = 'Update Classification';
var Activity_MatchEHRPID = 'Match EHRP ID';
var Activity_FillPosition = 'Fill Position';
var Status_PendingMoreInformation = 'Pending More Information';
var Status_PendingClassification = 'Pending Classification';
var Status_HRActionRequestActivitySaved = 'HR Action Request Activity Saved';
var Status_PendingStrategicConsultation = 'Pending Strategic Consultation';
var Status_HRSPendingStrategicConsultation = 'HRS_Pending Strategic Consultation';
var Status_PendigFundingApproval = 'Pendig Funding Approval';
var Status_Draft = 'Draft';
var MessageResource = {
    SELECT_ONE: 'Select one',
    SELECT_ALL_THAT_APPLY: 'Select all that apply'
};
var SelectOptionConfig_SelectOne = {firstItem: {value: '', text: MessageResource.SELECT_ONE}};
var SelectOptionConfig_SelectAllThatApply = {firstItem: {value: '', text: MessageResource.SELECT_ALL_THAT_APPLY}};

var activityList = [{
    name: Activity_HRActionRequest,
    usergroup: [],
    tabs: ['tab1', 'tab9'],
    readonly: []
}, {
    name: Activity_Classification,
    usergroup: [],
    tabs: ['tab1', 'tab9'],
    readonly: []
}, {
    name: Activity_StrategicConsultation,
    usergroup: [],
    tabs: ['tab1', 'tab2', 'tab9', 'tab3', 'tab4'],
    readonly: []
}, {
    name: Activity_UpdateHRActionRequest,
    usergroup: [],
    tabs: ['tab1', 'tab9'],
    readonly: []
}, {
    name: Activity_UpdateClassification,
    usergroup: [],
    tabs: ['tab1', 'tab9'],
    readonly: []
}, {
    name: Activity_MatchEHRPID,
    usergroup: [],
    tabs: ['tab1', 'tab2', 'tab9', 'tab3', 'tab4', 'tab5'],
    readonly: ['tab1', 'tab2', 'tab9', 'tab3', 'tab4']
}, {
    name: Activity_FillPosition,
    usergroup: [],
    tabs: ['tab1', 'tab2', 'tab9', 'tab3', 'tab4', 'tab5', 'tab6'],
    readonly: []
}];

var IHS_REQUEST_MAIN = {
    tabList: [{
        id: 'tab1',
        targetUrl: '/ihsrec_position/showTab1.do',
        targetGroup: 'partial_tab1',
        name: 'Request',
        validationOnLoadNextTab: false,
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function () {
        },
        postDisableTab: function () {
            IHS_REQUEST_MAIN.extraCoordinatorForReadOnlyTab(this.id);
            $('#occupationalSeries_container, #grade_container, #dutyStation_container').hide();
        },
        postClearTabContents: function () {
        },
        renderer: function () {
            HHS_TAB1.render();
        },
        onInit: function () {
            HHS_TAB1.init();
        }
    }, {
        id: 'tab2',
        targetUrl: '/ihsrec_job/showJob.do',
        targetGroup: 'partial_tab2',
        name: 'Job Announcement',
        validationOnLoadNextTab: false,
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function () {
        },
        postDisableTab: function () {
        },
        postClearTabContents: function () {
        },
        renderer: function () {
            JOB_TAB.render();
        },
        onInit: function () {
            JOB_TAB.init();
        }
    }, {
        id: 'tab3',
        targetUrl: '/ihsrec_job/showHROnly.do',
        targetGroup: 'partial_tab3',
        name: 'HR Only',
        validationOnLoadNextTab: false,
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function () {
        },
        postDisableTab: function () {
        },
        postClearTabContents: function () {
        },
        renderer: function () {
            HRONLY_TAB.render();
        },
        onInit: function () {
            HRONLY_TAB.init();
        }
    }, {
        id: 'tab4',
        targetUrl: '/ihsrec_job/showApprovals.do',
        targetGroup: 'partial_tab4',
        name: 'Approvals',
        validationOnLoadNextTab: false,
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function () {
        },
        postDisableTab: function () {
        },
        postClearTabContents: function () {
        },
        renderer: function () {
            APPROVALS_TAB.render();
        },
        onInit: function () {
            APPROVALS_TAB.init();
        }
    }, {
        id: 'tab5',
        targetUrl: '/ihsrec_track/showTrackRequest.do',
        targetGroup: 'partial_tab5',
        name: 'Track Request',
        validationOnLoadNextTab: false,
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function () {
        },
        postDisableTab: function () {
        },
        postClearTabContents: function () {
        },
        renderer: function () {
            TRACK_TAB.render();
        },
        onInit: function () {
            TRACK_TAB.init();
        }
    }, {
        id: 'tab6',
        targetUrl: '/ihsrec_job/showCloseOut.do',
        targetGroup: 'partial_tab6',
        name: 'Close-out',
        validationOnLoadNextTab: false,
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function () {
        },
        postDisableTab: function () {
        },
        postClearTabContents: function () {
        },
        renderer: function () {
            // CLOSEOUT_TAB.render();
        },
        onInit: function () {
            // CLOSEOUT_TAB.init();
        }
    }, {
        id: 'tab9',
        targetUrl: '/ihs_common/showAttachment.do',
        targetGroup: 'partial_tab9',
        name: 'Documents',
        validationOnLoadNextTab: false,
        loaded: false,
        completed: false,
        disabledHeader: false
    }],
    isHRActionRequestActivity: function () {
        return Activity_HRActionRequest === BFActivityOption.getActivityName();
    },
    isClassificationActivity: function () {
        return Activity_Classification === BFActivityOption.getActivityName();
    },
    isStrategicConsultationActivity: function () {
        return Activity_StrategicConsultation === BFActivityOption.getActivityName();
    },
    isUpdateHRActionRequestActivity: function () {
        return Activity_UpdateHRActionRequest === BFActivityOption.getActivityName();
    },
    isUpdateClassificationActivity: function () {
        return Activity_UpdateClassification === BFActivityOption.getActivityName();
    },
    isMatchEHRPIDActivity: function () {
        return Activity_MatchEHRPID === BFActivityOption.getActivityName();
    },
    isFillPositionActivity: function () {
        return Activity_FillPosition === BFActivityOption.getActivityName();
    },
    isHiringManager: function() {
        return (-1<$('#hiringManager').val().indexOf($('#h_currentUserMemberID').val()));
    },
    addButtonHandler: function (buttonID, validationRequired, buttonOptions, confirmMessage) {
        if (buttonID != null && buttonOptions != null) {
            $('#' + buttonID).off('click').click(function () {
                if (validationRequired === true) {
                    var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
                    for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                        var validated = TabManager.validateTab(activeTabs[tabIndex]);
                        if (validated === false) {
                            return;
                        }
                    }

                    var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
                    if (mandatoryDocumentsValid !== 'true') {
                        TabManager.enableTabHeader('tab3');
                        TabManager.enableTab('tab3');
                        $('#' + TabManager.getAnchorID('tab3')).click();
                        bootbox.alert('Please upload the missing required document(s).');
                        return;
                    }
                }

                if (confirmMessage != null && confirmMessage.length > 0) {
                    bootbox.dialog({
                        message: '<p class="bootbox-body">' + confirmMessage + '</p>',
                        onEscape: true,
                        buttons: [{
                            label: 'Yes',
                            className: 'btn-success',
                            callback: function () {
                                buttonOptions.forEach(function (option) {
                                    if (option.id === 'pv_requestStatusDate') {
                                        option.value = BFUtility.getNowUTCString();
                                    }
                                    $('#' + option.id).val(option.value);
                                })
                                BFUtility.greyOutScreen(true);
                                ajaxSubmission("actionWorkitem.do");
                            }
                        }, {
                            label: 'No',
                            className: 'btn-danger'
                        }]
                    });
                } else {
                    buttonOptions.forEach(function (option) {
                        if (option.id === 'pv_requestStatusDate') {
                            option.value = BFUtility.getNowUTCString();
                        }
                        $('#' + option.id).val(option.value);
                    })
                    BFUtility.greyOutScreen(true);
                    ajaxSubmission("actionWorkitem.do");
                }
            });
        } else {
            BFLog.log('DEBUG', 'STRATCONMAIN - addButtonHandler() - buttonID or buttonOption is null.');
        }
    },
    initBasedOnActivity: function () {
        if (BFUtility.isReadOnly() === true) {
            $('#bottomSection').hide();
            return;
        }

        if (IHS_REQUEST_MAIN.isHRActionRequestActivity() || IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()) {
            hyf.util.showComponent('button_CancelWorkitem');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.showComponent('button_Next');

        } else if (IHS_REQUEST_MAIN.isClassificationActivity()) {
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');

            hyf.util.showComponent('button_CancelWorkitem');
            hyf.util.showComponent('button_sendMail');
            hyf.util.showComponent('button_forward');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.showComponent('button_Next');
            hyf.util.showComponent('button_submitToHR');

        } else if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');

            hyf.util.showComponent('button_CancelWorkitem');
            hyf.util.showComponent('button_returnToClassification');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.showComponent('button_PDF');
            if (IHS_REQUEST_MAIN.isHiringManager()) {
                hyf.util.showComponent('button_exchange_hr');
                hyf.util.showComponent('button_submitToHR');
            } else {
                hyf.util.showComponent('button_exchange_mgr');
                hyf.util.showComponent('button_PDF');
            }
            hyf.util.showComponent('button_Next');
        } else if (IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');

            hyf.util.showComponent('button_CancelWorkitem');
            hyf.util.showComponent('button_forward');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.showComponent('button_Next');

        } else if (IHS_REQUEST_MAIN.isMatchEHRPIDActivity()) {
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');
            hyf.util.showComponent('button_SendBack');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_SubmitOnMatchEHRPID');
            hyf.util.showComponent('button_Next');
        }
    },
    // Request Type in General Tab
    resetRequestType: function () {
        var requestTypeLabel = $('#SG_RT_ID option:selected').text();
        var requestTypeValue = $('#SG_RT_ID option:selected').val();

        if (requestTypeValue !== '') {
            $('#requestType').text(requestTypeLabel);
        } else {
            $('#requestType').text('');
        }
        TabManager.resetTabs();
    },

    loadForm: function () {
        var xml = $('#h_formData').val();
        FormState.initWithXML(IHS_REQUEST_MAIN.renderer, xml);
        _.forEach(IHS_REQUEST_MAIN.tabList, function (tab) {
            if (typeof tab.renderer === 'function') {
                FormState.addRenderer(tab.renderer);
            }
        });
        FormState.doRender();
    },

    onAllTabLoaded: function () {
		if (!BFUtility.isReadOnly()) {
			hyf.util.showComponent('main_buttons_layout_group');
            hyf.util.showComponent('tab_container_group');
		}

        //
        // Code to remove certain tab based on certain condition.
        //
        // TabManager.clearTabContent(tabID);
        // TabManager.hideTabHeader(tabID);
        // BFActivityOption.removeTabFromCurrentActivity(activityName, tabID);

        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        BFUtility.initMaxSize(tabs);
        BFUtility.setDateIconTabOrder(tabs);

        IHS_REQUEST_MAIN.showHidePreNextButtons();
        $(document).on('ON_TAB_CHANGE', IHS_REQUEST_MAIN.onTabChange);

        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });

        setTimeout(function () {
            var ui = basicWIHActionClient.getUI();
            ui.getPane(ui.PANE_TOOL).open();
            ui.getPane(ui.PANE_TOOL).close();
            ui.getPane(ui.PANE_ATTACHMENT).hide();
            ui.getPane(ui.PANE_INTERNAL_DISCUSSION).open();
        }, 100);
    },
    onTabChange: function () {
        if (BFUtility.isReadOnly() === false) {
            var selectedTab = TabManager.getSelectedTabID();

            if ('tab9' == selectedTab) {
                if (IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
					// copy job code to long job code field used in next activities
                    FormState.doAction(StateAction.changeText('jobCode_2', $('#jobCode').val()), false);
                }

                if (IHS_REQUEST_MAIN.isHRActionRequestActivity() || IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()) {
                    if (!TabManager.validateTab('tab1')) {
                        TabManager.loadPreviousTab();
                        return;
                    }
                }

				if ('Draft' == $('#output_requestStatus').text() || '' == $('#output_requestStatus').text()) {
					$('#pv_requestStatus').val(Status_HRActionRequestActivitySaved);
					FormState.doAction(StateAction.changeText('pv_requestStatus', Status_HRActionRequestActivitySaved), false);
					$('#output_requestStatus').text(Status_HRActionRequestActivitySaved);
				}
            }

			var xml = FormState.getFinalStateXML();
			$('#h_formData').val(xml);
            basicWIHActionClient.setWIHOption('requestAction', 'tabChange');
            ajaxSubmission("actionWorkitem.do");
        }

        IHS_REQUEST_MAIN.showHidePreNextButtons();
    },

    renderer: function () {
    },
    showHidePreNextButtons: function () {
        var selectedTabID = TabManager.getSelectedTabID();
        var activeTabs = BFActivityOption.getTabList();

        var currentTabIndex = 0;
        for (var index = 0; index < activeTabs.length; index++) {
            if (activeTabs[index] === selectedTabID) {
                currentTabIndex = index;
                break;
            }
        }

        if (currentTabIndex === 0) {
			hyf.util.hideComponent('button_Previous');
			hyf.util.showComponent('button_Next');
			hyf.util.hideComponent('button_submitToHR');
            hyf.util.hideComponent('button_PDF');
			hyf.util.hideComponent('button_SubmitWorkitem');

            if (IHS_REQUEST_MAIN.isHRActionRequestActivity() || IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()) {
                hyf.util.showComponent('button_SaveWorkitem');
            } else if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
                hyf.util.showComponent('button_SaveWorkitem');
            } else if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
                hyf.util.showComponent('button_SaveWorkitem');
            }
        } else if (currentTabIndex === activeTabs.length - 1) {
            hyf.util.showComponent('button_Previous');
            hyf.util.hideComponent('button_Next');
			hyf.util.hideComponent('button_submitToHR');

			// Approval tab
			if ('tab4' == selectedTabID) {
				if (IHS_REQUEST_MAIN.isHiringManager()) {
					hyf.util.showComponent('button_submitToHR');
					hyf.util.hideComponent('button_PDF');
				} else {
					hyf.util.hideComponent('button_submitToHR');
					hyf.util.showComponent('button_PDF');
				}
			} else {
				hyf.util.hideComponent('button_submitToHR');
				hyf.util.hideComponent('button_PDF');
			}

            if (IHS_REQUEST_MAIN.isHRActionRequestActivity() || IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()) {
                hyf.util.showComponent('button_SubmitWorkitem');
                hyf.util.hideComponent('button_SaveWorkitem');
            } else if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
                hyf.util.showComponent('button_SubmitWorkitem');
                hyf.util.hideComponent('button_SaveWorkitem');
            } else if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
                hyf.util.hideComponent('button_SaveWorkitem');
            }
        } else {	// this is always strategic consultation activity or later
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_Next');
            hyf.util.hideComponent('button_SubmitWorkitem');
			
			// Approval tab
			if ('tab4' == selectedTabID) {
				if (IHS_REQUEST_MAIN.isHiringManager()) {
					hyf.util.showComponent('button_submitToHR');
					hyf.util.hideComponent('button_PDF');
				} else {
					hyf.util.hideComponent('button_submitToHR');
					hyf.util.showComponent('button_PDF');
				}
			} else {
				hyf.util.hideComponent('button_submitToHR');
				hyf.util.hideComponent('button_PDF');
			}
        }
    },
    saveForm: function (requestAction) {
        if (IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
            FormState.doAction(StateAction.changeText('jobCode_2', $('#jobCode').val()), false);
        } else if (IHS_REQUEST_MAIN.isClassificationActivity()) {
            if ($('#classificationStat').val() === '') {
                bootbox.alert('Please select a Classification Status.');
                return;
            }
        }

        if ('Draft' == $('#output_requestStatus').text() || '' == $('#output_requestStatus').text()) {
            $('#pv_requestStatus').val(Status_HRActionRequestActivitySaved);
			FormState.doAction(StateAction.changeText('pv_requestStatus', Status_HRActionRequestActivitySaved), false);
        }

        $('#h_currentTabID').val(TabManager.getSelectedTabID()); // store current tabid to reset after page reload
        var xml = FormState.getFinalStateXML();

        $('#h_formData').val(xml);
        if(requestAction){
            basicWIHActionClient.setWIHOption('requestAction', requestAction);
        }
        ajaxSubmission("actionWorkitem.do");
    },

    //
    // Main ENTRY POINT
    //
    init: function () {
        BFLog.setLogLevel('DEBUG');
        $('#main_buttons_layout_group').css('visibility', 'hidden');
		
        $('#workflowBtn').click(function (e) {
            e.preventDefault();
            basicWIHActionClient.monitor();
        });
        if ($('#WIH_exit_requested').val() == 'true') {
            basicWIHActionClient.exit({confirmMsg: null});
        }

        if(IHS_REQUEST_MAIN.isStrategicConsultationActivity()){
			if ($('#hiringManager').val().indexOf($('#h_currentUserMemberID').val()) > -1) {
                // remove tab3 (HR Only)
                _.remove(activityList, function(act){
                    if(act.name === Activity_StrategicConsultation){
                        _.pull(act.tabs, 'tab3');
                    }
                });
            }
        }

        BFActivityOption.init(activityList);

        IHS_REQUEST_MAIN.initBasedOnActivity();
        $('#formTitle').text(BFActivityOption.getActivityName());

        if (BFUtility.isReadOnly() === true) {
            var activityName = BFActivityOption.getActivityName();
            var readonlyTabs = ['tab1', 'tab9'];
            BFActivityOption.setReadOnlyTabList(activityName, readonlyTabs);
        }

        LookupManager.init();

        TabManager.initTab(IHS_REQUEST_MAIN.tabList, IHS_REQUEST_MAIN.loadForm);
        // if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()){
        //     TabManager.enableTabHeader('tab2');
        //     TabManager.enableTab('tab2');
        // }

        $(document).on('HHS_ALL_TAB_LOADED', IHS_REQUEST_MAIN.onAllTabLoaded);

        $('#button_SaveWorkitem').on('click', IHS_REQUEST_MAIN.saveForm);
        $('#button_Previous').off('click').click(function (e) {
            TabManager.loadPreviousTab();
        });
        $('#button_Next').off('click').click(function (e) {
			// validate first tab
			if (IHS_REQUEST_MAIN.isHRActionRequestActivity() || IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()) {
				IHS_REQUEST_MAIN.getTab().validationOnLoadNextTab = true;
			}

            var customValidationResult = true;
            if (IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
                customValidationResult = IHS_REQUEST_MAIN.validateCareerLadderPosition();
            }

            if (customValidationResult) {
                TabManager.loadNextTab();
            }
        });

        $('#button_sendMail').off('click').click(function (e) {
            IHS_REQUEST_MAIN.sendEmail();
        });
		
        $('#button_returnToHR').off('click').click(function (e) {
            // basicWIHActionClient.respond('Return');
            completeWorkitem('Return', false);
        });
		
        $('#button_returnToClassification').off('click').click(function (e) {
            // basicWIHActionClient.respond('Return');
            completeWorkitem('Return', false);
        });
		
        $('#button_exchange_hr').off('click').click(function (e) {
			IHS_REQUEST_MAIN.returnToHRfromManager(Status_PendingStrategicConsultation);
        });
		
        $('#button_exchange_mgr').off('click').click(function (e) {
			$('#consultant').val($('#hiringManager').val().substring(3));
			FormState.doAction(StateAction.changeText('consultant', $('#hiringManager').val().substring(3)), false);
			var xml = FormState.getFinalStateXML();
			$('#h_formData').val(xml);
			IHS_REQUEST_MAIN.submitWorkitem();
        });
		
        $('#button_submitToHR').off('click').click(function (e) {
            // Form validation
            var showAlertMsg = true;
            var isValidForm = true;
            var watchTabId = null;
            var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
            for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                watchTabId = activeTabs[tabIndex];
                isValidForm = TabManager.validateTab(watchTabId);
                if (isValidForm === false) {
                    break;
                }
            }

            if (isValidForm) {
				if ($('#concurHiringManager').prop('checked')) {
					IHS_REQUEST_MAIN.returnToHRfromManager(Status_HRSPendingStrategicConsultation);
				} else {
                    bootbox.alert('Please check the approvals checkbox before submit.');
				}
            } else {
                if (showAlertMsg) {
                    bootbox.alert('Please fill in all the required fields before submit.');
                }
                $('#' + TabManager.getAnchorID(watchTabId)).click();
            }
        });
		
        $('#button_PDF').off('click').click(function (e) {
            // Form validation
            var showAlertMsg = true;
            var isValidForm = true;
            var watchTabId = null;
            var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
            for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                watchTabId = activeTabs[tabIndex];
                isValidForm = TabManager.validateTab(watchTabId);
                if (isValidForm === false) {
                    break;
                }
            }

            if (isValidForm) {
				if ($('#approveHRSpecialist').prop('checked')) {
					alert('Under construction');
					completeWorkitem('Close', false);
				} else {
                    bootbox.alert('Please check the approvals checkbox before submit.');
				}
            } else {
                if (showAlertMsg) {
                    bootbox.alert('Please fill in all the required fields before submit.');
                }
                $('#' + TabManager.getAnchorID(watchTabId)).click();
            }
        });

        $('#button_CancelWorkitem').off('click').click(function (e) {
            if ('Draft' == $('#output_requestStatus').text() || '' == $('#output_requestStatus').text()) {
                // basicWIHActionClient.respond('Cancel');
                completeWorkitem('Cancel', false);
            } else {
                IHS_REQUEST_MAIN.confirmCancel();
            }
        });

        $('#button_forward').off('click').click(function (e) {
            IHS_REQUEST_MAIN.forward();
        });

        $('#button_SubmitWorkitem').off('click').click(function (e) {
            // Form validation
            var showAlertMsg = true;
            var isValidForm = true;
            var watchTabId = null;
            var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
            for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                watchTabId = activeTabs[tabIndex];
                isValidForm = TabManager.validateTab(watchTabId);
                if (isValidForm === false) {
                    break;
                }
            }

            if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
                var gradeSelection = $('#selectGrades').val();
                var gradeList = [];
                if (gradeSelection != '') {
                    var error = false;
                    gradeList = gradeSelection.split(',');
                    gradeList.forEach(function (value) {
                        if (value.indexOf(':') == -1) {
                            error = true;
                            $('#' + value).show();
                        }
                    });
                    if (error) {
                        watchTabId = 'tab1';
                        isValidForm = false;
                    }
                }

                if (isValidForm) {
                    watchTabId = 'tab1';
                    isValidForm = IHS_REQUEST_MAIN.validateCareerLadderPosition();
                    showAlertMsg = isValidForm;
                }
            }

            if (isValidForm) {
                if (IHS_REQUEST_MAIN.isClassificationActivity()) {
                    IHS_REQUEST_MAIN.submitForClassification();
                } else {
                    IHS_REQUEST_MAIN.submitWorkitem();
                }
            } else {
                if (showAlertMsg) {
                    bootbox.alert('Please fill in all the required fields before submit.');
                }
                $('#' + TabManager.getAnchorID(watchTabId)).click();
            }
        });
        $('#button_ExitWIH').off('click').click(function (e) {
            IHS_REQUEST_MAIN.confirmClose();
        });

        $('#button_SendBack').off('click').click(function (e) {
            IHS_REQUEST_MAIN.confirmSendBack();
        });

        $('#button_SubmitOnMatchEHRPID').off('click').click(function (e) {
            IHS_REQUEST_MAIN.submitOnMatchEHRPID();
        });

        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString); // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = BFUtility.getDateString(false, 'mm/dd/yyyy', newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        // // Request Number to process ID
        var requestNumber = $('#h_procid').val();
        $('#requestNumber').text(requestNumber);
        var requstStatus = $('#pv_requestStatus').val();
        if (requstStatus) {
            $('#output_requestStatus').text(requstStatus);
        }

        // set focus on the current tab
		$('#main_buttons_layout_group').css('visibility', 'visible');

        $('a.selectedTab').focus();
        //$('#button_SaveWorkitem').on('click',IHS_REQUEST_MAIN.saveDraft);
    },
    saveDraft: function () {
        var xml = FormState.getFinalStateXML();
        $('#h_formData').val(xml);
        basicWIHActionClient.setWIHOption('requestAction', 'saveDraft');
        ajaxSubmission("actionWorkitem.do");
    },
    validateCareerLadderPosition: function () {
        var gradeSelection = $('#selectGrades').val();
        var gradeList = [];
        if (gradeSelection != '') {
            gradeList = gradeSelection.split(',');
        }

        // Check career ladder position and grade
        var careerLadder = $('input[name="careerLadder"]:checked').val();
        if (careerLadder === 'Y' && gradeList.length <= 1) {
            bootbox.alert('You must select more than 1 grade because the Career Ladder Position has been marked as "Yes".');
            return false;
        } else {
            return true;
        }
    },
    submitOnMatchEHRPID: function() {

    },
    confirmSendBack: function () {
        bootbox.confirm({
            title: '',
            message: 'Would you like to send back?',
            callback: function (result) {
                if (result) {
                    completeWorkitem('Send Back', false);
                }
            }
        });
    },
    confirmClose: function () {
        //user must confirm closing
        bootbox.confirm({
            title: '',
            message: 'Would you like to save your entries before closing?',
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'No',
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if (result) {
                    $('#WIH_exit_requested').val(true);
                    IHS_REQUEST_MAIN.saveForm('exit');
                } else {
                    basicWIHActionClient.exit({confirmMsg: null});
                }
            }
        });
    },
    confirmCancel: function () {
        var cancelReasons = LookupManager.findByLTYPE('CancellationReason');
        var selectHTML = '<select class="form-control" id="cancelReason" name="cancelReason"><option value="">Select One</option>';
        for (var i = 0; i < cancelReasons.length; i++) {
            selectHTML += '<option value="' + cancelReasons[i].NAME + '">' + cancelReasons[i].NAME + '</option>';
        }
        selectHTML += '</select>';

        //user must confirm closing
        bootbox.confirm({
            title: 'What is the reason for canceling this request?',
            message: selectHTML,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#cancelReason').val()) {
                        bootbox.alert('Please select a cancellation reason');
                    } else {
                        $('#pv_cancelReason').val($('#cancelReason').val());
                        // basicWIHActionClient.respond('Cancel');
                        completeWorkitem('Cancel', false);
                    }
                }
            }
        });
    },
    forward: function () {
        var selectHTML = '<select class="form-control" id="forwardUser" name="forwardUser">';
        $("#HRClassifier > option").each(function () {
            if ($("#HRClassifier").val() !== this.value) {
                selectHTML += '<option value="' + this.value + '">' + this.text + '</option>';
            }
        });
        selectHTML += '</select>';

        //user must confirm closing
        bootbox.confirm({
            title: 'Please identify an HR Classifier',
            message: selectHTML,
            buttons: {
                confirm: {
                    label: 'Forward',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#forwardUser').val()) {
                        bootbox.alert('Please identify an HR Classifier to forward this action to');
                    } else {
                        // set HRClassifier value and text
                        FormState.doAction(StateAction.changeSelect('HRClassifier', $('#forwardUser').val(), $('#forwardUser option:selected').text()), false);
                        var xml = FormState.getFinalStateXML();
                        $('#h_formData').val(xml);
                        // basicWIHActionClient.respond('Forward');
                        completeWorkitem('Forward', false);
                    }
                }
            }
        });
    },
    sendEmail: function () {
        var selectHTML = '<textarea class="form-control" rows="16" id="emailContent" name="emailContent" maxlength="500">';
        selectHTML += 'The HR Specialist has reviewed the proposed position and has determined that more information is needed to proceed with the evaluation. Please see the comments below for more information:';
        selectHTML += '\n\n';
        selectHTML += 'Classification Status: ' + $('#classificationStat').val()
        selectHTML += '\nClassification Comments: ' + $('#classificationComments').val();
        selectHTML += '\n\nThe recruit action will remain in "Pending More information" status until all items have been received.';
        selectHTML += '\n\nThank you.';
        selectHTML += '</textarea>';

        //user must confirm closing
        bootbox.confirm({
            title: 'Send Email to HR Manager',
            message: selectHTML,
            buttons: {
                confirm: {
                    label: 'Send',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#emailContent').val()) {
                        bootbox.alert('Please enter email contents.');
                    } else {
                        var workitemContext = basicWIHActionClient.getWorkitemContext();
                        var ccid = workitemContext.Process.Initiator;
                        $.ajax({
                            url: '/bizflowwebmaker/ihs_AutoCompleteService/SendMail.do',
                            method: 'POST',
                            data: {
                                procid: $('#h_procid').val(),
                                senderid: '[U]' + $('#h_currentUserMemberID').val(),
                                recipientid: '[U]' + $('#managerID').val(),
                                ccid: '[U]' + ccid,
                                requestid: IHS_REQUEST_MAIN.uuid(),
                                body: $('#emailContent').val()
                            },
                            dataType: 'xml',
                            cache: false,
                            success: function (xmlResponse) {
                                HHS_TAB1.loadMoreInformationRequest();
                                $('#output_requestStatus').text(Status_PendingMoreInformation);
                                $('#pv_requestStatus').val(Status_PendingMoreInformation);
								FormState.doAction(StateAction.changeText('pv_requestStatus', Status_PendingMoreInformation), false);
                                bootbox.alert('Your email has been successfully sent.');
                            }
                        });
                    }
                }
            }
        });
    },
    uuid: function () {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        })
    },
    submitWorkitem: function () {
        // basicWIHActionClient.respond('Submit');
        completeWorkitem('Submit', false);
    },
    dialogSelectHRSpecialist: null,
    submitForClassification: function () {
        IHS_REQUEST_MAIN.dialogSelectHRSpecialist = bootbox.confirm({
            title: 'Who would you like to route this request to?',
            message: '<select class="form-control" id="selectHRSpecialist" name="selectHRSpecialist"></select>',
            buttons: {
                confirm: {
                    label: 'Submit',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#selectHRSpecialist').val()) {
                        bootbox.alert('Please select someone to receive this request.');
                    } else {
                        // set HRSpecialist value and text
                        FormState.doAction(StateAction.changeText('HRSpecialist', $('#selectHRSpecialist').val()), false);
                        FormState.doAction(StateAction.changeText('consultant', $('#selectHRSpecialist').val()), false);
                        var xml = FormState.getFinalStateXML();
                        $('#h_formData').val(xml);
                        // basicWIHActionClient.respond('Submit');
                        completeWorkitem('Submit', false);
                    }
                }
            }
        });

        IHS_REQUEST_MAIN.dialogSelectHRSpecialist.init(function () {
            $.ajax({
                url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchHRSpecialist.do',
                data: {searchString: $('#adminCode').val(), managerId: $('#managerID').val()},
                dataType: 'xml',
                cache: false,
                success: function (xmlResponse) {
                    var data = $('record', xmlResponse).map(function () {
                        return {
                            value: '',
                            memberid: $('MEMBERID', this).text(),
                            name: $('NAME', this).text(),
                            email: $('EMAIL', this).text()
                        };
                    }).get();
                    if (data.length > 0) {
                        $('#selectHRSpecialist').html('');
                        var initiator = basicWIHActionClient.getWorkitemContext().Process.Initiator;
                        data.forEach(function (value) {
                            var selected = value.memberid === initiator ? ' selected ' : ' ';
                            $('#selectHRSpecialist').append('<option value="' + value.memberid + '" ' + selected + '>' + value.name + ' (' + value.email + ')</option>');
                        });
                    }
                }
            });
        });
    },
	returnToHRfromManager: function (newStatus) {
        IHS_REQUEST_MAIN.dialogSelectHRSpecialist = bootbox.confirm({
            title: 'Who would you like to route this request to?',
            message: '<select class="form-control" id="selectHRSpecialist" name="selectHRSpecialist"></select>',
            buttons: {
                confirm: {
                    label: 'Submit',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#selectHRSpecialist').val()) {
                        bootbox.alert('Please select someone to receive this request.');
                    } else {
						$('#pv_requestStatus').val(newStatus);
						FormState.doAction(StateAction.changeText('pv_requestStatus', newStatus), false);
						
                        // set HRSpecialist value and text
                        FormState.doAction(StateAction.changeText('HRSpecialist', $('#selectHRSpecialist').val()), false);
                        FormState.doAction(StateAction.changeText('consultant', $('#selectHRSpecialist').val()), false);
                        var xml = FormState.getFinalStateXML();
                        $('#h_formData').val(xml);
                        // basicWIHActionClient.respond('Submit');
                        completeWorkitem('Submit', false);
                    }
                }
            }
        });

        IHS_REQUEST_MAIN.dialogSelectHRSpecialist.init(function () {
            $.ajax({
                url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchHRSpecialist.do',
                data: {searchString: $('#adminCode').val(), managerId: $('#managerID').val()},
                dataType: 'xml',
                cache: false,
                success: function (xmlResponse) {
                    var data = $('record', xmlResponse).map(function () {
                        return {
                            value: '',
                            memberid: $('MEMBERID', this).text(),
                            name: $('NAME', this).text(),
                            email: $('EMAIL', this).text()
                        };
                    }).get();
                    if (data.length > 0) {
                        $('#selectHRSpecialist').html('');
                        var currentSpecialist = $('#HRSpecialist').val();
                        data.forEach(function (value) {
                            var selected = value.memberid === currentSpecialist ? ' selected ' : ' ';
                            $('#selectHRSpecialist').append('<option value="' + value.memberid + '" ' + selected + '>' + value.name + ' (' + value.email + ')</option>');
                        });
                    }
                }
            });
        });
    },
    getTab: function () {
        var tabID = TabManager.getSelectedTabID();
        var selectedTabs = IHS_REQUEST_MAIN.tabList.filter(function (node, index) {
            return node.id === tabID;
        });
        var foundTab = null;
        if (selectedTabs.length === 1) {
            foundTab = selectedTabs[0];
        }
        return foundTab;
    },

    extraCoordinatorForReadOnlyTab: function(id) {
        $('#'+id+' .deleteAction, #'+id+' .selectedValueCaption').remove();
        $('#'+id+' .selectedValue').addClass('selectedValueReadOnly');
    },
    disableTabContents: function(tabs) {
        $.each(tabs, function(i,tabId){
            IHS_REQUEST_MAIN.disableAllElements(tabId);
        });
    },
    undoDisableTabContents: function(tabs) {
        $.each(tabs, function(i,tabId){
            IHS_REQUEST_MAIN.undoDisableAllElements(tabId);
        });
    },
    disableAllElements: function(id){
        $('#'+id+' input, #'+id+' select, #'+id+' textarea, #'+id+' button').each(function(i,v){
            var $v = $(v);
            if(!$v.is('[disabled]')){
                $v.attr('__disabled', 'disabled').attr('disabled', 'disabled');
            }
        });
        $('#'+id+' .deleteAction, #'+id+' .datePickerIcon').attr('__disabled', 'disabled').hide();
    },
    undoDisableAllElements: function(id){
        $('#'+id+' input, #'+id+' select, #'+id+' textarea, #'+id+' button').each(function(i,v){
            var $v = $(v);
            if($v.is('[__disabled]')){
                $v.removeAttr('__disabled').removeAttr('disabled');
            }
        });
        $('#'+id+' .deleteAction[__disabled], #'+id+' .datePickerIcon[__disabled]').removeAttr('__disabled').show();
    }
};

/**
 * Adding options to a select tag
 * @param field field ID
 * @param items options
 * @param defaultValue default value
 * @param config {firstItem: {value:'', text:'Select One'} }
 */
function populateSelectOptions(field, items, defaultValue, config) {
    var $f = $('#' + field).html('');
    if (config.firstItem) {
        $f.append($('<option>', {value: config.firstItem.value, text: config.firstItem.text}));
    }
    $.each(items, function (i, item) {
        $f.append($('<option>', {value: item.value, text: item.text, selected: (defaultValue === item.value)}));
    });
    return $f;
}

/**
 * Submit form data and complete workitem. Workitem Handler closed when it completed successfully.
 * @param responseName (Optional) the response name should be one of the available response names on current activity.
 */
function completeWorkitem(responseName, formValidation){
    if(typeof responseName !== 'undefined'){
        basicWIHActionClient.setResponseByName(responseName);
    }
    basicWIHActionClient.setWIHOption('requestAction', 'complete');
    if(!basicWIHActionClient.getWIHOption('formSaved')){
        basicWIHActionClient.setWait();
        ajaxSubmission('actionWorkitem.do', 'all', undefined, formValidation);
    }
}

/**
 * This function to be called when the partial page is loaded.
 */
function onLoadResultActionWorkitem(){
    basicWIHActionClient.setWIHOption('formSaved', true);
    var action = basicWIHActionClient.getWIHOption('requestAction');
    if(action === 'complete'){
        basicWIHActionClient.setContinue();
        basicWIHActionClient.setWIHOption('closeWihOnComplete', true);
        basicWIHActionClient.setWIHOption('completionWindow', false);
        basicWIHActionClient.complete();
    } else if(action === 'tabChange') {

    } else if(action === 'saveDraft') {
        basicWIHActionClient.notify('Your data has been successfully saved.', 3000);
    } else if(action === 'exit') {
        basicWIHActionClient.exit({confirmMsg: null});
    }

    basicWIHActionClient.setWIHOption('formSaved', undefined);
    basicWIHActionClient.setWIHOption('requestAction', undefined);
    BFUtility.greyOutScreen(false);
}

/**
 * Submit form data via ajax
 * @param action WebMaker action name
 * @param sourceGroup (Optional) indicates whether to send all the data on the page or just the data within a particular group.
 * @param targetGroup (Optional) indicates which group to place the results into.
 * @param validate (Optional) indicates whether to validate first. default: false
 * @example
 * // Submit all data without form validation on the page, and result page is not showing.
 * ajaxSubmission('actionWorkitem.do');
 * // Form validation before submit all data on the page, and result page is not showing.
 * ajaxSubmission('actionWorkitem.do', 'all', undefined, true);
 * // Form validation before submit data within 'input_layout_group', and results showing to 'output_layout_group'.
 * ajaxSubmission('actionWorkitem.do', 'input_layout_group', 'output_layout_group', true);
 */
function ajaxSubmission(action, sourceGroup, targetGroup, validate) {
    if (window.location.pathname.indexOf('bizflowwebmaker') > -1 && action.indexOf('/') === 0) {
        action = '/bizflowwebmaker' + action;
    }
    var objAction = {
        name: 'Action',
        option: 'Action',
        value: action
    };
    var objSourceGroup = null;
    if (typeof sourceGroup === 'undefined' || null === sourceGroup || '' === sourceGroup
        || 'all' === sourceGroup || 'ALL' === sourceGroup) {
        objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
    } else {
        objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
    }

    var partialPageContainerId = '_hidden_partial_page_container_';
    if(typeof targetGroup === 'undefined'){
        var partialPageContainer = document.createElement('div');
        if(document.getElementById(partialPageContainerId) === null){
            partialPageContainer.id = partialPageContainerId;
            partialPageContainer.style.display = "none";
            document.getElementsByTagName('body')[0].appendChild(partialPageContainer);
        }
    }else{
        partialPageContainerId = targetGroup;
    }

    var objTargetGroup = {
        name: 'TargetGroup',
        option: 'PageGroup',
        value: partialPageContainerId
    };
    var objValidate = {
        name: 'Validate',
        option: 'Static',
        value: validate?validate:false
    };
    hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, {value: targetGroup});
}