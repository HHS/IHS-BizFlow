/* global $ TabManager BFUtility BFActivityOption BFLog FormState StateAction bootbox hyf LookupManager */
var Activity_HRActionRequest = 'HR Action Request';
var Activity_Classification = 'Classification';
var Activity_StrategicConsultation = 'Strategic Consultation';
var Activity_UpdateHRActionRequest = 'Update HR Action Request';
var Activity_UpdateClassification = 'Update Classification';
var Activity_MatchEHRPID = 'Match EHRP ID';
var Activity_FillPosition = 'Fill Position';
var Status_PendingMoreInformation = 'Pending More Information';
var Status_PendingClassification = 'Pending Classification';
var Status_HRActionRequestActivitySaved = 'HR Action Request Activity Saved';
var Status_HMPendingStrategicConsultation = 'HM_Pending Strategic Consultation';
var Status_HRSPendingStrategicConsultation = 'HRS_Pending Strategic Consultation';
var Status_PendingFundingApproval = 'Pending Funding Approval';
var Status_Draft = 'Draft';
var MessageResource = {
    SELECT_ONE: 'Select one',
    SELECT_ALL_THAT_APPLY: 'Select all that apply'
};
var SelectOptionConfig_SelectOne = {firstItem: {value: '', text: MessageResource.SELECT_ONE}};
var SelectOptionConfig_SelectAllThatApply = {firstItem: {value: '', text: MessageResource.SELECT_ALL_THAT_APPLY}};
var SYSTEM_ERROR_MESSAGE = "<h3 style='color:red'>Something went wrong</h3><p><h4>The system has encountered an error. Please try again, and if it still doesn't work, contact EWITS 2.0 help desk.</h4>";

var TABID_REQUEST= 'tab1';
var TABID_POSITION= TABID_REQUEST;
var TABID_JOB_ANNOUNCEMENT= 'tab2';
var TABID_HR_ONLY= 'tab3';
var TABID_APPROVALS= 'tab4';
var TABID_TRACK_REQUEST = 'tab5';
var TABID_CLOSE_OUT = 'tab6';
var TABID_DOCUMENTS = 'tab9';
var currentUserMemberId;
var activityList = [{
    name: Activity_HRActionRequest,
    usergroup: [],
    tabs: [TABID_REQUEST, TABID_DOCUMENTS],
    readonly: []
}, {
    name: Activity_Classification,
    usergroup: [],
    tabs: [TABID_REQUEST, TABID_DOCUMENTS],
    readonly: []
}, {
    name: Activity_StrategicConsultation,
    usergroup: [],
    tabs: [TABID_REQUEST, TABID_JOB_ANNOUNCEMENT, TABID_DOCUMENTS, TABID_HR_ONLY, TABID_APPROVALS],
    readonly: []
}, {
    name: Activity_UpdateHRActionRequest,
    usergroup: [],
    tabs: [TABID_REQUEST, TABID_DOCUMENTS],
    readonly: []
}, {
    name: Activity_UpdateClassification,
    usergroup: [],
    tabs: [TABID_REQUEST, TABID_DOCUMENTS],
    readonly: []
}, {
    name: Activity_MatchEHRPID,
    usergroup: [],
    tabs: [TABID_REQUEST, TABID_JOB_ANNOUNCEMENT, TABID_DOCUMENTS, TABID_APPROVALS, TABID_TRACK_REQUEST],
    readonly: [TABID_REQUEST, TABID_JOB_ANNOUNCEMENT, TABID_APPROVALS]
}, {
    name: Activity_FillPosition,
    usergroup: [],
    tabs: [TABID_REQUEST, TABID_JOB_ANNOUNCEMENT, TABID_DOCUMENTS, TABID_HR_ONLY, TABID_APPROVALS, TABID_TRACK_REQUEST, TABID_CLOSE_OUT],
    readonly: [TABID_APPROVALS]
}];

var IHS_REQUEST_MAIN = {
    allTabInfo: [{
            id: TABID_REQUEST,
            targetUrl: '/ihsrec_position/showTab1.do',
            targetGroup: 'partial_tab1',
            name: 'Request',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false,
            postEnableTab: function () {
            },
            postDisableTab: function () {
                IHS_REQUEST_MAIN.extraCoordinatorForReadOnlyTab(this.id);
                $('#appointmentType_container, #occupationalSeries_container, #grade_container, #dutyStation_container, #hiringPlan_container').hide();
            },
            postClearTabContents: function () {
            },
            renderer: function () {
                HHS_TAB1.render();
            },
            onInit: function () {
                HHS_TAB1.init();
            }
        },{
            id: TABID_JOB_ANNOUNCEMENT,
            targetUrl: '/ihsrec_job/showJob.do',
            targetGroup: 'partial_tab2',
            name: 'Job Announcement',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false,
            postEnableTab: function () {
            },
            postDisableTab: function () {
                IHS_REQUEST_MAIN.extraCoordinatorForReadOnlyTab(this.id);
                $('#recruitmentEnticements_input_container, #additionalRecruitment_input_container').hide();
            },
            postClearTabContents: function () {
            },
            renderer: function () {
                JOB_TAB.render();
            },
            onInit: function () {
                JOB_TAB.init();
            }
        },{
            id: TABID_HR_ONLY,
            targetUrl: '/ihsrec_job/showHROnly.do',
            targetGroup: 'partial_tab3',
            name: 'HR Only',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false,
            postEnableTab: function () {
            },
            postDisableTab: function () {
            },
            postClearTabContents: function () {
            },
            renderer: function () {
                HRONLY_TAB.render();
            },
            onInit: function () {
                HRONLY_TAB.init();
            }
        },{
            id: TABID_APPROVALS,
            targetUrl: '/ihsrec_job/showApprovals.do',
            targetGroup: 'partial_tab4',
            name: 'Approvals',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false,
            postEnableTab: function () {
            },
            postDisableTab: function () {
                $('#approveHRSpecialist_layout_group, #concurHiringManager_layout_group').hide();
            },
            postClearTabContents: function () {
            },
            renderer: function () {
                APPROVALS_TAB.render();
            },
            onInit: function () {
                APPROVALS_TAB.init();
            }
        },{
            id: TABID_TRACK_REQUEST,
            targetUrl: '/ihsrec_track/showTrackRequest.do',
            targetGroup: 'partial_tab5',
            name: 'Track Request',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false,
            postEnableTab: function () {
            },
            postDisableTab: function () {
            },
            postClearTabContents: function () {
            },
            renderer: function () {
                TRACK_TAB.render();
            },
            onInit: function () {
                TRACK_TAB.init();
            }
        },{
            id: TABID_CLOSE_OUT,
            targetUrl: '/ihsrec_job/showCloseOut.do',
            targetGroup: 'partial_tab6',
            name: 'Close-out',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false,
            postEnableTab: function () {
            },
            postDisableTab: function () {
            },
            postClearTabContents: function () {
            },
            renderer: function () {
                CLOSEOUT_TAB.render();
            },
            onInit: function () {
                CLOSEOUT_TAB.init();
            }
        },{
            id: TABID_DOCUMENTS,
            targetUrl: '/ihs_common/showAttachment.do',
            targetGroup: 'partial_tab9',
            name: 'Documents',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false
        }
    ],
    tabList: [],
    isHRActionRequestActivity: function () {
        return Activity_HRActionRequest === BFActivityOption.getActivityName();
    },
    isClassificationActivity: function () {
        return Activity_Classification === BFActivityOption.getActivityName();
    },
    isStrategicConsultationActivity: function () {
        return Activity_StrategicConsultation === BFActivityOption.getActivityName();
    },
    isUpdateHRActionRequestActivity: function () {
        return Activity_UpdateHRActionRequest === BFActivityOption.getActivityName();
    },
    isUpdateClassificationActivity: function () {
        return Activity_UpdateClassification === BFActivityOption.getActivityName();
    },
    isMatchEHRPIDActivity: function () {
        return Activity_MatchEHRPID === BFActivityOption.getActivityName();
    },
    isFillPositionActivity: function () {
        return Activity_FillPosition === BFActivityOption.getActivityName();
    },
    isHiringManager: function() {
        return (-1<$('#hiringManager').val().indexOf(currentUserMemberId));
    },
    isHRSpecialist: function() {
        return (-1<$('#HRSpecialist').val().indexOf(currentUserMemberId));
    },
    isProxyHiringManager: function(){
        if(this.isHiringManager()){
            var whoToContactName= "";
            var whoToContact = FormState.getState('whoToContact');
            if(whoToContact){
                whoToContactName = whoToContact.value;
            }
            return (whoToContactName !== $('#h_currentUserName').val());
        }else{
            return false;
        }
    },
    getTabInfo: function(id){
        var a = $.grep(IHS_REQUEST_MAIN.allTabInfo, function(v){return v.id === id;});
        return typeof a === 'undefined'? a : a[0];
    },
    initBasedOnActivity: function () {

        var activityName = BFActivityOption.getActivityName();
        $.each(activityList, function(i,v){
            if(v.name === activityName){
                $.each(v.tabs, function(tabIndex,tabId){
                    IHS_REQUEST_MAIN.tabList.push(IHS_REQUEST_MAIN.getTabInfo(tabId));
                });
            }
        });

        if (BFUtility.isReadOnly() === true) {
            $('#bottomSection, #top_action_button_layout_group, #headingAttachments').hide();
            return;
        }

        if (IHS_REQUEST_MAIN.isHRActionRequestActivity() || IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()) {
            if (IHS_REQUEST_MAIN.isHRActionRequestActivity()){
                hyf.util.showComponent('button_copy');
            }
            hyf.util.showComponent('button_CancelWorkitem');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.showComponent('button_Next');
        } else if (IHS_REQUEST_MAIN.isClassificationActivity()) {
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');

            hyf.util.showComponent('button_CancelWorkitem');
            hyf.util.showComponent('button_returnToHR');
            hyf.util.showComponent('button_sendMail');
            hyf.util.showComponent('button_forward');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.showComponent('button_Next');
            hyf.util.showComponent('button_submitToHR');

        } else if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');

            hyf.util.showComponent('button_CancelWorkitem');
            hyf.util.showComponent('button_returnToClassification');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.showComponent('button_PDF');
            if (IHS_REQUEST_MAIN.isHiringManager()) {
                hyf.util.showComponent('button_exchange_hr');
                hyf.util.showComponent('button_submitToHR');
            } else {
                hyf.util.showComponent('button_exchange_mgr');
            }

            if(IHS_REQUEST_MAIN.isHRSpecialist()){
                hyf.util.showComponent('button_PDF');
            }

            hyf.util.showComponent('button_Next');
        } else if (IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');

            hyf.util.showComponent('button_CancelWorkitem');
            hyf.util.showComponent('button_forward');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.showComponent('button_Next');

        } else if (IHS_REQUEST_MAIN.isMatchEHRPIDActivity()) {
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');
            hyf.util.showComponent('button_SendBack');
            hyf.util.showComponent('button_Previous');
            hyf.util.showComponent('button_Next');
        } else if (IHS_REQUEST_MAIN.isFillPositionActivity()){
            IHS_REQUEST_MAIN.tabList[0].name = 'Position';
            $('span .r:eq(0)').text('Position');
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_CancelWorkitem');
        }
    },
    // Request Type in General Tab
    resetRequestType: function () {
        var requestTypeLabel = $('#SG_RT_ID option:selected').text();
        var requestTypeValue = $('#SG_RT_ID option:selected').val();

        if (requestTypeValue !== '') {
            $('#requestType').text(requestTypeLabel);
        } else {
            $('#requestType').text('');
        }
        TabManager.resetTabs();
    },

    loadForm: function (data) {
        FormState.initWithXML(IHS_REQUEST_MAIN.renderer, data);
        _.forEach(IHS_REQUEST_MAIN.tabList, function (tab) {
            if (typeof tab.renderer === 'function') {
                FormState.addRenderer(tab.renderer);
            }
        });
        FormState.doRender();
    },

    onAllTabLoaded: function () {
		if (!BFUtility.isReadOnly()) {
			hyf.util.showComponent('main_buttons_layout_group');
            hyf.util.showComponent('tab_container_group');
		}

        //
        // Code to remove certain tab based on certain condition.
        //
        // TabManager.clearTabContent(tabID);
        // TabManager.hideTabHeader(tabID);
        // BFActivityOption.removeTabFromCurrentActivity(activityName, tabID);

        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        BFUtility.initMaxSize(tabs);
        BFUtility.setDateIconTabOrder(tabs);

        IHS_REQUEST_MAIN.showHidePreNextButtons();
        $(document).on('ON_TAB_CHANGE', IHS_REQUEST_MAIN.onTabChange);

        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });

        setTimeout(function () {
            var ui = basicWIHActionClient.getUI();
            ui.getPane(ui.PANE_TOOL).open();
            ui.getPane(ui.PANE_TOOL).close();
            ui.getPane(ui.PANE_ATTACHMENT).hide();
            ui.getPane(ui.PANE_INTERNAL_DISCUSSION).open();
        }, 100);
    },
    onTabChange: function () {
        if (BFUtility.isReadOnly() === false) {
            var selectedTab = TabManager.getSelectedTabID();

            if (TABID_DOCUMENTS == selectedTab) {
                if (IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
					// copy job code to long job code field used in next activities
                    FormState.doActionNoRender(StateAction.changeText('jobCode_2', $('#jobCode').val()));
                }

                if (IHS_REQUEST_MAIN.isHRActionRequestActivity() || IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()) {
                    if (!TabManager.validateTab(TABID_REQUEST)) {
                        TabManager.loadPreviousTab();
                        return;
                    }
                }

				if (Status_Draft === IHS_REQUEST_MAIN.getStatus()) {
                    if (IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
                        IHS_REQUEST_MAIN.setStatus(Status_HRActionRequestActivitySaved);
                    }
				}
            }

			var xml = FormState.getFinalStateXML();
			$('#h_formData').val(xml);
            basicWIHActionClient.setWIHOption('requestAction', 'tabChange');
            ajaxSubmission("actionWorkitem.do");
        }

        IHS_REQUEST_MAIN.showHidePreNextButtons();
    },

    renderer: function () {
    },
    showHidePreNextButtons: function () {
        var selectedTabID = TabManager.getSelectedTabID();
        var activeTabs = BFActivityOption.getTabList();

        var currentTabIndex = 0;
        for (var index = 0; index < activeTabs.length; index++) {
            if (activeTabs[index] === selectedTabID) {
                currentTabIndex = index;
                break;
            }
        }

        var isLastTab = currentTabIndex === activeTabs.length - 1;

        hyf.util.showComponent('button_Previous');
        hyf.util.showComponent('button_Next');
        if (currentTabIndex === 0) {
            hyf.util.hideComponent('button_Previous');
        } else if (isLastTab) {
            hyf.util.hideComponent('button_Next');
        }

        hyf.util.hideComponent('button_PDF');
        hyf.util.hideComponent('button_submitToHR');
        hyf.util.hideComponent('button_SubmitOnMatchEHRPID');
        hyf.util.hideComponent('button_SubmitWorkitem');

        // Approval Tab
        if (IHS_REQUEST_MAIN.isStrategicConsultationActivity() && TABID_APPROVALS === selectedTabID) {
            if (IHS_REQUEST_MAIN.isHiringManager()) {
                var approveHRSpecialist = FormState.getState('approveHRSpecialist');
                if(typeof approveHRSpecialist ==='undefined' || !isTrue(approveHRSpecialist.value)) {
                    hyf.util.showComponent('button_submitToHR');
                }
            }

            if(IHS_REQUEST_MAIN.isHRSpecialist()){
                hyf.util.showComponent('button_PDF');
            }
        }

        if (isLastTab) {
            // Tracking Request Tab
			if (IHS_REQUEST_MAIN.isMatchEHRPIDActivity() && TABID_TRACK_REQUEST === selectedTabID) {
                hyf.util.showComponent('button_SubmitOnMatchEHRPID');
            }

            if (IHS_REQUEST_MAIN.isHRActionRequestActivity() ||
                IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity() ||
                IHS_REQUEST_MAIN.isClassificationActivity() ||
                IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
                hyf.util.showComponent('button_SubmitWorkitem');
            }
        }
    },
    saveForm: function (requestAction) {
        if (IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
            FormState.doActionNoRender(StateAction.changeText('jobCode_2', $('#jobCode').val()));
        } else if (IHS_REQUEST_MAIN.isClassificationActivity()) {
            if ($('#classificationStat').val() === '') {
                bootbox.alert('Please select a Classification Status.');
                return;
            }
        }

        if (Status_Draft === IHS_REQUEST_MAIN.getStatus()) {
            if (IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
                IHS_REQUEST_MAIN.setStatus(Status_HRActionRequestActivitySaved);
            }
        }

        $('#h_currentTabID').val(TabManager.getSelectedTabID()); // store current tabid to reset after page reload
        var xml = FormState.getFinalStateXML();

        $('#h_formData').val(xml);
        if(typeof requestAction === 'string'){
            basicWIHActionClient.setWIHOption('requestAction', requestAction);
        }
        ajaxSubmission("actionWorkitem.do");
    },

    //
    // Main ENTRY POINT
    //
    init: function () {
        BFLog.setLogLevel('DEBUG');
        $('#main_buttons_layout_group').css('visibility', 'hidden');

        var xml = $('#h_formData').val();
        FormState.initWithXML(function(){}, xml);
        FormState.doRender();

        currentUserMemberId = $('#h_currentUserMemberID').val();

        $('#workflowBtn').click(function (e) {
            e.preventDefault();
            basicWIHActionClient.monitor();
        });
        if ($('#WIH_exit_requested').val() == 'true') {
            basicWIHActionClient.exit({confirmMsg: null});
        }

        if(IHS_REQUEST_MAIN.isStrategicConsultationActivity()){
            if (!IHS_REQUEST_MAIN.isHRSpecialist()) {
                if(-1===$('#pv_specialist').val().indexOf(currentUserMemberId)){
                    // remove tab3 (HR Only)
                    _.remove(activityList, function(act){
                        if(act.name === Activity_StrategicConsultation){
                            _.pull(act.tabs, TABID_HR_ONLY);
                        }
                    });
                }
            }
        }

        BFActivityOption.init(activityList);

        IHS_REQUEST_MAIN.initBasedOnActivity();
        $('#formTitle').text(BFActivityOption.getActivityName());

        if (BFUtility.isReadOnly() === true) {
            var activityName = BFActivityOption.getActivityName();
            var readonlyTabs = [TABID_REQUEST, TABID_JOB_ANNOUNCEMENT, TABID_DOCUMENTS, TABID_HR_ONLY, TABID_APPROVALS, TABID_TRACK_REQUEST, TABID_CLOSE_OUT];
            BFActivityOption.setReadOnlyTabList(activityName, readonlyTabs);
        }

        LookupManager.init();
        TabManager.initTab(IHS_REQUEST_MAIN.tabList, function(){
            var data = $('#h_formData').val();
            IHS_REQUEST_MAIN.loadForm(data);
        });

        $(document).on('HHS_ALL_TAB_LOADED', IHS_REQUEST_MAIN.onAllTabLoaded);

        $('#button_SaveWorkitem').on('click', function(){IHS_REQUEST_MAIN.saveForm('saveDraft');});
        $('#button_Previous').off('click').click(function (e) {
            TabManager.loadPreviousTab();
        });
        $('#button_Next').off('click').click(function (e) {
			// validate first tab
			if (IHS_REQUEST_MAIN.isHRActionRequestActivity() || IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()) {
				IHS_REQUEST_MAIN.getTab().validationOnLoadNextTab = true;
			}

            var customValidationResult = true;
            if (IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
                customValidationResult = IHS_REQUEST_MAIN.validateCareerLadderPosition();
                if(customValidationResult){
                    customValidationResult = IHS_REQUEST_MAIN.validateClassifiedPDandGrades();
                }
            }

            if (customValidationResult) {
                TabManager.loadNextTab();
            }
        });

        $('#button_sendMail').off('click').click(function (e) {
            IHS_REQUEST_MAIN.sendEmail();
        });
		
        $('#button_returnToHR').off('click').click(function (e) {
            completeWorkitem('Return', false);
        });
		
        $('#button_returnToClassification').off('click').click(function (e) {
            completeWorkitem('Return', false);
        });
		
        $('#button_exchange_hr').off('click').click(function (e) {
			IHS_REQUEST_MAIN.returnToHRfromManager(Status_HRSPendingStrategicConsultation);
        });
		
        $('#button_exchange_mgr').off('click').click(function (e) {
            IHS_REQUEST_MAIN.setStatus(Status_HMPendingStrategicConsultation);
			$('#consultant').val($('#hiringManager').val().substring(3));
			FormState.doActionNoRender(StateAction.changeText('consultant', $('#hiringManager').val().substring(3)));
            completeWorkitem('Submit', false);
        });
		
        $('#button_submitToHR').off('click').click(function (e) {
            // Form validation
            var showAlertMsg = true;
            var isValidForm = true;
            var watchTabId = null;
            var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
            for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                watchTabId = activeTabs[tabIndex];
                isValidForm = TabManager.validateTab(watchTabId);
                if (isValidForm === false) {
                    break;
                }
            }

            if (isValidForm) {
				if ($('#concurHiringManager').prop('checked')) {
					IHS_REQUEST_MAIN.returnToHRfromManager(Status_HRSPendingStrategicConsultation);
				} else {
                    bootbox.alert('Please check the approvals checkbox before submit.');
				}
            } else {
                if (showAlertMsg) {
                    bootbox.alert('Please fill in all the required fields before submit.');
                }
                $('#' + TabManager.getAnchorID(watchTabId)).click();
            }
        });
		
        $('#button_PDF').off('click').click(function (e) {
            // Form validation
            var alertMsg = undefined;
            var isValidForm = true;
            var watchTabId = null;
            var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
            for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                watchTabId = activeTabs[tabIndex];
                isValidForm = TabManager.validateTab(watchTabId);
                if (isValidForm === false) {
                    break;
                }
            }

            if(isValidForm){
                var approveHRSpecialist = FormState.getState('approveHRSpecialist');
                var concurHiringManager = FormState.getState('concurHiringManager');
                if(!((concurHiringManager && isTrue(concurHiringManager.value))&&(approveHRSpecialist && isTrue(approveHRSpecialist.value)))){
                    isValidForm = false;
                    watchTabId = TABID_APPROVALS;
                    alertMsg = 'Please check the approvals checkbox before submit.';
                }

                if(isValidForm){
                    // Check IHS Recruitment Worksheet file type attached.
                    var foundWorksheet = false;
                    $.each(basicWIHActionClient.getAttachments(), function(i, file){
                        if(file.category && file.category.LABEL && "IHS Recruitment Worksheet" === file.category.LABEL){
                            foundWorksheet = true;
                            return false;
                        }
                    });

                    if(!foundWorksheet){
                        isValidForm = false;
                        watchTabId = TABID_DOCUMENTS;
                        alertMsg = 'Please generate IHS Recruitment Worksheet before submit.';
						//
						// // check manager and specialist signatures
						// var concurHiringManager = FormState.getState('concurHiringManager');
						// if(concurHiringManager && isTrue(concurHiringManager.value)){
						// 	watchTabId = TABID_DOCUMENTS;
						// 	alertMsg = 'Please generate IHS Recruitment Worksheet before submit.';
						// } else {
						// 	alertMsg = 'Please obtain manager approval before complete.';
						// }
                    }
                }
            }else{
                alertMsg = 'Please fill in all the required fields before submit.';
            }

            if (isValidForm) {
				completeWorkitem('Close', false);
            } else {
                if (alertMsg) {
                    bootbox.alert(alertMsg);
                }
                $('#' + TabManager.getAnchorID(watchTabId)).click();
            }
        });

        $('#button_CancelWorkitem').off('click').click(function (e) {
            if (Status_Draft === IHS_REQUEST_MAIN.getStatus()) {
                completeWorkitem('Cancel', false);
            } else {
                IHS_REQUEST_MAIN.confirmCancel();
            }
        });

        $('#button_forward').off('click').click(function (e) {
            IHS_REQUEST_MAIN.forward();
        });

        $('#button_SubmitWorkitem').off('click').click(function (e) {
            // Form validation
            var showAlertMsg = true;
            var isValidForm = true;
            var watchTabId = null;
            var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
            for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                watchTabId = activeTabs[tabIndex];
                isValidForm = TabManager.validateTab(watchTabId);
                if (isValidForm === false) {
                    break;
                }
            }

            if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
                var gradeSelection = $('#selectGrades').val();
                var gradeList = [];
                if (gradeSelection != '') {
                    var error = false;
                    gradeList = gradeSelection.split(',');
                    gradeList.forEach(function (value) {
                        if (value.indexOf(':') == -1) {
                            error = true;
                            $('#' + value).show();
                        }
                    });
                    if (error) {
                        watchTabId = TABID_REQUEST;
                        isValidForm = false;
                    }
                }

                if (isValidForm) {
                    watchTabId = TABID_REQUEST;
                    isValidForm = IHS_REQUEST_MAIN.validateCareerLadderPosition();
                    if(isValidForm){
                        isValidForm = IHS_REQUEST_MAIN.validateClassifiedPDandGrades();
                    }
                    showAlertMsg = isValidForm;
                }
            }

            if (isValidForm) {
                if (IHS_REQUEST_MAIN.isClassificationActivity()) {
                    IHS_REQUEST_MAIN.submitForClassification();
                } else if(IHS_REQUEST_MAIN.isUpdateClassificationActivity()){
                    var consultant = $('#consultant').val();
                    var HRManager = $('#hiringManager').val();
                    var requestStatus;
                    if(-1<HRManager.indexOf(consultant)){
                        requestStatus = Status_HMPendingStrategicConsultation;
                    }else{
                        requestStatus = Status_HRSPendingStrategicConsultation;
                    }

                    IHS_REQUEST_MAIN.setStatus(requestStatus);

                    completeWorkitem('Submit', false);
                } else {
                    completeWorkitem('Submit', false);
                }
            } else {
                if (showAlertMsg) {
                    bootbox.alert('Please fill in all the required fields before submit.');
                }
                $('#' + TabManager.getAnchorID(watchTabId)).click();
            }
        });
        $('#button_ExitWIH').off('click').click(function (e) {
            IHS_REQUEST_MAIN.confirmClose();
        });

        $('#button_SendBack').off('click').click(function (e) {
            IHS_REQUEST_MAIN.confirmSendBack();
        });

        $('#button_SubmitOnMatchEHRPID').off('click').click(function (e) {
            IHS_REQUEST_MAIN.submitOnMatchEHRPID();
        });

        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString); // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = BFUtility.getDateString(false, 'mm/dd/yyyy', newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        // // Request Number to process ID
        var requestNumber = $('#h_procid').val();
        $('#requestNumber').text(requestNumber);
        var requestStatus = IHS_REQUEST_MAIN.getStatus();
        if (requestStatus) {
            $('#output_requestStatus').text(requestStatus);
        }

        // set focus on the current tab
		$('#main_buttons_layout_group').css('visibility', 'visible');

        $('a.selectedTab').focus();
        //$('#button_SaveWorkitem').on('click',IHS_REQUEST_MAIN.saveDraft);
    },
    saveDraft: function () {
        var xml = FormState.getFinalStateXML();
        $('#h_formData').val(xml);
        basicWIHActionClient.setWIHOption('requestAction', 'saveDraft');
        ajaxSubmission("actionWorkitem.do");
    },
    validateCareerLadderPosition: function () {
        var gradeSelection = $('#selectGrades').val();
        var gradeList = [];
        if (gradeSelection != '') {
            gradeList = gradeSelection.split(',');
        }

        // Check career ladder position and grade
        var careerLadder = $('input[name="careerLadder"]:checked').val();
        if (careerLadder === 'Y' && gradeList.length <= 1) {
            bootbox.alert('You must select more than 1 grade because the Career Ladder Position has been marked as "Yes".');
            return false;
        } else {
            return true;
        }
    },
    getSelectedGrades: function(){
        var selectGrades = $('#selectGrades').val();
        var gradeList = [];
        if (selectGrades != '') {
            gradeList = selectGrades.split(',');
        }
        return gradeList;
    },
    validateClassifiedPDandGrades: function () {
        var careerLadder = $('input[name="classifiedPDRes"]:checked').val();
        if (careerLadder === 'Y') {
            var gradeList = IHS_REQUEST_MAIN.getSelectedGrades();
            if(gradeList.length === 0){
                bootbox.alert('Please select a grade for the classified PD.');
                return false;
            }
        }

        return true;
    },
    submitOnMatchEHRPID: function() {
        var ehrpStatus = $('#pv_ehrpStatus').val();
        if(ehrpStatus === '010'){
            completeWorkitem('Approved', true);
        }else if(ehrpStatus === '120'){
            completeWorkitem('Disapproved', true);
        }else{
            completeWorkitem('Disapproved', true);
            // bootbox.alert("Unknown EHRP Status: " + ehrpStatus + "\nPlease contact administrator.");
        }
    },
    confirmSendBack: function () {
        bootbox.confirm({
            title: '',
            message: 'Would you like to send back?',
            callback: function (result) {
                if (result) {
                    $('#interface_job_requisitionNumber').val('');
                    FormState.doActionNoRender(StateAction.reset('interface_job_requisitionNumber'));
                    completeWorkitem('Send Back', false);
                }
            }
        });
    },
    confirmClose: function () {
        bootbox.dialog({
            message: '<p class="bootbox-body">Would you like to save your entries before closing?</p>',
            onEscape: true,
            buttons: [{
                    label: 'No',
                    callback: function () {
                        basicWIHActionClient.exit({confirmMsg: null});
                    }
                },
                {
                    label: 'Yes, save and close',
                    className: 'btn-primary',
                    callback: function () {
                        $('#WIH_exit_requested').val(true);
                        IHS_REQUEST_MAIN.saveForm('exit');
                    }
                }]
        });

    },
    confirmCancel: function () {
        var cancelReasons = LookupManager.findByLTYPE('CancellationReason');
        var selectHTML = '<select class="form-control" id="cancelReason" name="cancelReason"><option value="">Select one</option>';
        for (var i = 0; i < cancelReasons.length; i++) {
            selectHTML += '<option value="' + cancelReasons[i].NAME + '">' + cancelReasons[i].NAME + '</option>';
        }
        selectHTML += '</select>';

        //user must confirm closing
        bootbox.confirm({
            title: 'What is the reason for canceling this request?',
            message: selectHTML,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#cancelReason').val()) {
                        bootbox.alert('Please select a cancellation reason');
                    } else {
                        $('#pv_cancelReason').val($('#cancelReason').val());
                        completeWorkitem('Cancel', false);
                    }
                }
            }
        });
    },
    forward: function () {
        var selectHTML = '<select class="form-control" id="forwardUser" name="forwardUser">';
        $("#HRClassifier > option").each(function () {
            if ($("#HRClassifier").val() !== this.value) {
                selectHTML += '<option value="' + this.value + '">' + this.text + '</option>';
            }
        });
        selectHTML += '</select>';

        //user must confirm closing
        bootbox.confirm({
            title: 'Please identify an HR Classifier',
            message: selectHTML,
            buttons: {
                confirm: {
                    label: 'Forward',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#forwardUser').val()) {
                        bootbox.alert('Please identify an HR Classifier to forward this action to');
                    } else {
                        // set HRClassifier value and text
                        FormState.doActionNoRender(StateAction.changeSelect('HRClassifier', $('#forwardUser').val(), $('#forwardUser option:selected').text()));
                        completeWorkitem('Forward', false);
                    }
                }
            }
        });
    },
    sendEmail: function () {
        var comments = $('#classificationComments').val();
        if(83<=comments.length){
            comments = comments.substring(0, 80) + "...";
        }
        var selectHTML = '<textarea class="form-control" rows="16" id="emailContent" name="emailContent" maxlength="500">';
        selectHTML += 'The HR Specialist has reviewed the proposed position and has determined that more information is needed to proceed with the evaluation. Please see the comments below for more information:';
        selectHTML += '\n\n';
        selectHTML += 'Classification Status: ' + $('#classificationStat').val()
        selectHTML += '\nClassification Comments: ' + comments;
        selectHTML += '\n\nThe recruit action will remain in "Pending More information" status until all items have been received.';
        selectHTML += '\n\nThank you.';
        selectHTML += '</textarea>';

        //user must confirm closing
        bootbox.confirm({
            title: 'Send Email to HR Manager',
            message: selectHTML,
            buttons: {
                confirm: {
                    label: 'Send',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#emailContent').val()) {
                        bootbox.alert('Please enter email contents.');
                    } else {
                        var workitemContext = basicWIHActionClient.getWorkitemContext();
                        var ccid = workitemContext.Process.Initiator;
                        $.ajax({
                            url: '/bizflowwebmaker/ihs_AutoCompleteService/SendMail.do',
                            method: 'POST',
                            data: {
                                procid: $('#h_procid').val(),
                                senderid: '[U]' + currentUserMemberId,
                                recipientid: '[U]' + $('#managerID').val(),
                                ccid: '[U]' + ccid,
                                requestid: IHS_REQUEST_MAIN.uuid(),
                                body: $('#emailContent').val()
                            },
                            dataType: 'xml',
                            cache: false,
                            success: function (xmlResponse) {
                                if(0<$('status[outcome=fail]', xmlResponse).length){
                                    bootbox.alert(SYSTEM_ERROR_MESSAGE);
                                    BFLog.log('ERROR', $('status[outcome=fail] message', xmlResponse).html());
                                }else{
                                    HHS_TAB1.loadMoreInformationRequest();
                                    IHS_REQUEST_MAIN.setStatus(Status_PendingMoreInformation);
                                    bootbox.alert('Your email has been successfully sent.');
                                }
                            }
                        });
                    }
                }
            }
        });
    },
    uuid: function () {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        })
    },
    dialogSelectHRSpecialist: null,
    submitForClassification: function () {
        IHS_REQUEST_MAIN.dialogSelectHRSpecialist = bootbox.confirm({
            title: 'Who would you like to route this request to?',
            message: '<select class="form-control" id="selectHRSpecialist" name="selectHRSpecialist"></select>',
            buttons: {
                confirm: {
                    label: 'Submit',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#selectHRSpecialist').val()) {
                        bootbox.alert('Please select someone to receive this request.');
                    } else {
						// set next request status
						if (-1<$('#hiringManager').val().indexOf($('#selectHRSpecialist').val())) {
							FormState.doActionNoRender(StateAction.changeText('consultant', $('#selectHRSpecialist').val()));
                            IHS_REQUEST_MAIN.setStatus(Status_HMPendingStrategicConsultation);
						} else {
							// set HRSpecialist value and text
							FormState.doActionNoRender(StateAction.changeText('managerID', $('#selectHRSpecialist').val()));
							FormState.doActionNoRender(StateAction.changeText('HRSpecialist', $('#selectHRSpecialist').val()));
							FormState.doActionNoRender(StateAction.changeText('consultant', $('#selectHRSpecialist').val()));

                            IHS_REQUEST_MAIN.setStatus(Status_HRSPendingStrategicConsultation);
						}
						
                        completeWorkitem('Submit', false, true);
                    }
                }
            }
        });

        IHS_REQUEST_MAIN.dialogSelectHRSpecialist.init(function () {
            $.ajax({
                url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchHRSpecialist.do',
                data: {searchString: $('#adminCode').val(), managerId: $('#managerID').val()},
                dataType: 'xml',
                cache: false,
                success: function (xmlResponse) {
                    var data = $('record', xmlResponse).map(function () {
                        return {
                            value: '',
                            memberid: $('MEMBERID', this).text(),
                            name: $('NAME', this).text(),
                            email: $('EMAIL', this).text()
                        };
                    }).get();
                    if (data.length > 0) {
                        $('#selectHRSpecialist').html('');
                        // var initiator = basicWIHActionClient.getWorkitemContext().Process.Initiator;
                        var managerID = $('#managerID').val();
                        data.forEach(function (value) {
                            var selected = value.memberid === managerID ? ' selected ' : ' ';
                            $('#selectHRSpecialist').append('<option value="' + value.memberid + '" ' + selected + '>' + value.name + ' (' + value.email + ')</option>');
                        });
                    }
                }
            });
        });
    },
	returnToHRfromManager: function (newRequestStatus) {
        IHS_REQUEST_MAIN.dialogSelectHRSpecialist = bootbox.confirm({
            title: 'Who would you like to route this request to?',
            message: '<select class="form-control" id="selectHRSpecialist" name="selectHRSpecialist"></select>',
            buttons: {
                confirm: {
                    label: 'Submit',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#selectHRSpecialist').val()) {
                        bootbox.alert('Please select someone to receive this request.');
                    } else {
                        IHS_REQUEST_MAIN.setStatus(newRequestStatus);
                        FormState.doActionNoRender(StateAction.changeText('HRSpecialist', $('#selectHRSpecialist').val()));
                        FormState.doActionNoRender(StateAction.changeText('consultant', $('#selectHRSpecialist').val()));
                        completeWorkitem('Submit', false, true);
                    }
                }
            }
        });

        IHS_REQUEST_MAIN.dialogSelectHRSpecialist.init(function () {
            $.ajax({
                url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchHRSpecialist.do',
                data: {searchString: $('#adminCode').val(), managerId: $('#managerID').val()},
                dataType: 'xml',
                cache: false,
                success: function (xmlResponse) {
                    var data = $('record', xmlResponse).map(function () {
                        return {
                            value: '',
                            memberid: $('MEMBERID', this).text(),
                            name: $('NAME', this).text(),
                            email: $('EMAIL', this).text()
                        };
                    }).get();
                    if (data.length > 0) {
                        $('#selectHRSpecialist').html('');
                        var currentSpecialist = $('#HRSpecialist').val();
                        data.forEach(function (value) {
                            if(IHS_REQUEST_MAIN.isStrategicConsultationActivity()){
                                if(value.memberid === currentUserMemberId){
                                    return;
                                }
                            }
                            var selected = value.memberid === currentSpecialist ? ' selected ' : ' ';
                            $('#selectHRSpecialist').append('<option value="' + value.memberid + '" ' + selected + '>' + value.name + ' (' + value.email + ')</option>');
                        });
                    }
                }
            });
        });
    },
    getTab: function () {
        var tabID = TabManager.getSelectedTabID();
        var selectedTabs = IHS_REQUEST_MAIN.tabList.filter(function (node, index) {
            return node.id === tabID;
        });
        var foundTab = null;
        if (selectedTabs.length === 1) {
            foundTab = selectedTabs[0];
        }
        return foundTab;
    },

    extraCoordinatorForReadOnlyTab: function(id) {
        $('#'+id+' .deleteAction, #'+id+' .selectedValueCaption').remove();
        $('#'+id+' .selectedValue').addClass('selectedValueReadOnly');
    },
    disableTabContents: function(tabs) {
        $.each(tabs, function(i,tabId){
            IHS_REQUEST_MAIN.disableAllElements(tabId);
        });
    },
    undoDisableTabContents: function(tabs) {
        $.each(tabs, function(i,tabId){
            IHS_REQUEST_MAIN.undoDisableAllElements(tabId);
        });
    },
    disableAllElements: function(id){
        $('#'+id+' input, #'+id+' select, #'+id+' textarea, #'+id+' button').each(function(i,v){
            var $v = $(v);
            if(!$v.is('[disabled]')){
                $v.attr('__disabled', 'disabled').attr('disabled', 'disabled');
            }
        });
        $('#'+id+' .deleteAction, #'+id+' .datePickerIcon').attr('__disabled', 'disabled').hide();
    },
    undoDisableAllElements: function(id){
        $('#'+id+' input, #'+id+' select, #'+id+' textarea, #'+id+' button').each(function(i,v){
            var $v = $(v);
            if($v.is('[__disabled]')){
                $v.removeAttr('__disabled').removeAttr('disabled');
            }
        });
        $('#'+id+' .deleteAction[__disabled], #'+id+' .datePickerIcon[__disabled]').removeAttr('__disabled').show();
    },
    setStatus: function(status){
        $('#pv_requestStatus').val(status);
        FormState.doActionNoRender(StateAction.changeText('pv_requestStatus', status));
        $('#output_requestStatus').text(status);
    },
    getStatus: function(){
        return $('#pv_requestStatus').val();
    }
};

$(document).ready(function(){
    try{
        IHS_REQUEST_MAIN.init();
    }catch(e){
        bootbox.alert({
            message: SYSTEM_ERROR_MESSAGE,
            callback: function(){
                basicWIHActionClient.exit({confirmMsg: null});
            }
        });
        BFLog.log('ERROR', e);
    }
});

/**
 * Adding options to a select tag
 * @param field field ID
 * @param items options
 * @param defaultValue default value
 * @param config {firstItem: {value:'', text:'Select one'} }
 */
function populateSelectOptions(field, items, defaultValue, config) {
    var $f = $('#' + field).html('');
    if (config.firstItem) {
        $f.append($('<option>', {value: config.firstItem.value, text: config.firstItem.text}));
    }
    $.each(items, function (i, item) {
        $f.append($('<option>', {value: item.value, text: item.text, selected: (defaultValue === item.value)}));
    });
    return $f;
}

/**
 * Submit form data and complete workitem. Workitem Handler closed when it completed successfully.
 * @param responseName (Optional) the response name should be one of the available response names on current activity.
 */
function completeWorkitem(responseName, formValidation){
    var xml = FormState.getFinalStateXML();
    $('#h_formData').val(xml);

    if(typeof responseName !== 'undefined'){
        basicWIHActionClient.setResponseByName(responseName);
    }
    basicWIHActionClient.setWIHOption('requestAction', 'complete');
    if(!basicWIHActionClient.getWIHOption('formSaved')){
        basicWIHActionClient.setWait();
        ajaxSubmission('actionWorkitem.do?requestAction='+responseName, 'all', undefined, formValidation);
    }
}

/**
 * This function to be called when the partial page is loaded.
 */
function onLoadResultActionWorkitem(){
    var errorMessage = $('#ResultActionWorkitemtErrorMessage').val();
    if(errorMessage && 0<errorMessage.length){
        BFLog.log('ERROR', errorMessage);
        bootbox.alert(SYSTEM_ERROR_MESSAGE);
    }else{
        basicWIHActionClient.setWIHOption('formSaved', true);
        var action = basicWIHActionClient.getWIHOption('requestAction');
        if(action === 'complete'){
            basicWIHActionClient.setContinue();
            basicWIHActionClient.setWIHOption('closeWihOnComplete', true);
            basicWIHActionClient.setWIHOption('completionWindow', false);
            basicWIHActionClient.complete();
        } else if(action === 'tabChange') {

        } else if(action === 'saveDraft') {
            basicWIHActionClient.notify('Your data has been successfully saved.', 3000);
        } else if(action === 'exit') {
            basicWIHActionClient.exit({confirmMsg: null});
        }

        basicWIHActionClient.setWIHOption('formSaved', undefined);
        basicWIHActionClient.setWIHOption('requestAction', undefined);
    }

    BFUtility.greyOutScreen(false);
}

/**
 * Submit form data via ajax
 * @param action WebMaker action name
 * @param sourceGroup (Optional) indicates whether to send all the data on the page or just the data within a particular group.
 * @param targetGroup (Optional) indicates which group to place the results into.
 * @param validate (Optional) indicates whether to validate first. default: false
 * @example
 * // Submit all data without form validation on the page, and result page is not showing.
 * ajaxSubmission('actionWorkitem.do');
 * // Form validation before submit all data on the page, and result page is not showing.
 * ajaxSubmission('actionWorkitem.do', 'all', undefined, true);
 * // Form validation before submit data within 'input_layout_group', and results showing to 'output_layout_group'.
 * ajaxSubmission('actionWorkitem.do', 'input_layout_group', 'output_layout_group', true);
 */
function ajaxSubmission(action, sourceGroup, targetGroup, validate) {
    if (window.location.pathname.indexOf('bizflowwebmaker') > -1 && action.indexOf('/') === 0) {
        action = '/bizflowwebmaker' + action;
    }
    var objAction = {
        name: 'Action',
        option: 'Action',
        value: action
    };
    var objSourceGroup = null;
    if (typeof sourceGroup === 'undefined' || null === sourceGroup || '' === sourceGroup
        || 'all' === sourceGroup || 'ALL' === sourceGroup) {
        objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
    } else {
        objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
    }

    var partialPageContainerId = '_hidden_partial_page_container_';
    if(typeof targetGroup === 'undefined'){
        var partialPageContainer = document.createElement('div');
        if(document.getElementById(partialPageContainerId) === null){
            partialPageContainer.id = partialPageContainerId;
            partialPageContainer.style.display = "none";
            document.getElementsByTagName('body')[0].appendChild(partialPageContainer);
        }
    }else{
        partialPageContainerId = targetGroup;
    }

    var objTargetGroup = {
        name: 'TargetGroup',
        option: 'PageGroup',
        value: partialPageContainerId
    };
    var objValidate = {
        name: 'Validate',
        option: 'Static',
        value: validate?validate:false
    };
    hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, {value: targetGroup});
}

function isTrue(val){
    if(typeof val === 'boolean'){
        return val;
    } else if(typeof val === 'string' && val.toLowerCase() === 'true') {
        return true;
    }
    return false;
}
function unique(array) {
    return $.grep(array, function(el, index) {
        return index == $.inArray(el, array);
    });
}

$( document ).ajaxError(function( event, request, settings, thrownError ) {
    bootbox.alert(SYSTEM_ERROR_MESSAGE);
    BFLog.log('ERROR', thrownError);
});