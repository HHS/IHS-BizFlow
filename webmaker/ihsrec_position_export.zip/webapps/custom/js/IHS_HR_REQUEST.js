var HHS_TAB1 = {
    initialized: false,
    activityName: '',
    init: function () {
        //elements to hide or show in classification
        var hideListAR = ['classificationStatus', 'organizationTitleGroup', 'employingOfficeLocGroup', 'ClassificationSet', 'flsaDeterminationGroup', 'initialJobCodeGroup', 'classifiedPDQ_2', 'classificationComments', 'appointmentTypeGroup', 'tempPositionReasonGroup', 'consultationPDQ_2', 'consultationSet'];
        var hideListCL = ['classifiedPDQ', 'actionTypeGroup', 'classifierGroup', 'classifiedPDTxt', 'basedTxt', 'appointmentTypeGroup', 'tempPositionReasonGroup', 'consultationPDQ_2', 'consultationSet'];
        var hideListSC = ['classifiedPDQ', 'numberSection', 'actionTypeGroup', 'classifierGroup', 'classifiedPDTxt', 'basedTxt', 'classificationStatus', 'organizationTitleGroup', 'ClassificationSet', 'initialJobCodeGroup', 'careerLadderGroup'];
        var activity = BFActivityOption.getActivityName();
        HHS_TAB1.activityName = activity;
        if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
            hideListCL.forEach(function (val) {
                hyf.util.hideComponent(val);
            });
            hyf.util.showComponent('classificationStatus');
            hyf.util.showComponent('organizationTitleGroup');
            hyf.util.showComponent('employingOfficeLocGroup');

            hyf.util.setMandatoryConstraint('jobCode_2', true);
            hyf.util.setMandatoryConstraint('grade', true);
            hyf.util.setMandatoryConstraint('positionNumber', true);
            for (var fieldGroup = 2; fieldGroup <= 5; fieldGroup++) {
                hyf.util.setMandatoryConstraint('positionNumber_' + fieldGroup, true);
            }
            hyf.util.disableComponent('comments');
            hyf.util.hideComponent('initialJobCodeGroup');
            //HHS_TAB1.setWhoToContactAutoComplete('reportTo');
		} else if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
            hideListSC.forEach(function (val) {
                hyf.util.hideComponent(val);
            });

            hyf.util.disableComponent('positionTitle');
            hyf.util.disableComponent('payPlan');
            hyf.util.disableComponent('adminCode');
            hyf.util.disableComponent('jobCode_2');
            hyf.util.disableComponent('empOfficeLoc');
            hyf.util.disableComponent('comments');
            hyf.util.disableComponent('classificationComments');
            hyf.util.disableComponent('positionNumber', true);
            for (var fieldGroup = 2; fieldGroup <= 5; fieldGroup++) {
                hyf.util.disableComponent('positionNumber_' + fieldGroup, true);
            }
            hyf.util.disableComponent('viceName', true);
            for (var fieldGroup = 2; fieldGroup <= 5; fieldGroup++) {
                hyf.util.disableComponent('viceName_' + fieldGroup, true);
            }
            hyf.util.disableComponent('positionVacatedDate', true);
            for (var fieldGroup = 2; fieldGroup <= 5; fieldGroup++) {
                hyf.util.disableComponent('positionVacatedDate_' + fieldGroup, true);
            }
			
            $('#occupationalSeries_container, #grade_container, #dutyStation_container').hide();
            $('#occupationalSeries_container .deleteAction, #occupationalSeries_container .selectedValueCaption').remove();
            $('#occupationalSeries_container .selectedValue').addClass('selectedValueReadOnly');
            $('#grade_container .deleteAction, #grade_container .selectedValueCaption').remove();
            $('#grade_container .selectedValue').addClass('selectedValueReadOnly');
            $('#dutyStation_container .deleteAction, #dutyStation_container .selectedValueCaption').remove();
            $('#dutyStation_container .selectedValue').addClass('selectedValueReadOnly');

            hyf.util.hideComponent('tempPositionReasonGroup');
        } else if(IHS_REQUEST_MAIN.isHRActionRequestActivity()){
            hideListAR.forEach(function (val) {
                hyf.util.hideComponent(val);
            });
            hyf.util.hideComponent('classificationJobCodeGroup');
            hyf.util.showComponent('initialJobCodeGroup');

            hyf.util.setMandatoryConstraint('occupationalSeries', false);


            $('#button_copy').off('click').click(function (e) {
                e.preventDefault();
                HHS_TAB1.copyDialog = bootbox.dialog({
                    title: "Please enter the tracking number to be copied",
                    message: '<div style="margin:auto;width:50%">' +
                                '<input class="form-control textbox" id="copyTrackingNumber" name="copyTrackingNumber" title="Enter the tracking number to be copied" type="text">' +
                             '</div>',
                    buttons: [{
                        label: 'Cancel'
                    },{
                        label: 'Copy Request',
                        callback: function(){
                            var copyTrackingNumber = $('#copyTrackingNumber').val();
                            if(0<copyTrackingNumber.length){
                                HHS_TAB1.copyByTrackingNumber(copyTrackingNumber);
                            }else{
                                bootbox.alert('Please enter the tracking number.', function(){$('#button_copy').click();});
                            }
                        }
                    }]
                });

                HHS_TAB1.copyDialog.init(function(){
                    setTimeout(function(){$('#copyTrackingNumber').focus();}, 500);
                });
            });

        } else if(IHS_REQUEST_MAIN.isUpdateHRActionRequestActivity()){
            hideListAR.forEach(function (val) {
                hyf.util.hideComponent(val);
            });
        } else if(IHS_REQUEST_MAIN.isMatchEHRPIDActivity()){
            hideListAR.forEach(function (val) {
                hyf.util.hideComponent(val);
            });
        } else if(IHS_REQUEST_MAIN.isFillPositionActivity()){
            //
            hyf.util.hideComponent('jobCode');
        }
        hyf.calendar.setDateConstraint('flsaCompleteDate', 'Maximum', 'Today');
        hyf.calendar.setDateConstraint('posRiskComplete', 'Maximum', 'Today');
        hyf.calendar.setDateConstraint('posDescCompleteDate', 'Maximum', 'Today');
        hyf.calendar.setDateConstraint('evalStatement', 'Maximum', 'Today');
        $('#flsaCompleteDate, #posRiskComplete, #posDescCompleteDate, #evalStatement').change(function(e) {
            var fieldName = e.currentTarget.name;
            var newValue = e.target.value;
            if(0<newValue.length && !hyf.validation.validateField(fieldName)){
                $(e.target).focus();
            }
        });
        HHS_TAB1.loadMoreInformationRequest();
    },
    render: function () {
        var adminCode = FormState.getState('adminCode');
        var whoToContact = FormState.getState('whoToContact');
        var requestType = FormState.getState('actionType');
        var classifiedPDRes = FormState.getState('classifiedPDRes');
        var viceName = FormState.getState('viceName');
        var payPlan = FormState.getState('payPlan');
        var numbOfVacancies = FormState.getState('numberOfVacancies');
        var grade = FormState.getState('grade');
        var appointmentType = FormState.getState('appointmentType');
        var hiringPlan = FormState.getState('hiringPlan');
        var usingSamePD = FormState.getState('usingSamePDs');
        var classifier = FormState.getState('HRClassifier');
        var jobCode = FormState.getState('jobCode');
		
		if (!HHS_TAB1.initialized) {
            var seriesSplit = FormState.getState('series');
            if (seriesSplit && seriesSplit.dirty && seriesSplit.value.length) {
                seriesSplit = seriesSplit.value.indexOf(',') ? seriesSplit.value.split(',') : [seriesSplit.value];
				
				if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					HHS_TAB1.populateFields(seriesSplit, 'series', 'selectedOccSeries', ',', true);
				} else {
					HHS_TAB1.populateFields(seriesSplit, 'series', 'selectedOccSeries', ',', false);
				}
            }
			
            var dutyLoc = FormState.getState('dutyLoc');
            if (dutyLoc && dutyLoc.dirty && dutyLoc.value.length) {
                dutyLoc = dutyLoc.value.indexOf(';') ? dutyLoc.value.split(';') : [dutyLoc.value];

				if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					HHS_TAB1.populateFields(dutyLoc, 'dutyLoc', 'selectedDutyStations', ';', true);
				} else {
					HHS_TAB1.populateFields(dutyLoc, 'dutyLoc', 'selectedDutyStations', ';', false);
				}
            }
			
            if (adminCode && adminCode.dirty && adminCode.value) {
                var selectedClassifier = '';
                if (classifier) {
                    selectedClassifier = classifier.value;
                }
                HHS_TAB1.getHRClassifier(adminCode.value, selectedClassifier);
            }
			
            var selectedGrade = FormState.getState('selectGrades');
            if (selectedGrade && selectedGrade.dirty && selectedGrade.value.length) {
                var selectedGrades = selectedGrade.value.indexOf(',') ? selectedGrade.value.split(',') : [selectedGrade.value];

				if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					HHS_TAB1.populateFields(selectedGrades, 'selectGrades', 'selectedGrades', ',', true);
					$('.flsaRadio').attr('disabled', true);
				} else {
					HHS_TAB1.populateFields(selectedGrades, 'selectGrades', 'selectedGrades', ',', false);
				}

                // if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity())
                {
                    if(0===selectedGrades.length){
                        $('#grade').attr('_required', 'true');
                    }else{
                        $('#grade').removeAttr('_required');
                    }
                }
            }
			
            var appTypes = FormState.getState('h_selectedAppointmentTypes');
            if (appTypes && appTypes.dirty && appTypes.value.length) {
				if(!IHS_REQUEST_MAIN.isUpdateClassificationActivity()){
                    var atArray = appTypes.value.split(',');
                    for (var k = 0; k < atArray.length; k++) {
                        if (atArray[k] == 'Temporary') {
                            hyf.util.showComponent('tempPositionReasonGroup');
                            break;
                        }
                    }
                }

                appTypes = appTypes.value.indexOf(',') ? appTypes.value.split(',') : [appTypes.value];

				if (!IHS_REQUEST_MAIN.isStrategicConsultationActivity() && !IHS_REQUEST_MAIN.isFillPositionActivity()) {
					HHS_TAB1.populateFields(appTypes, 'h_selectedAppointmentTypes', 'selectedAppTypes', ',', true);
				} else {
					HHS_TAB1.populateFields(appTypes, 'h_selectedAppointmentTypes', 'selectedAppTypes', ',', false);
				}
            }
			
            var hiringPlans = FormState.getState('h_selectedHiringPlan');

            if (hiringPlans && hiringPlans.dirty && hiringPlans.value.length) {
                var hiringPlansArray = hiringPlans.value.indexOf(';') ? hiringPlans.value.split(';') : [hiringPlans.value];

				if (!IHS_REQUEST_MAIN.isStrategicConsultationActivity() && !IHS_REQUEST_MAIN.isFillPositionActivity()) {
					HHS_TAB1.populateFields(hiringPlansArray, 'h_selectedHiringPlan', 'selectedHiringPlans', ';', true);
				} else {
					// if MP/ESEP Hiring Plan does not exist, hide additional hiring plan info
					if (hiringPlans.value.indexOf('MP/ESEP Hiring Plan') < 0) {
						hyf.util.hideComponent('additionalHPGroup');
					}

					HHS_TAB1.populateFields(hiringPlansArray, 'h_selectedHiringPlan', 'selectedHiringPlans', ';', false);
				}
            } else {
				hyf.util.hideComponent('additionalHPGroup');
			}

            if (!numbOfVacancies) {
                $('usingSamePDs').val('na');
                FormState.doActionNoRender(StateAction.changeRadio('usingSamePDs', 'na'));
                FormState.doActionNoRender(StateAction.changeSelect('numberOfVacancies', '1', '1'));
                for (var group = 2; group <= 5; group++) {
                    hyf.util.hideComponent('group_info_' + group);
                }
                $('#usingSamePDs1').parent().parent().hide();
                $('#usingSamePDs2').parent().parent().hide();
            }

            if (!whoToContact) {
                $('#whoToContact').val($('#initiatorName').text())
                $('#managerID').val($('#h_currentUserMemberID').val());
                FormState.doActionNoRender(StateAction.changeText('whoToContact', $('#initiatorName').text()));
                FormState.doActionNoRender(StateAction.changeText('managerID', $('#h_currentUserMemberID').val()));
            }

            if (payPlan && payPlan.dirty && payPlan.value !== 'Select one') {
                HHS_TAB1.getGrades(payPlan.value);
            }

            HHS_TAB1.setAdminCodeAutoComplete();
            HHS_TAB1.setWhoToContactAutoComplete('whoToContact');
            HHS_TAB1.setOccupationalSeriesAutoComplete();
            HHS_TAB1.setDutyLocationAutoComplete();
            HHS_TAB1.setEmployingOfficeLocationAutoComplete();
            HHS_TAB1.setReportToAutoComplete();

            HHS_TAB1.initialized = true;
        } else {
            // if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity())
            {
                if(0===IHS_REQUEST_MAIN.getSelectedGrades().length){
                    $('#grade').attr('_required', 'true');
                }else{
                    $('#grade').removeAttr('_required');
                }
            }

            if (payPlan && payPlan.dirty && payPlan.value !== 'Select one') {
                $('#grade').html('');
                var seriesValue = $('#series').val();
                var gradeValue = $('#selectGrades').val();
                if ((seriesValue && seriesValue.length > 0) || (gradeValue && gradeValue.length > 0)) {
                    bootbox.confirm({
                        message: 'Do you want to reset your values for Occupational Series and Grade(s)?',
                        buttons: {
                            confirm: {
                                label: 'Yes',
                                className: 'btn-success'
                            },
                            cancel: {
                                label: 'No',
                                className: 'btn-danger'
                            }
                        },
                        callback: function (result) {
                            if (result) {
                                //reset grades and series.
                                $('#series').val('');
                                $('#selectGrades').val('');
                                FormState.doActionNoRender(StateAction.reset('series'));
                                FormState.doActionNoRender(StateAction.reset('selectGrades'));
                                $('#selectedOccSeries > .selectedValueContainer').html('');
                                $('#selectedGrades > .selectedValueContainer').html('');

                                if(IHS_REQUEST_MAIN.isFillPositionActivity()){
                                    FormState.doActionNoRender(StateAction.reset('advertiseGrade'));
                                    FormState.doActionNoRender(StateAction.reset('targetGrade'));
                                    JOB_TAB.populateAdvertiseGradesAndTargetGrades();
                                }
                            }
                        }
                    });
                }
                HHS_TAB1.getGrades(payPlan.value);
            }

        }

        if (adminCode && adminCode.dirty && adminCode.value.length===0) {
            FormState.doActionNoRender(StateAction.reset('adminCodeDesc'));
        }

        if (requestType && requestType.dirty) {
            $('#requestType').text(requestType.value);
        }

        if (whoToContact && whoToContact.dirty) {
            $('#initiatorName').text(whoToContact.value);
            $('#whoToContact').val(whoToContact);
        }

        if (viceName && viceName.dirty) {
            hyf.util.setMandatoryConstraint('positionVacatedDate', (0<viceName.value.length));
        }
		
        for (var group = 2; group <= 5; group++) {
            var multiViceName = FormState.getState('viceName_' + group);
            if (multiViceName && multiViceName.dirty) {
                hyf.util.setMandatoryConstraint('positionVacatedDate_'+group, (0<multiViceName.value.length));
            }
        }

        if (numbOfVacancies && numbOfVacancies.dirty) {
            if (parseInt(numbOfVacancies.value) == 1) {
                $('usingSamePDs').val('na');
                FormState.doActionNoRender(StateAction.changeRadio('usingSamePDs', 'na'));
                if (IHS_REQUEST_MAIN.getStatus() === Status_Draft) {//check if status is draft, if yes, hide 2-5
                    FormState.doActionNoRender(StateAction.changeSelect('numberOfVacancies', '1', '1'));
                    for (var group = 2; group <= 5; group++) {
                        hyf.util.hideComponent('group_info_' + group);
                    }
                }
                $('#usingSamePDs1').parent().parent().hide();
                $('#usingSamePDs2').parent().parent().hide();
                $('#usingSamePDs3').parent().parent().show();
            } else {
				if ('Y' != usingSamePD.value) {
					$('#usingSamePDs3').prop('checked', false);
					FormState.doActionNoRender(StateAction.changeRadio('usingSamePDs', ''));
				}

                $('#usingSamePDs1').parent().parent().show();
                $('#usingSamePDs2').parent().parent().show();
                $('#usingSamePDs3').parent().parent().hide();
            }


            for (var group = 1; group <= parseInt(numbOfVacancies.value); group++) {
                hyf.util.showComponent('group_info_' + group);
            }
            if (parseInt(numbOfVacancies.value) <= 5) {
                var group = parseInt(numbOfVacancies.value) + 1;
                for (; group <= 5; group++) {
                    hyf.util.hideComponent('group_info_' + group);
                    $('#positionNumber_' + group).val('');
                    $('#positionVacatedDate_' + group).val('');
                    $('#viceName_' + group).val('');
                    FormState.doActionNoRender(StateAction.reset('positionNumber_' + group));
                    FormState.doActionNoRender(StateAction.changeDate('positionVacatedDate_' + group, ''));
					hyf.util.setMandatoryConstraint('positionVacatedDate_'+group);
                    FormState.doActionNoRender(StateAction.reset('viceName_' + group));
                }
            }
        }
        if (usingSamePD && usingSamePD.dirty) {
            if (usingSamePD.value === 'N') {
                $('#usingSamePDs2').prop('checked', false);
                FormState.doActionNoRender(StateAction.changeRadio('usingSamePDs', ''));
                bootbox.alert('You selected more than one vacancy, more than one request will be required.');
            }
        }
        if (classifier && classifier.dirty) {
            if ($('#HRClassifier options').length > 1) {
                var classifierID = $('#HRClassifier option:selected').val();
                $('#classifierID').val(classifierID);
                FormState.doActionNoRender(StateAction.changeText('classifierID', classifierID));
            }
        }

        if (grade && grade.dirty) {
            if ('' != grade.value) {
                var savedGrades = $('#selectGrades').val();

                var data = HHS_TAB1.addStringValue(savedGrades, grade.value, ',', true);
                if(data !== null){
                    FormState.doActionNoRender(StateAction.changeText('selectGrades', data.join(',')));
                    HHS_TAB1.populateFields(data, 'selectGrades', 'selectedGrades', ',');
                }

                FormState.doActionNoRender(StateAction.reset('grade'));
            }
        }

        if (appointmentType && appointmentType.dirty) {
            if ('' != appointmentType.value) {
                var savedAppointmentTypes = $('#h_selectedAppointmentTypes').val();
                var data = HHS_TAB1.addStringValue(savedAppointmentTypes, appointmentType.value, ',');
                if(data !== null){
                    FormState.doActionNoRender(StateAction.changeText('h_selectedAppointmentTypes', data.join(',')));
                    HHS_TAB1.populateFields(data, 'h_selectedAppointmentTypes', 'selectedAppTypes', ',');
                    if(-1<_.indexOf(data, 'Temporary')){
                        hyf.util.showComponent('tempPositionReasonGroup');
                    }else{
                        hyf.util.hideComponent('tempPositionReasonGroup');
                    }
                }

                FormState.doActionNoRender(StateAction.reset('appointmentType'));
            }
        }

        if (hiringPlan && hiringPlan.dirty) {
            if ('' != hiringPlan.value) {
                var savedHiringPlans = $('#h_selectedHiringPlan').val();
                var data = HHS_TAB1.addStringValue(savedHiringPlans, hiringPlan.value, ';');
                if(data !== null){
                    FormState.doActionNoRender(StateAction.changeText('h_selectedHiringPlan', data.join(';')));
                    HHS_TAB1.populateFields(data, 'h_selectedHiringPlan', 'selectedHiringPlans', ';');

                    if ('MP/ESEP Hiring Plan' == hiringPlan.value) {
                        hyf.util.showComponent('additionalHPGroup');
                    }
                }

                FormState.doActionNoRender(StateAction.reset('hiringPlan'));
            }
        }
    }
    ,
    deleteButtonHtml: function(id, hiddenId, delimiter, title){
        return '<a role="button" href="javascript:void(0)" onclick="HHS_TAB1.removeSelectedItem(\'' + id + '\', \'' + hiddenId
            + '\', \'' + delimiter + '\');" title="'+title+'" class="deleteAction"><span class="glyphicon glyphicon-remove"></span></a>';
    },
    populateFields: function (arr, hiddenID, selectionID, delimiter, readOnly) {
        arr = unique(arr).sort();
        $('#' + selectionID + " .selectedValueContainer").html('');
        var $placeHolder = $('#' + selectionID);
        if(0<arr.length){
            $placeHolder.removeClass('hide');
            $placeHolder.show();
            $('#' + selectionID + " .selectedValueCaption").toggle(!readOnly);
        }else{
            $placeHolder.hide();
        }

        for (var i = 0; i < arr.length; i++) {
            var value = arr[i];
            var uID = 'a' + (new Date()).getTime() + value.replace(/\W+/g, "");
            var itemHtml = '<li role="option" class="selectedValue" id="'+uID+'">';
            if (hiddenID === 'selectGrades') {
                if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity() || IHS_REQUEST_MAIN.isStrategicConsultationActivity() || IHS_REQUEST_MAIN.isFillPositionActivity()) {

                    var rName = uID + '_' + value, errorMsg = value.substr(0, 2);
                    var newYValue = (value.indexOf(':Y') >= 0) ? value.substr(0, 2) + ':Y' : value.substr(0, 2) + ':Y'; // it has to always be "01-15:Y"
                    var newNValue = (value.indexOf(':N') >= 0) ? value.substr(0, 2) + ':N' : value.substr(0, 2) + ':N'; // it has to always be "01-15:N"
                    var dismissibleAlert = '<div  data-toggle="popover" data-content="Please select an appropriate FLSA exemption status." id="' + uID
                        + '" class="selectedValue isMandatory hasFeedback hasSuccess">';
                    var flsaDeterminationExempt = '<label class="selectedValueLabel">FLSA Determination<span class="mandatory"> *</span></label><label class="radio-inline">' +
                        '<input class="flsaRadio" type="radio" _required ="true" id ="' + uID + '_Y" name="' + uID + '" value="' + newYValue + '" onchange="HHS_TAB1.changeFlsaExempt($(this).val(),\'' + uID + '_Y\'' + ');HHS_TAB1.hideErrorMsg($(this).val())"' +
                        ' title="Is position Exempt or Non-exempt from FLSA? OF8, Box 7." />Exempt</label><label class="radio-inline">' +
                        '<input class="flsaRadio" type="radio" id="' + uID + '_N" name="' + uID + '" value="' + newNValue + '"   onchange="HHS_TAB1.changeFlsaExempt($(this).val(),\'' + uID + '_N\'' + ');HHS_TAB1.hideErrorMsg($(this).val())"' +
                        'title="Is position Exempt or Non-exempt from FLSA? OF8, Box 7." _required="true" />Non-exempt</label>' +
                        '</div><span id ="' + errorMsg + '" class="dijitTooltipContainer dijitTooltipContents errorMessage2"' +
                        ' role="alert" align="left" data-dojo-attach-point="containerNode">' +
                        'Please select an appropriate FLSA exemption status for ' + value.substr(0, 2) + '.</span>' +
                        '<div class="dijitTooltipConnector" data-dojo-attach-point="connectorNode" style="top: 17px;"></div>';

                    itemHtml = itemHtml + dismissibleAlert;
                    if (!readOnly) {
                        itemHtml += HHS_TAB1.deleteButtonHtml(uID, hiddenID, delimiter, "Delete " + value.substr(0,2));
                    }
                    itemHtml += value.substr(0, 2) + flsaDeterminationExempt + "</div></li>";

                    $('#' + selectionID + " .selectedValueContainer").append(itemHtml);
                    if (value.indexOf(':Y') || value.indexOf(':N')) {
                        $('input:radio[value~="' + value + '"]').prop('checked', true);
                        $('#' + value.substr(0, 2)).hide();
                    }
                } else {
                    var p = value.indexOf(':');
                    if(0 < p){
                        value = value.substr(0, p);
                    }

                    if (!readOnly) {
                        itemHtml += HHS_TAB1.deleteButtonHtml(uID, hiddenID, delimiter, "Delete " + value);
                    }
                    itemHtml += value + '</li>';

                    $('#' + selectionID + " .selectedValueContainer").append(itemHtml);
                }
            } else {
                if (!readOnly) {
                    itemHtml += HHS_TAB1.deleteButtonHtml(uID, hiddenID, delimiter, "Delete " + value);
                }
                itemHtml += value + '</li>';
                $('#' + selectionID + " .selectedValueContainer").append(itemHtml);
            }
        }

        if(!IHS_REQUEST_MAIN.isHRActionRequestActivity()){
            if (hiddenID === 'series' && arr.length > 0) {
                $('#occupationalSeries').removeAttr('_required');
            } else if (hiddenID === 'series') {
                $('#occupationalSeries').attr('_required', 'true');
            }
        }

        if (hiddenID === 'dutyLoc' && arr.length > 0) {
            $('#dutyStation').removeAttr('_required');
        } else if (hiddenID === 'dutyLoc') {
            $('#dutyStation').attr('_required', 'true');
        }
		
        if (hiddenID === 'selectGrades') {
            if(IHS_REQUEST_MAIN.isFillPositionActivity()){
                FormState.doActionNoRender(StateAction.reset('advertiseGrade'));
                FormState.doActionNoRender(StateAction.reset('targetGrade'));
                JOB_TAB.populateAdvertiseGradesAndTargetGrades();
            }

            if(arr.length > 0){
                $('#grade').removeAttr('_required');
            }
        }

        if (hiddenID === 'h_selectedAppointmentTypes' && arr.length > 0) {
            $('#appointmentType').removeAttr('_required');
        } else if (hiddenID === 'series') {
            $('#appointmentType').attr('_required', 'true');
        }
    },
    removeSelectedItem: function (selectionID, hiddendFieldID, delimiter) {
        var selection = $('#' + selectionID);
        var hiddendField = $('#' + hiddendFieldID);
        var hiddenValue = hiddendField.val();
        if (hiddenValue) {
            var newValue = hiddenValue.split(delimiter);
            var arrayCopy = [];
            if (Array.isArray(newValue) && newValue.length > 0) {
                newValue.forEach(function (val) {
                    if (hiddendFieldID == 'selectGrades') {
                        if ((selection).text().substring(0, 2) != val.substring(0, 2)) {
                            arrayCopy.push(val);
                        }
                    }
                    else if ($(selection).text().indexOf(val) == -1) {
                        arrayCopy.push(val);
                    }
                });

                hiddendField.val(arrayCopy.join(delimiter));
                FormState.doActionNoRender(StateAction.changeText(hiddendFieldID, arrayCopy.join(delimiter)));
                if (hiddendFieldID === 'series') {
                    if(!IHS_REQUEST_MAIN.isHRActionRequestActivity()) {
                        if (arrayCopy.length > 0) {
                            $('#occupationalSeries').removeAttr('_required');
                        } else {
                            $('#occupationalSeries').attr('_required', 'true');
                        }
                    }
				} else if (hiddendFieldID === 'selectGrades') {
					if (arrayCopy.length == 0 && (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity())) {
						$('#grade').attr('_required', 'true');
					}
                    if(IHS_REQUEST_MAIN.isFillPositionActivity()){
                        FormState.doActionNoRender(StateAction.reset('advertiseGrade'));
                        FormState.doActionNoRender(StateAction.reset('targetGrade'));
                        JOB_TAB.populateAdvertiseGradesAndTargetGrades();
                    }
                } else if (hiddendFieldID === 'dutyLoc') {
					if (arrayCopy.length == 0) {
						$('#dutyStation').attr('_required', 'true');
					}
                } else if (hiddendFieldID === 'h_selectedAppointmentTypes' && IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					if ($(selection).text() == 'Temporary') {
						hyf.util.hideComponent('tempPositionReasonGroup');
					}
					
					if (arrayCopy.length == 0) {
						$('#appointmentType').attr('_required', 'true');					
					}
                } else if (hiddendFieldID === 'h_selectedHiringPlan' && IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					// if MP/ESEP Hiring Plan does not exist, hide additional hiring plan info
					if ($(selection).text() === 'MP/ESEP Hiring Plan') {
						hyf.util.hideComponent('additionalHPGroup');
					}
                }
                selection.remove();
            }
        }
    },
    setAdminCodeAutoComplete: function () {
        $('#adminCode').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchAdminCode.do',
                    data: {searchString:$('#adminCode').val()},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: $('ADMIN_CODE', this).text(),
                                name: $('ADMIN_CODE', this).text(),
                                id: $('ID', this).text(),
                                adminCodeDesc: $('DESCRIPTION', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                $('#adminCode').val(ui.item.name);
                $('#adminCodeDesc').val(ui.item.adminCodeDesc);
                FormState.doActionNoRender(StateAction.changeText('adminCode', ui.item.name));
                FormState.doActionNoRender(StateAction.changeText('adminCodeDesc', ui.item.adminCodeDesc));
                HHS_TAB1.getHRClassifier(ui.item.name, '');
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            ul.attr('role', 'listbox');
            return $('<li>')
                .append('<a role="option">' + item.name + '</a>')
                .appendTo(ul);
        };
    },
    getHRClassifier: function (selectedItem, selectedClassifier) {
        $.ajax({
            url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchClassifier.do',
            data: {searchString:selectedItem},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        value: '',
                        memberid: $('MEMBERID', this).text(),
                        name: $('NAME', this).text(),
                        email: $('EMAIL', this).text()
                    };
                }).get();
                if (data.length > 0) {
                    $('#HRClassifier').html('');
                    $('#HRClassifier').append('<option value="">Select one</option>');
                    data.forEach(function (value) {
                        if (selectedClassifier == value.memberid) {
                            $('#HRClassifier').append('<option selected value="' + value.memberid + '">' + value.name + ' (' + value.email + ')</option>');
                        } else {
                            $('#HRClassifier').append('<option value="' + value.memberid + '">' + value.name + ' (' + value.email + ')</option>');
                        }
                    });
                }
            }
        });
    },
    getHRSpecialist: function (adminCode) {
        $.ajax({
            url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchHRSpecialist.do',
            data:{searchString: adminCode, managerId: $('#managerID').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        value: '',
                        memberid: $('MEMBERID', this).text(),
                        name: $('NAME', this).text(),
                        email: $('EMAIL', this).text()
                    };
                }).get();
                if (data.length > 0) {
                    $('#HRSpecialist').html('');
                    $('#HRSpecialist').append('<option value="">Select one</option>');
                    data.forEach(function (value) {
                        $('#HRSpecialist').append('<option value="' + value.memberid + '">' + value.name + ' (' + value.email + ')</option>');
                    });
                }
            }
        });
    },
    getGrades: function (selectedItem) {
        if(BFUtility.isReadOnly()){
            return;
        }

        if(typeof selectedItem ==='undefined' || 0===selectedItem.length){
            return;
        }

        $.ajax({
            url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchGrade.do',
            data: {searchString: selectedItem},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        value: '',
                        grade: $('GRADE', this).text()
                    };
                }).get();
                if (data.length > 0) {
                    $('#grade').html('').append('<option value="">Select all that apply</option>');
                    data.forEach(function (value) {
                        $('#grade').append('<option value="' + value.grade + '">' + value.grade + '</option>');
                    });
                }else{
                    bootbox.alert(SYSTEM_ERROR_MESSAGE);
                }
            }
        });
    },
    setReportToAutoComplete: function () {
        $('#reportTo').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchUser.do',
                    data: {searchString: $('#reportTo').val()},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: $('NAME', this).text(),
                                memberid: $('MEMBERID', this).text(),
                                name: $('NAME', this).text(),
                                email: $('EMAIL', this).text(),
                                positionTitle: $('JOBTITLENAME', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var val = ui.item.name + ', ' + ui.item.positionTitle + ' (' + ui.item.email + ')';
                $('#reportTo').val(val);
                FormState.doActionNoRender(StateAction.changeText('reportTo', val));
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
        .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            ul.attr('role', 'listbox');
            return $('<li>')
                .append('<a role="option">' + item.name + ', ' + item.positionTitle + ' (' + item.email + ') </a>')
                .appendTo(ul);
        };
    },
    setWhoToContactAutoComplete: function (fieldID) {
        $('#' + fieldID).autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchManager.do',
                    data: {searchString: $('#' + fieldID).val()},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: $('NAME', this).text(),
                                memberid: $('MEMBERID', this).text(),
                                name: $('NAME', this).text(),
                                email: $('EMAIL', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                $('#initiatorName').text(ui.item.name);
                $('#whoToContact').val(ui.item.name);
                $('#managerID').val(ui.item.memberid);
                if (fieldID === 'reportTo') {
                    $('#reportTo').val(ui.item.name);
                    FormState.doActionNoRender(StateAction.changeText('reportTo', ui.item.name));
                }
                FormState.doActionNoRender(StateAction.changeText('whoToContact', ui.item.name));
                FormState.doActionNoRender(StateAction.changeText('managerID', ui.item.memberid));
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            ul.attr('role', 'listbox');
            return $('<li>')
                .append('<a role="option">' + item.name + '  (' + item.email + ') </a>')
                .appendTo(ul);
        };
    },
    setOccupationalSeriesAutoComplete: function () {
        $('#occupationalSeries')
            .autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchOccSeries.do',
                    data:{searchString:$('#occupationalSeries').val(), payPlan:$('#payPlan').val()},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: $('SERIES_CODE', this).text() + " " + $('DESCRIPTION', this).text(),
                                seriesCode: $('SERIES_CODE', this).text(),
                                description: $('DESCRIPTION', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var series = $('#series').val();

                var data = HHS_TAB1.addStringValue(series, ui.item.seriesCode + ' ' + ui.item.description, ',');
                if(data !== null){
                    FormState.doActionNoRender(StateAction.changeText('series', data.join(',')));
                    $('#series').val(FormState.getState('series').value);
                    HHS_TAB1.populateFields(data, 'series', 'selectedOccSeries', ',');
                }
                $('#occupationalSeries').val('');
                FormState.doActionNoRender(StateAction.reset('occupationalSeries'));
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .data('ui-autocomplete')._renderItem = function (ul, item) {
            ul.attr('role', 'listbox');
            return $('<li>')
                .append('<a role="option">' + item.seriesCode + ' ' + item.description + '</a>')
                .appendTo(ul);
        };
    },
    setDutyLocationAutoComplete: function () {
        $('#dutyStation').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchDutyStation.do',
                    data: {searchString: $('#dutyStation').val()},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: $('LOC_CITY', this).text() + ', ' + $('LOC_STATE', this).text() + ' ' + $('LOC_CODE', this).text(),
                                locCode: $('LOC_CODE', this).text(),
                                locCountry: $('LOC_COUNTRY', this).text(),
                                locState: $('LOC_STATE', this).text(),
                                locCity: $('LOC_CITY', this).text(),
                                locCounty: $('LOC_COUNTY', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 3,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var dValue = ui.item.locCity + ', ' + ui.item.locState + ' ' + ui.item.locCode;
                var savedDutyLoc = $('#dutyLoc').val();
                var data = HHS_TAB1.addStringValue(savedDutyLoc, dValue, ';');
                if(data !== null){
                    FormState.doActionNoRender(StateAction.changeText('dutyLoc', data.join(';')));
                    $('#dutyLoc').val(FormState.getState('dutyLoc').value);
                    HHS_TAB1.populateFields(data, 'dutyLoc', 'selectedDutyStations', ';');
                }

                $('#dutyStation').val('');
                FormState.doActionNoRender(StateAction.reset('dutyStation'));
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            ul.attr('role', 'listbox');
            return $('<li>')
                .append('<a role="option">' + item.locCity + ', ' + item.locState + ' ' + item.locCode + '</a>')
                .appendTo(ul);
        };
    },
    setEmployingOfficeLocationAutoComplete: function () {
        $('#empOfficeLoc').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchDutyStation.do',
                    data: {searchString: $('#empOfficeLoc').val()},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: $('LOC_CITY', this).text() + ', ' + $('LOC_STATE', this).text() + ' ' + $('LOC_CODE', this).text(),
                                locCode: $('LOC_CODE', this).text(),
                                locCountry: $('LOC_COUNTRY', this).text(),
                                locState: $('LOC_STATE', this).text(),
                                locCity: $('LOC_CITY', this).text(),
                                locCounty: $('LOC_COUNTY', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 3,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var dl = ui.item.locCity + ', ' + ui.item.locState;
                $('#empOfficeLoc').val(dl);
                FormState.doActionNoRender(StateAction.changeText('empOfficeLoc', dl));
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            ul.attr('role', 'listbox');
            return $('<li>')
                .append('<a role="option">' + item.locCity + ', ' + item.locState + '</a>')
                .appendTo(ul);
        };
    },
    changeFlsaExempt: function (value, id) {
        var grades = $('#selectGrades').val(), tempGrades, searchvalue;
        if (grades.length >= 2) {
            tempGrades = grades.indexOf(',') ? grades.split(',') : grades;
            if (tempGrades.length > 0) {
                tempGrades.forEach(function (gradeValue, index) {
                    if (value.substr(0, 2) == gradeValue.substr(0, 2)) {
                        tempGrades[index] = value;	// value is in the form of grade:N or grade:Y. eg 01:Y or 01:N
                        searchvalue = value;
                    }
                });
                $('#selectGrades').val(tempGrades.join());
                FormState.doActionNoRender(StateAction.changeText('selectGrades', tempGrades.join()));

            }
        }
    },
    hideErrorMsg: function (value) {
        $('#' + value.substr(0, 2)).hide();
    },
    mirmDialog: null,
    copyDialog: null,
    loadMoreInformationRequest: function(){
        BFUtility.callPartialPage(null, '/ihsrec_position/loadMoreInformationRequest.do', 'WIH_information', 'moreInformationGroup');
    },
    checkAllReceivedDate: function(){
        if(IHS_REQUEST_MAIN.isClassificationActivity()) {
            // Disabling 'Send Email to Manager' and 'Return to HR Action Request'
            var hasEmpty = false;
            $('input.mirReceivedDate').each(function(){
                if($(this).val().length == 0){
                    hasEmpty = true;
                    return false;
                }
            });

            if(hasEmpty) {
                hyf.util.disableComponent('button_returnToHR');
                hyf.util.disableComponent('button_forward');
                IHS_REQUEST_MAIN.setStatus(Status_PendingMoreInformation);
            }else{
                hyf.util.enableComponent('button_returnToHR');
                hyf.util.enableComponent('button_forward');
                IHS_REQUEST_MAIN.setStatus(Status_PendingClassification);
            }
        }
    },
    initMoreInformationRequestHistory: function (){
        hyf.calendar.setRepeatDateConstraint('moreInformationRequest', 'RCV_DT', 'Minimum', 'MIN_RCV_DT', true);
        hyf.calendar.setRepeatDateConstraint('moreInformationRequest', 'RCV_DT', 'Maximum', 'Today');

        HHS_TAB1.checkAllReceivedDate();

        $('#moreInformationGroup input.mirReceivedDate').change(function(e){
            var fieldName = e.currentTarget.name;
            var newValue = e.target.value;
            if(newValue.length === 0 || hyf.validation.validateField(fieldName, true)){
                var requestId = $('#' + fieldName.substring(0, fieldName.indexOf('RCV_DT')) + 'REQUEST_ID').val();
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/UpdateReceiveDate.do',
                    data: {reqId: requestId, dt: newValue},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        HHS_TAB1.checkAllReceivedDate();
                    }
                });
            }
        });

        $('#moreInformationGroup a.viewMoreInformationRequestMessage').click(function(e){
            e.preventDefault();
            var fieldName = e.currentTarget.name;
            var requestId = $('#' + fieldName.substring(0, fieldName.indexOf('viewMessage')) + 'REQUEST_ID').val();
            BFUtility.callPartialPage(null, '/ihsrec_position/loadMoreInformationRequestMessage.do?reqId='+requestId, null, 'more_info_req_popup_dialog_content');
            HHS_TAB1.mirmDialog = bootbox.dialog({
                title: 'Request Message',
                message: '<p><i class="fa fa-spin fa-spinner"></i>Loading...</p>',
                onEscape: true,
                buttons: [{
                    label: 'Close',
                    className: 'btn pull-right',
                    callback: function () {
                        $('#more_info_req_popup_dialog_content').hide();
                    }
                }]
            });
        });
    },
    callbackLoadMoreInformationRequestMessage: function(){
        $('#MIRM_EMAIL_BODY').attr("readonly","readonly").attr("wrap", "hard");
        HHS_TAB1.mirmDialog.find('.bootbox-body').html($('#more_info_req_popup_dialog_content').html());
    },
    escapeRegExp: function (str) {
        return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
    },
    addStringValue: function(savedValues, newValue, delimiter, startsWith){
        var data = [];
        if(savedValues && 0<savedValues.length){
            data = savedValues.split(delimiter);
        }

        var found = false;
        if(startsWith){
            found = (-1<_.findIndex(data, function(item) {return _.startsWith(item, newValue);}));
        }else{
            found = (-1<_.indexOf(data, newValue));
        }

        if(found){
            return null; // no data changed
        } else{
            data.push(newValue);
            return unique(data).sort();
        }
    },
    copyByTrackingNumber: function(trackingNumber){
        $.ajax({
            url: '/bizflowwebmaker/ihs_AutoCompleteService/LoadFormData.do',
            data: {procid:trackingNumber, memberid: $('#h_currentUserMemberID').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = undefined;
                var isIE = !!navigator.userAgent.match(/Trident/g) || !!navigator.userAgent.match(/MSIE/g);
                if(isIE){
                    var xml = $('formData', xmlResponse);
                    data = (new XMLSerializer()).serializeToString(xml[0]);
                }else{
                    data = $('FIELD_DATA_CLOB', xmlResponse).html();
                }
                if(0<data.length){
                    if(Status_Draft !== IHS_REQUEST_MAIN.getStatus()){
                        bootbox.confirm({
                            message:"Copying a request will remove all previously entered information. Continue?",
                            callback: function(result){
                                if(result){
                                    HHS_TAB1.populateFormData(data);
                                }
                            }});
                    }else{
                        HHS_TAB1.populateFormData(data);
                    }
                }else{
                    bootbox.alert("Tracking number does not exist, or you don't have access rights.");
                }
            }
        });
    },
    populateFormData: function(data){
        HHS_TAB1.initialized = false;
        IHS_REQUEST_MAIN.loadForm(data);
        IHS_REQUEST_MAIN.setStatus(Status_Draft);
    }
};
