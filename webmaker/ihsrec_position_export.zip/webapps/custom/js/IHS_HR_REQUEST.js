var HHS_TAB1 = {
    initialized: false,
    activityName: '',
    init: function () {
        //elements to hide or show in classification
        var hideListAR = ['classificationStatus', 'organizationTitleGroup', 'employingOfficeLocGroup', 'ClassificationSet', 'flsaDeterminationGroup', 'initialJobCodeGroup', 'classifiedPDQ_2', 'classificationComments', 'appointmentTypeGroup', 'tempPositionReasonGroup', 'consultationPDQ_2', 'consultationSet'];
        var hideListCL = ['classifiedPDQ', 'actionTypeGroup', 'classifierGroup', 'classifiedPDTxt', 'basedTxt', 'appointmentTypeGroup', 'tempPositionReasonGroup', 'consultationPDQ_2', 'consultationSet'];
        var hideListSC = ['classifiedPDQ', 'numberSection', 'actionTypeGroup', 'classifierGroup', 'classifiedPDTxt', 'basedTxt', 'classificationStatus', 'organizationTitleGroup', 'ClassificationSet', 'initialJobCodeGroup', 'careerLadderGroup'];
        var activity = BFActivityOption.getActivityName();
        HHS_TAB1.activityName = activity;
        if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity()) {
            hideListCL.forEach(function (val) {
                hyf.util.hideComponent(val);
            });
            hyf.util.showComponent('classificationStatus');
            hyf.util.showComponent('organizationTitleGroup');
            hyf.util.showComponent('employingOfficeLocGroup');

            hyf.util.setMandatoryConstraint('grade', true);
            hyf.util.setMandatoryConstraint('positionNumber', true);
            for (var fieldGroup = 2; fieldGroup <= 5; fieldGroup++) {
                hyf.util.setMandatoryConstraint('positionNumber_' + fieldGroup, true);
            }
            hyf.util.disableComponent('comments');
            hyf.util.hideComponent('initialJobCodeGroup');
            //HHS_TAB1.setWhoToContactAutoComplete('reportTo');
		} else if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
            hideListSC.forEach(function (val) {
                hyf.util.hideComponent(val);
            });

            hyf.util.disableComponent('positionTitle');
            hyf.util.disableComponent('payPlan');
            hyf.util.disableComponent('adminCode');
            hyf.util.disableComponent('jobCode_2');
            hyf.util.disableComponent('empOfficeLoc');
            hyf.util.disableComponent('comments');
            hyf.util.disableComponent('classificationComments');
            hyf.util.disableComponent('positionNumber', true);
            for (var fieldGroup = 2; fieldGroup <= 5; fieldGroup++) {
                hyf.util.disableComponent('positionNumber_' + fieldGroup, true);
            }
            hyf.util.disableComponent('viceName', true);
            for (var fieldGroup = 2; fieldGroup <= 5; fieldGroup++) {
                hyf.util.disableComponent('viceName_' + fieldGroup, true);
            }
            hyf.util.disableComponent('positionVacatedDate', true);
            for (var fieldGroup = 2; fieldGroup <= 5; fieldGroup++) {
                hyf.util.disableComponent('positionVacatedDate_' + fieldGroup, true);
            }
			
			$('#occupationalSeries').hide();
			$('#grade').hide();
			$('#dutyStation').hide();
            hyf.util.hideComponent('tempPositionReasonGroup');
        } else {	// HR Action Request, Update HR Action Request
            hideListAR.forEach(function (val) {
                hyf.util.hideComponent(val);
            });

            if(IHS_REQUEST_MAIN.isHRActionRequestActivity()){
                hyf.util.hideComponent('classificationJobCodeGroup');
                hyf.util.showComponent('initialJobCodeGroup');
            }
        }
        hyf.calendar.setDateConstraint('flsaCompleteDate', 'Maximum', 'Today');
        hyf.calendar.setDateConstraint('posRiskComplete', 'Maximum', 'Today');
        hyf.calendar.setDateConstraint('posDescCompleteDate', 'Maximum', 'Today');
        hyf.calendar.setDateConstraint('evalStatement', 'Maximum', 'Today');
        $('#flsaCompleteDate, #posRiskComplete, #posDescCompleteDate, #evalStatement').change(function(e) {
            var fieldName = e.currentTarget.name;
            var newValue = e.target.value;
            if(0<newValue.length && !hyf.validation.validateField(fieldName)){
                $(e.target).focus();
            }
        });
        HHS_TAB1.loadMoreInformationRequest();
    },
    render: function () {
        var adminCode = FormState.getState('adminCode');
        var whoToContact = FormState.getState('whoToContact');
        var requestType = FormState.getState('actionType');
        var classifiedPopulated = FormState.getState('classifiedPDRes');
        var viceName = FormState.getState('viceName');
        var payPlan = FormState.getState('payPlan');
        var numbOfVacancies = FormState.getState('numberOfVacancies');
        var grade = FormState.getState('grade');
        var appointmentType = FormState.getState('appointmentType');
        var hiringPlan = FormState.getState('hiringPlan');
        var usingSamePD = FormState.getState('usingSamePDs');
        var classifier = FormState.getState('HRClassifier');
        var jobCode = FormState.getState('jobCode');
		
		if (!HHS_TAB1.initialized) {
            var seriesSplit = FormState.getState('series');
            if (seriesSplit && seriesSplit.dirty && seriesSplit.value.length) {
                seriesSplit = seriesSplit.value.indexOf(',') ? seriesSplit.value.split(',') : [seriesSplit.value];
				
				if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					HHS_TAB1.populateFields(seriesSplit, 'series', 'selectedOccSeries', ',', true);
				} else {
					HHS_TAB1.populateFields(seriesSplit, 'series', 'selectedOccSeries', ',', false);
				}
            }
			
            var dutyLoc = FormState.getState('dutyLoc');
            if (dutyLoc && dutyLoc.dirty && dutyLoc.value.length) {
                dutyLoc = dutyLoc.value.indexOf(';') ? dutyLoc.value.split(';') : [dutyLoc.value];

				if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					HHS_TAB1.populateFields(dutyLoc, 'dutyLoc', 'selectedDutyStations', ';', true);
				} else {
					HHS_TAB1.populateFields(dutyLoc, 'dutyLoc', 'selectedDutyStations', ';', false);
				}
            }
			
            if (adminCode && adminCode.dirty && adminCode.value) {
                var selectedClassifier = '';
                if (classifier) {
                    selectedClassifier = classifier.value;
                }
                HHS_TAB1.getHRClassifier(adminCode.value, selectedClassifier);
            }
			
            var selectedGrade = FormState.getState('selectGrades');
            if (selectedGrade && selectedGrade.dirty && selectedGrade.value.length) {
                selectedGrades = selectedGrade.value.indexOf(',') ? selectedGrade.value.split(',') : [selectedGrade.value];

				if (IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					HHS_TAB1.populateFields(selectedGrades, 'selectGrades', 'selectedGrades', ',', true);
					$('.flsaRadio').attr('disabled', true);
				} else {
					HHS_TAB1.populateFields(selectedGrades, 'selectGrades', 'selectedGrades', ',', false);
				}
            }
			
            var appTypes = FormState.getState('h_selectedAppointmentTypes');
            if (appTypes && appTypes.dirty && appTypes.value.length) {
				var atArray = appTypes.value.split(',');
				
				for (var k = 0; k < atArray.length; k++) {
					if (atArray[k] == 'Temporary') {
						hyf.util.showComponent('tempPositionReasonGroup');
						break;
					}
				}
				
                appTypes = appTypes.value.indexOf(',') ? appTypes.value.split(',') : [appTypes.value];

				if (!IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					HHS_TAB1.populateFields(appTypes, 'h_selectedAppointmentTypes', 'selectedAppTypes', ',', true);
				} else {
					HHS_TAB1.populateFields(appTypes, 'h_selectedAppointmentTypes', 'selectedAppTypes', ',', false);
				}
            }
			
            var hiringPlans = FormState.getState('h_selectedHiringPlan');

            if (hiringPlans && hiringPlans.dirty && hiringPlans.value.length) {
                var hiringPlansArray = hiringPlans.value.indexOf(';') ? hiringPlans.value.split(';') : [hiringPlans.value];

				if (!IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					HHS_TAB1.populateFields(hiringPlansArray, 'h_selectedHiringPlan', 'selectedHiringPlans', ';', true);
				} else {
					// if MP/ESEP Hiring Plan does not exist, hide additional hiring plan info
					if (hiringPlans.value.indexOf('MP/ESEP Hiring Plan') < 0) {
						hyf.util.hideComponent('additionalHPGroup');
					}

					HHS_TAB1.populateFields(hiringPlansArray, 'h_selectedHiringPlan', 'selectedHiringPlans', ';', false);
				}
            } else {
				hyf.util.hideComponent('additionalHPGroup');
			}

            if (!numbOfVacancies) {
                $('usingSamePDs').val('na');
                FormState.doAction(StateAction.changeRadio('usingSamePDs', 'na'), false);
                FormState.doAction(StateAction.changeSelect('numberOfVacancies', '1', '1'), false);
                for (var group = 2; group <= 5; group++) {
                    hyf.util.hideComponent('group_info_' + group);
                }
                $('#usingSamePDs1').parent().parent().hide();
                $('#usingSamePDs2').parent().parent().hide();
            }

            if (!whoToContact) {
                $('#whoToContact').val($('#initiatorName').text())
                $('#managerID').val($('#h_currentUserMemberID').val());
                FormState.doAction(StateAction.changeText('whoToContact', $('#initiatorName').text()), false);
                FormState.doAction(StateAction.changeText('managerID', $('#h_currentUserMemberID').val()), false);
            }

            HHS_TAB1.setAdminCodeAutoComplete();
            HHS_TAB1.setWhoToContactAutoComplete('whoToContact');
            HHS_TAB1.setOccupationalSeriesAutoComplete();
            HHS_TAB1.setDutyLocationAutoComplete();
            HHS_TAB1.setEmployingOfficeLocationAutoComplete();
            HHS_TAB1.setReportToAutoComplete();
            //HHS_TAB1.changeFlsaExempt
            HHS_TAB1.initialized = true;
        }	// if (!HHS_TAB1.initialized)

        // populate initial fields with form state values

        if (classifiedPopulated && classifiedPopulated.dirty) {
            if (classifiedPopulated.value === 'Y') {
                var grages = FormState.getState('selectGrades');
                if (grages && grages.value.length >= 1) {
                    $('#grade').removeAttr('_required');
                } else {
                    $('#grade').attr('_required', 'true');
                }
            }
        } else {
            $('#grade').removeAttr('_required');
        }
		
        if (requestType && requestType.dirty) {
            $('#requestType').text(requestType.value);
        }

        if (whoToContact && whoToContact.dirty) {
            $('#initiatorName').text(whoToContact.value);
            $('#whoToContact').val(whoToContact);
        }

        if (viceName && viceName.dirty) {
            hyf.util.setMandatoryConstraint('positionVacatedDate', (0<viceName.value.length));
        }
		
        for (var group = 2; group <= 5; group++) {
            var multiViceName = FormState.getState('viceName_' + group);
            if (multiViceName && multiViceName.dirty) {
                hyf.util.setMandatoryConstraint('positionVacatedDate_'+group, (0<multiViceName.value.length));
            }
        }
		
        if (payPlan && payPlan.dirty && payPlan.value !== 'Select one') {
            $('#grade').html('');
            var seriesValue = $('#series').val();
            var gradeValue = $('#selectGrades').val();
            if ((seriesValue && seriesValue.length > 0) || (gradeValue && gradeValue.length > 0)) {
                bootbox.confirm({
                    message: 'Do you want to reset your values for Occupational Series and Grade(s)?',
                    buttons: {
                        confirm: {
                            label: 'Yes',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'No',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if (result) {
                            //reset grades and series.
                            $('series').val('');
                            $('selectGrades').val('');
                            FormState.doAction(StateAction.changeText('series', ''), false);
                            FormState.doAction(StateAction.changeText('selectGrades', ''), false);
                            $('#selectedOccSeries > div').remove();
                            $('#selectedGrades > div').remove();
                        }

                    }
                });
            }
            HHS_TAB1.getGrades(payPlan.value);
        }
		
        if (numbOfVacancies && numbOfVacancies.dirty) {
            if (parseInt(numbOfVacancies.value) == 1) {
                $('usingSamePDs').val('na');
                FormState.doAction(StateAction.changeRadio('usingSamePDs', 'na'), false);
                if ($('#output_requestStatus').text() === Status_Draft) {//check if status is draft, if yes, hide 2-5
                    FormState.doAction(StateAction.changeSelect('numberOfVacancies', '1', '1'), false);
                    for (var group = 2; group <= 5; group++) {
                        hyf.util.hideComponent('group_info_' + group);
                    }
                }
                $('#usingSamePDs1').parent().parent().hide();
                $('#usingSamePDs2').parent().parent().hide();
                $('#usingSamePDs3').parent().parent().show();
            } else {
				if ('Y' != usingSamePD.value) {
					$('#usingSamePDs3').prop('checked', false);
					FormState.doAction(StateAction.changeRadio('usingSamePDs', ''), false);
				}

                $('#usingSamePDs1').parent().parent().show();
                $('#usingSamePDs2').parent().parent().show();
                $('#usingSamePDs3').parent().parent().hide();
            }


            for (var group = 1; group <= parseInt(numbOfVacancies.value); group++) {
                hyf.util.showComponent('group_info_' + group);
            }
            if (parseInt(numbOfVacancies.value) <= 5) {
                var group = parseInt(numbOfVacancies.value) + 1;
                for (; group <= 5; group++) {
                    hyf.util.hideComponent('group_info_' + group);
                    $('#positionNumber_' + group).val('');
                    $('#positionVacatedDate_' + group).val('');
                    $('#viceName_' + group).val('');
                    FormState.doAction(StateAction.changeText('positionNumber_' + group, ''), false);
                    FormState.doAction(StateAction.changeDate('positionVacatedDate_' + group, ''), false);
					hyf.util.setMandatoryConstraint('positionVacatedDate_'+group, false);
                    FormState.doAction(StateAction.changeText('viceName_' + group, ''), false);
                }
            }
        }
        if (usingSamePD && usingSamePD.dirty) {
            if (usingSamePD.value === 'N') {
                $('#usingSamePDs2').prop('checked', false);
                FormState.doAction(StateAction.changeRadio('usingSamePDs', ''), false);
                bootbox.alert('You selected more than one vacancy, more than one request will be required.');
            }
        }
        if (classifier && classifier.dirty) {
            if ($('#HRClassifier options').length > 1) {
                var classifierID = $('#HRClassifier option:selected').val();
                $('#classifierID').val(classifierID);
                FormState.doAction(StateAction.changeText('classifierID', classifierID, false));
            }
        }

        if (grade && grade.dirty) {
            if ('' != grade.value) {
                var savedGrades = $('#selectGrades').val();

                if (savedGrades.indexOf(grade.value) == -1) {
                    if ('' == savedGrades) {
                        savedGrades = grade.value;
                    } else {
                        savedGrades = savedGrades + ',' + grade.value;
                    }
                    $('#selectGrades').val(savedGrades);
                    FormState.doAction(StateAction.changeText('selectGrades', savedGrades), false);
                    HHS_TAB1.populateFields([grade.value], 'selectGrades', 'selectedGrades', ',');
                    FormState.doAction(StateAction.changeText('grade', ''), false);
                } else {
                    FormState.doAction(StateAction.changeText('grade', ''), false);
				}
            }
        }

        if (appointmentType && appointmentType.dirty) {
            if ('' != appointmentType.value) {
                var savedAppointmentTypes = $('#h_selectedAppointmentTypes').val();
				var alreadyExist = false;
				var atArray = savedAppointmentTypes.split(',');
				
				for (var k = 0; k < atArray.length; k++) {
					if (atArray[k] == appointmentType.value) {
						alreadyExist = true;
						break;
					}
				}

                if (!alreadyExist) {
                    if ('' == savedAppointmentTypes) {
                        savedAppointmentTypes = appointmentType.value;
                    } else {
                        savedAppointmentTypes = savedAppointmentTypes + ',' + appointmentType.value;
                    }
					
                    $('#h_selectedAppointmentTypes').val(savedAppointmentTypes);
                    FormState.doAction(StateAction.changeText('h_selectedAppointmentTypes', savedAppointmentTypes), false);
                    HHS_TAB1.populateFields([appointmentType.value], 'h_selectedAppointmentTypes', 'selectedAppTypes', ',');
                    FormState.doAction(StateAction.changeText('appointmentType', ''), false);

					if (appointmentType.value == 'Temporary') {
						hyf.util.showComponent('tempPositionReasonGroup');
					}
                } else {
                    FormState.doAction(StateAction.changeText('appointmentType', ''), false);
				}
            }
        }

        if (hiringPlan && hiringPlan.dirty) {
            if ('' != hiringPlan.value) {
                var savedHiringPlans = $('#h_selectedHiringPlan').val();

                if (savedHiringPlans.indexOf(hiringPlan.value) == -1) {
                    if ('' == savedHiringPlans) {
                        savedHiringPlans = hiringPlan.value;
                    } else {
                        savedHiringPlans = savedHiringPlans + ';' + hiringPlan.value;
                    }
					
					// if MP/ESEP Hiring Plan, show additional hiring plan info
					if ('MP/ESEP Hiring Plan' == hiringPlan.value) {
						hyf.util.showComponent('additionalHPGroup');
					}
					
                    $('#h_selectedHiringPlan').val(savedHiringPlans);
                    FormState.doAction(StateAction.changeText('h_selectedHiringPlan', savedHiringPlans), false);
                    HHS_TAB1.populateFields([hiringPlan.value], 'h_selectedHiringPlan', 'selectedHiringPlans', ';');
                    FormState.doAction(StateAction.changeText('hiringPlan', ''), false);
                } else {
                    FormState.doAction(StateAction.changeText('hiringPlan', ''), false);
				}
            }
        }
    }
    ,
    populateFields: function (arr, hiddenID, selectionID, delimiter, hideX) {
        for (var i = 0; i < arr.length; i++) {
            var value = arr[i];
            var uID = 'a' + (new Date()).getTime() + value.replace(/\W+/g, "");
            var dismissibleAlert = '<div  data-toggle="popover" data-content="Please select an appropriate FLSA exemption status." id="' + uID
				+ '" class="selectedValue isMandatory hasFeedback hasSuccess">';
			
			if (!hideX) {
				dismissibleAlert = dismissibleAlert + '<a href="#" onclick="HHS_TAB1.removeSelectedItem(\'' + uID + '\', \'' + hiddenID
					+ '\', \'' + delimiter + '\'); $(this).parent().remove()" class="deleteAction"><span class="glyphicon glyphicon-remove"></span></a>';
			}

            dismissibleAlert += '<span class="selectedValue">';
            if (hiddenID === 'selectGrades') {
                if (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity() || IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
                    var rName = uID + '_' + value, errorMsg = value.substr(0, 2);
                    var newYValue = (value.indexOf(':Y') >= 0) ? value.substr(0, 2) + ':Y' : value.substr(0, 2) + ':Y'; // it has to always be "01-15:Y"
                    var newNValue = (value.indexOf(':N') >= 0) ? value.substr(0, 2) + ':N' : value.substr(0, 2) + ':N'; // it has to always be "01-15:N"
                    var flsaDeterminationExempt = '<label class="selectedValueLabel">FLSA Determination<span class="mandatory"> *</span></label><label class="radio-inline">' +
                        '<input class="flsaRadio" type="radio" _required ="true" id ="' + uID + '_Y" name="' + uID + '" value="' + newYValue + '" onchange="HHS_TAB1.changeFlsaExempt($(this).val(),\'' + uID + '_Y\'' + ');HHS_TAB1.hideErrorMsg($(this).val())"' +
                        ' title="Is position Exempt or Non-exempt from FLSA? OF8, Box 7." />Exempt</label><label class="radio-inline">' +
                        '<input class="flsaRadio" type="radio" id="' + uID + '_N" name="' + uID + '" value="' + newNValue + '"   onchange="HHS_TAB1.changeFlsaExempt($(this).val(),\'' + uID + '_N\'' + ');HHS_TAB1.hideErrorMsg($(this).val())"' +
                        'title="Is position Exempt or Non-exempt from FLSA? OF8, Box 7." _required="true" />Non-exempt</label>' +
                        '</div><span id ="' + errorMsg + '" class="dijitTooltipContainer dijitTooltipContents"' +
                        ' role="alert" align="left" data-dojo-attach-point="containerNode">' +
                        '<i class="feedbackIcon fiError" style="position:relative !important;font-size: 13px; font-weight: 700;"></i>' +
                        'Please select an appropriate FLSA exemption status for ' + value.substr(0, 2) + '.</span>' +
                        '<div class="dijitTooltipConnector" data-dojo-attach-point="connectorNode" style="top: 17px;"></div>';
                    dismissibleAlert = dismissibleAlert + value.substr(0, 2) + '</span>' + flsaDeterminationExempt;
                    $('#' + selectionID).append(dismissibleAlert);
                    if (value.indexOf(':Y') || value.indexOf(':N')) {
                        $('input:radio[value~="' + value + '"]').prop('checked', true);
                        $('#' + value.substr(0, 2)).hide();
                    }
                } else {
                    var p = value.indexOf(':');
                    if(0 < p){
                        value = value.substr(0, p);
                    }
                    dismissibleAlert = dismissibleAlert + value + '</span></div>';
                    $('#' + selectionID).append(dismissibleAlert);
                }
            } else {
                dismissibleAlert = dismissibleAlert + value + '</span></div>';
                $('#' + selectionID).append(dismissibleAlert);
            }
        }

        if (hiddenID === 'series' && arr.length > 0) {
            $('#occupationalSeries').removeAttr('_required');
        } else if (hiddenID === 'series') {
            $('#occupationalSeries').attr('_required', 'true');
        }

        if (hiddenID === 'dutyLoc' && arr.length > 0) {
            $('#dutyStation').removeAttr('_required');
        } else if (hiddenID === 'dutyLoc') {
            $('#dutyStation').attr('_required', 'true');
        }
		
        if (hiddenID === 'selectGrades' && arr.length > 0) {
            $('#grade').removeAttr('_required');
        } else if (hiddenID === 'dutyLoc') {
            $('#grade').attr('_required', 'true');
        }

        if (hiddenID === 'h_selectedAppointmentTypes' && arr.length > 0) {
            $('#appointmentType').removeAttr('_required');
        } else if (hiddenID === 'series') {
            $('#appointmentType').attr('_required', 'true');
        }
    },
    removeSelectedItem: function (selectionID, hiddendFieldID, delimiter) {
        var selection = $('#' + selectionID);
        var hiddendField = $('#' + hiddendFieldID);
        var hiddenValue = hiddendField.val();
        if (hiddenValue) {
            var newValue = hiddenValue.split(delimiter);
            var arrayCopy = [];
            if (Array.isArray(newValue) && newValue.length > 0) {
                newValue.forEach(function (val) {
                    if (hiddendFieldID == 'selectGrades') {
                        if ((selection).text().substring(0, 2) != val.substring(0, 2)) {
                            arrayCopy.push(val);
                        }
                    }
                    else if ($(selection).text().indexOf(val) == -1) {
                        arrayCopy.push(val);
                    }
                });

                hiddendField.val(arrayCopy.join());
                FormState.doAction(StateAction.changeText(hiddendFieldID, arrayCopy.join()), false);
                if (hiddendFieldID === 'series' && arrayCopy.length == 0) {
                    $('#occupationalSeries').attr('_required', 'true');
				} else if (hiddendFieldID === 'selectGrades') {
					if (arrayCopy.length == 0 && (IHS_REQUEST_MAIN.isClassificationActivity() || IHS_REQUEST_MAIN.isUpdateClassificationActivity())) {
						$('#grade').attr('_required', 'true');
					}
                } else if (hiddendFieldID === 'dutyLoc') {
					if (arrayCopy.length == 0) {
						$('#dutyStation').attr('_required', 'true');
					}
                } else if (hiddendFieldID === 'h_selectedAppointmentTypes' && IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					if ($(selection).text() == 'Temporary') {
						hyf.util.hideComponent('tempPositionReasonGroup');
					}
					
					if (arrayCopy.length == 0) {
						$('#appointmentType').attr('_required', 'true');					
					}
                } else if (hiddendFieldID === 'h_selectedHiringPlan' && IHS_REQUEST_MAIN.isStrategicConsultationActivity()) {
					// if MP/ESEP Hiring Plan does not exist, hide additional hiring plan info
					if ($(selection).text() === 'MP/ESEP Hiring Plan') {
						hyf.util.hideComponent('additionalHPGroup');
					}
                }
            }
        }
    },
    setAdminCodeAutoComplete: function () {
        $('#adminCode').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchAdminCode.do?searchString=' + $('#adminCode').val(),
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: '',
                                name: $('ADMIN_CODE', this).text(),
                                id: $('ID', this).text(),
                                adminCodeDesc: $('DESCRIPTION', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                $('#adminCode').val(ui.item.name);
                $('#adminCodeDesc').val(ui.item.adminCodeDesc);
                FormState.doAction(StateAction.changeText('adminCode', ui.item.name), false);
                FormState.doAction(StateAction.changeText('adminCodeDesc', ui.item.adminCodeDesc), false);
                HHS_TAB1.getHRClassifier(ui.item.name, '');
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>' + HHS_TAB1.boldSearchText(item.name, this.term) + '</a>')
                .appendTo(ul);
        };
    },
    getHRClassifier: function (selectedItem, selectedClassifier) {
        $.ajax({
            url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchClassifier.do?searchString=' + selectedItem,
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        value: '',
                        memberid: $('MEMBERID', this).text(),
                        name: $('NAME', this).text(),
                        email: $('EMAIL', this).text()
                    };
                }).get();
                if (data.length > 0) {
                    $('#HRClassifier').html('');
                    $('#HRClassifier').append('<option value="">Select one</option>');
                    data.forEach(function (value) {
                        if (selectedClassifier == value.memberid) {
                            $('#HRClassifier').append('<option selected value="' + value.memberid + '">' + value.name + ' (' + value.email + ')</option>');
                        } else {
                            $('#HRClassifier').append('<option value="' + value.memberid + '">' + value.name + ' (' + value.email + ')</option>');
                        }
                    });
                }
            }
        });
    },
    getHRSpecialist: function (adminCode) {
        $.ajax({
            url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchHRSpecialist.do',
            data:{searchString: adminCode, managerId: $('#managerID').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        value: '',
                        memberid: $('MEMBERID', this).text(),
                        name: $('NAME', this).text(),
                        email: $('EMAIL', this).text()
                    };
                }).get();
                if (data.length > 0) {
                    $('#HRSpecialist').html('');
                    $('#HRSpecialist').append('<option value="">Select one</option>');
                    data.forEach(function (value) {
                        $('#HRSpecialist').append('<option value="' + value.memberid + '">' + value.name + ' (' + value.email + ')</option>');
                    });
                }
            }
        });
    },
    getGrades: function (selectedItem) {
        $.ajax({
            url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchGrade.do?searchString=' + selectedItem,
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        value: '',
                        grade: $('GRADE', this).text()
                    };
                }).get();
                if (data.length > 0) {
                    $('#grade').append('<option value="">Select all that apply</option>');
                    data.forEach(function (value) {
                        $('#grade').append('<option value="' + value.grade + '">' + value.grade + '</option>');
                    });
                }
            }
        });
    },
    setReportToAutoComplete: function () {
        $('#reportTo').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchUser.do',
                    data: {searchString: $('#reportTo').val()},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: '',
                                memberid: $('MEMBERID', this).text(),
                                name: $('NAME', this).text(),
                                email: $('EMAIL', this).text(),
                                positionTitle: $('JOBTITLENAME', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var val = ui.item.name + ', ' + ui.item.positionTitle + ' (' + ui.item.email + ')';
                $('#reportTo').val(val);
                FormState.doAction(StateAction.changeText('reportTo', val), false);
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
        .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>' + HHS_TAB1.boldSearchText(item.name, this.term) + ', ' + item.positionTitle + ' (' + item.email + ') </a>')
                .appendTo(ul);
        };
    },
    setWhoToContactAutoComplete: function (fieldID) {
        $('#' + fieldID).autocomplete({
            source: function (request, response) {//http://ihs.bizflow.com/bizflowwebmaker/ihs_AutoCompleteService/SearchManager.do?searchString=hu
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchManager.do?searchString=' + $('#' + fieldID).val(),
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: '',
                                memberid: $('MEMBERID', this).text(),
                                name: $('NAME', this).text(),
                                email: $('EMAIL', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                $('#initiatorName').text(ui.item.name);
                $('#whoToContact').val(ui.item.name);
                $('#managerID').val(ui.item.memberid);
                if (fieldID === 'reportTo') {
                    $('#reportTo').val(ui.item.name);
                    FormState.doAction(StateAction.changeText('reportTo', ui.item.name), false);
                }
                FormState.doAction(StateAction.changeText('whoToContact', ui.item.name), false);
                FormState.doAction(StateAction.changeText('managerID', ui.item.memberid), false);
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>' + HHS_TAB1.boldSearchText(item.name, this.term) + '  (' + item.email + ') </a>')
                .appendTo(ul);
        };
    },
    setOccupationalSeriesAutoComplete: function () {
        $('#occupationalSeries').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchOccSeries.do?searchString=' + $('#occupationalSeries').val() + '&payPlan=' + $('#payPlan').val(),
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: '',
                                seriesCode: $('SERIES_CODE', this).text(),
                                description: $('DESCRIPTION', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var series = $('#series').val();
                if (series.indexOf(ui.item.seriesCode) == -1) {
                    if ('' == series) {
                        series = ui.item.seriesCode + ' ' + ui.item.description;
                    } else {
                        series = series + ',' + ui.item.seriesCode + ' ' + ui.item.description;
                    }
                    $('#series').val(series);
                    FormState.doAction(StateAction.changeText('series', series), false);
                    HHS_TAB1.populateFields([ui.item.seriesCode + ' ' + ui.item.description], 'series', 'selectedOccSeries', ',');
                }
                $('#occupationalSeries').val('');
                FormState.doAction(StateAction.changeText('occupationalSeries', ''), false);
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>' + HHS_TAB1.boldSearchText(item.seriesCode, this.term) + ' ' + item.description + '</a>')
                .appendTo(ul);
        };
    },
    setDutyLocationAutoComplete: function () {
        $('#dutyStation').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchDutyStation.do?searchString=' + $('#dutyStation').val(),
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: '',
                                locCode: $('LOC_CODE', this).text(),
                                locCountry: $('LOC_COUNTRY', this).text(),
                                locState: $('LOC_STATE', this).text(),
                                locCity: $('LOC_CITY', this).text(),
                                locCounty: $('LOC_COUNTY', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 3,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var dl = $('#dutyLoc').val();
                if (dl.indexOf(ui.item.locCity) == -1) {
                    var dValue = ui.item.locCity + ', ' + ui.item.locState + ' ' + ui.item.locCode;
                    if ('' == dl) {
                        dl = dValue;
                    } else {
                        dl = dl + ';' + dValue;
                    }
                    $('#dutyLoc').val(dl);
                    FormState.doAction(StateAction.changeText('dutyLoc', dl), false);
                    HHS_TAB1.populateFields([dValue], 'dutyLoc', 'selectedDutyStations', ';');
                    $('#dutyStation').val('');
                    FormState.doAction(StateAction.changeText('dutyStation', ''), false);
                } //check for existence before adding value

            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>' + HHS_TAB1.boldSearchText(item.locCity, this.term) + ', ' + item.locState + ' ' + item.locCode + '</a>')
                .appendTo(ul);
        };
    },
    setEmployingOfficeLocationAutoComplete: function () {
        $('#empOfficeLoc').autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/SearchDutyStation.do?searchString=' + $('#empOfficeLoc').val(),
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $('record', xmlResponse).map(function () {
                            return {
                                value: '',
                                locCode: $('LOC_CODE', this).text(),
                                locCountry: $('LOC_COUNTRY', this).text(),
                                locState: $('LOC_STATE', this).text(),
                                locCity: $('LOC_CITY', this).text(),
                                locCounty: $('LOC_COUNTY', this).text()
                            };
                        }).get();
                        response(data);
                    }
                });
            },
            minLength: 3,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var dl = ui.item.locCity + ', ' + ui.item.locState;
                $('#empOfficeLoc').val(dl);
                FormState.doAction(StateAction.changeText('empOfficeLoc', dl), false);
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>' + HHS_TAB1.boldSearchText(item.locCity, this.term) + ', ' + item.locState + '</a>')
                .appendTo(ul);
        };
    },
    changeFlsaExempt: function (value, id) {
        var grades = $('#selectGrades').val(), tempGrades, searchvalue;
        if (grades.length >= 2) {
            tempGrades = grades.indexOf(',') ? grades.split(',') : grades;
            if (tempGrades.length > 0) {
                tempGrades.forEach(function (gradeValue, index) {
                    if (value.substr(0, 2) == gradeValue.substr(0, 2)) {
                        tempGrades[index] = value;	// value is in the form of grade:N or grade:Y. eg 01:Y or 01:N
                        searchvalue = value;
                    }
                });
                $('#selectGrades').val(tempGrades.join());
                FormState.doAction(StateAction.changeText('selectGrades', tempGrades.join()), false);

            }
        }
    },
    hideErrorMsg: function (value) {
        $('#' + value.substr(0, 2)).hide();
    },
    mirmDialog: null,
    loadMoreInformationRequest: function(){
        BFUtility.callPartialPage(null, '/ihsrec_position/loadMoreInformationRequest.do', 'WIH_information', 'moreInformationGroup');
    },
    checkAllReceivedDate: function(){
        if(IHS_REQUEST_MAIN.isClassificationActivity()) {
            // Disabling 'Send Email to Manager' and 'Return to HR Action Request'
            var hasEmpty = false;
            $('input.mirReceivedDate').each(function(){
                if($(this).val().length == 0){
                    hasEmpty = true;
                    return false;
                }
            });

            if(hasEmpty) {
                hyf.util.disableComponent('button_returnToHR');
                hyf.util.disableComponent('button_forward');
                $('#pv_requestStatus').val(Status_PendingMoreInformation);
				FormState.doAction(StateAction.changeText('pv_requestStatus', Status_PendingMoreInformation), false);
                $('#output_requestStatus').text(Status_PendingMoreInformation);
            }else{
                hyf.util.enableComponent('button_returnToHR');
                hyf.util.enableComponent('button_forward');
                $('#pv_requestStatus').val(Status_PendingClassification);
				FormState.doAction(StateAction.changeText('pv_requestStatus', Status_PendingClassification), false);
                $('#output_requestStatus').text(Status_PendingClassification);
            }
        }
    },
    initMoreInformationRequestHistory: function (){
        hyf.calendar.setRepeatDateConstraint('moreInformationRequest', 'RCV_DT', 'Minimum', 'MIN_RCV_DT', true);
        hyf.calendar.setRepeatDateConstraint('moreInformationRequest', 'RCV_DT', 'Maximum', 'Today');

        HHS_TAB1.checkAllReceivedDate();

        $('#moreInformationGroup input.mirReceivedDate').change(function(e){
            var fieldName = e.currentTarget.name;
            var newValue = e.target.value;
            if(newValue.length === 0 || hyf.validation.validateField(fieldName, true)){
                var requestId = $('#' + fieldName.substring(0, fieldName.indexOf('RCV_DT')) + 'REQUEST_ID').val();
                $.ajax({
                    url: '/bizflowwebmaker/ihs_AutoCompleteService/UpdateReceiveDate.do',
                    data: {reqId: requestId, dt: newValue},
                    dataType: 'xml',
                    cache: false,
                    success: function (xmlResponse) {
                        HHS_TAB1.checkAllReceivedDate();
                    }
                });
            }
        });

        $('#moreInformationGroup a.viewMoreInformationRequestMessage').click(function(e){
            e.preventDefault();
            var fieldName = e.currentTarget.name;
            var requestId = $('#' + fieldName.substring(0, fieldName.indexOf('viewMessage')) + 'REQUEST_ID').val();
            BFUtility.callPartialPage(null, '/ihsrec_position/loadMoreInformationRequestMessage.do?reqId='+requestId, null, 'more_info_req_popup_dialog_content');
            HHS_TAB1.mirmDialog = bootbox.dialog({
                title: 'Request Message',
                message: '<p><i class="fa fa-spin fa-spinner"></i>Loading...</p>',
                onEscape: true,
                buttons: [{
                    label: 'Close',
                    className: 'btn pull-right',
                    callback: function () {
                        $('#more_info_req_popup_dialog_content').hide();
                    }
                }]
            });
        });
    },
    callbackLoadMoreInformationRequestMessage: function(){
        $('#MIRM_EMAIL_BODY').attr("readonly","readonly").attr("wrap", "hard");
        HHS_TAB1.mirmDialog.find('.bootbox-body').html($('#more_info_req_popup_dialog_content').html());
    },
    escapeRegExp: function (str) {
        return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
    },
    boldSearchText: function(source, keywords){
        return source.replace(new RegExp( '('+ this.escapeRegExp(keywords)+')' , "gi"), '<b>$1</b>');
    }
};
