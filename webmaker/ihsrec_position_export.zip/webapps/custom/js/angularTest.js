/*(function(){
	'use strict'
	angular.module('TestApp',[])
		.controller('ctrlTest',function($scope) {
		$scope.date = 'Date';
		$scope.pwd = 'Test'
		$scope.addr = 'Test';
		$scope.state = 'Test';
		$scope.optionList = [{text:'Pendting',value : 'pending'},{text : 'Filled',value : 'filled'},{ text : 'Declined', value : 'declined'},{text : 'Re-Opened',value : 'reOpend'}];
	});
})();*/