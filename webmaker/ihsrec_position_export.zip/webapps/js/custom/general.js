var generalBind = function(){
    $('#SG_SO_ID').on('change',function(e){
        var titleOrg;
        $('#selecting_official_titleorg').val($(this).val())
        titleOrg = $('#selecting_official_titleorg option:selected').text().split('~');
        $('#SG_SO_TITLE').val('');
        $('#SG_SO_ORG').val('');
        $('#selecting_official_detail').html('');
        if(titleOrg.length > 1){
            $('#SG_SO_TITLE').val(titleOrg[0]);
            $('#SG_SO_ORG').val(titleOrg[1]);
            $('#selecting_official_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        }
    });
    $('#SG_XO_ID').on('change',function(e){
        var titleOrg;
        $('#executive_office_titleorg').val($(this).val())
        titleOrg = $('#executive_office_titleorg option:selected').text().split('~');
        $('#SG_XO_TITLE').val('');
        $('#SG_XO_ORG').val('');
        $('#executive_office_detail').html('');
        if(titleOrg.length > 1){
            $('#SG_XO_TITLE').val(titleOrg[0]);
            $('#SG_XO_ORG').val(titleOrg[1]);
            $('#executive_office_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        }
    });
    $('#SG_HRL_ID').on('change',function(e){
        var titleOrg;
        $('#hr_liaison_titleorg').val($(this).val())
        titleOrg = $('#hr_liaison_titleorg option:selected').text().split('~');
        $('#SG_HRL_TITLE').val('');
        $('#SG_HRL_ORG').val('');
        $('#hr_liaison_detail').html('');
        if(titleOrg.length > 1){
            $('#SG_HRL_TITLE').val(titleOrg[0]);
            $('#SG_HRL_ORG').val(titleOrg[1]);
            $('#hr_liaison_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        }
    });
    $('#staffSpecialist').on('change',function(e){
        $('#hr_staffing_specialist_titleorg').val($(this).val())
        $('#hr_staffing_specialist_detail').html($('#hr_staffing_specialist_titleorg option:selected').text());
    });
    $('#classSpecialist').on('change',function(e){
        $('#hr_classification_specialist_titleorg').val($(this).val())
        $('#hr_classification_specialist_detail').html($('#hr_classification_specialist_titleorg option:selected').text());
    });
    $('#requestTypeSel').on('change',function(e){
        var preselect = $('#classificationType').val();
        $('#classificationType').empty();
        $('#classification_type_parent').val($(this).val());
        $('#classification_type_parent :selected').each(function(){
            $('#classificationType').append($('#classification_type_data option[value="' + $(this).text() + '"]').clone());
        });
        if(preselect.length > 0){
             $('#classificationType').val(preselect);
        }
    });
	$('#selectOfficial').trigger('change');
	$('#execOfficer').trigger('change');
	$('#hrLiaison').trigger('change');
	$('#requestTypeSel').trigger('change');

};