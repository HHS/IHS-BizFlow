/* global hyf BFActivityOption BFUtility $ BFLog _ */
/* eslint no-unused-vars:0 */

// tabList: [{
//     id: "tab1",
//     targetUrl: "/HHS_MAIN/showTab1.do",
//     targetGroup: "partial_tab1",
//     name: "Tab 1",
//     loaded: false,
//     completed: false,
//     disabledHeader: false,
//     postEnableTab: function() {
//         $('#tab1 img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').show();
//     },
//     postDisableTab: function() {
//         $('#tab1 img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').hide();
//     },
//     postClearTabContents: function() {
//         //$('#RI_OA_APRV_ITEM').val('NA');
//     }
//     // onInit: function() {
//     //     $('#SG_RT_ID').on("change", function() {
//     //         HHS_MAIN.resetRequestType();
//     //     });
//     //     HHS_MAIN.resetRequestType();
//     // }
// }, {
//     id: "tab2",
//     targetUrl: "/HHS_MAIN/showTab2.do",
//     targetGroup: "partial_tab2",
//     name: "Tab 2",
//     loaded: false,
//     completed: false,
//     disabledHeader: false,
//     postEnableTab: function() {
//         $('#tab2 img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').show();
//     },
//     postDisableTab: function() {
//         $('#tab2 img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').hide();
//     },
//     postClearTabContents: function() {

//     },
//     validator: function() {return true;}
// }, {
//     id: "tab3",
//     targetUrl: "/HHS_COMMON/showAttachment.do",
//     targetGroup: "partial_tab3",
//     name: "Documents",
//     loaded: false,
//     completed: false,
//     disabledHeader: false
// }],

var TabManager = new function () {
    var tabList = []; // This will contain Tab options.
    var _tabIDList = []; // This will be used by ensureTabControlPropertyPopulated.
    var totalLoadedTabCount = 0;
    var _currentTab = '';
    var activeTabIDList = ['tab1','tab2','tab3','tab4','tab5','tab6','tab9'];
    var _loadFormFunction = null;

    var getAnchorID = function (tabID) {
        return 'tab_control_tab_' + tabID;
    };
    var getTabIDFromAnchorID = function (anchorID) {
        if (anchorID != null && anchorID.length > 0) {
            var lastIndex = anchorID.lastIndexOf('_');
            if (lastIndex >= 0) {
                return anchorID.substring(lastIndex + 1);
            }
        }
        return null;
    };
    var getTab = function (tabID) {
        var selectedTabs = tabList.filter(function (node, index) {
            return node.id === tabID;
        });
        var foundTab = null;
        if (selectedTabs.length === 1) {
            foundTab = selectedTabs[0];
        }
        return foundTab;
    };
    var loadTabFromAnchor = function (node) {
        var currentTabID = getSelectedTabID();
        var tabAnchorID = $(node).attr('id');
        var tabID = getTabIDFromAnchorID(tabAnchorID);
        var tab = getTab(tabID);

        if (tab.disabledHeader === false) {
            if (_.includes(activeTabIDList, tabID) || TabManager.isTabCompleted(currentTabID) === true) {
                loadTab(tabID);
            }
        }
        // Tab click on disabled tab should be ignored.
    };
    var loadTab = function (tabID) {
        var selectedTab = getTab(tabID)
        if (selectedTab != null) {
            if (selectedTab.loaded === false) {
                BFUtility.callPartialPage(null, selectedTab.targetUrl, 'system', selectedTab.targetGroup);
                selectedTab.loaded = true;
            }
        }
    };
    var showTabHeader = function (tabID) {
        if ($('#' + getAnchorID(tabID) + ':hidden').length > 0) {
            hyf.util.showComponent('tab_control_tab_' + tabID, null, null, null);
        }
    };
    var hideTabHeader = function (tabID) {
        if ($('#' + getAnchorID(tabID) + ':visible').length > 0) {
            hyf.util.hideComponent('tab_control_tab_' + tabID, null, null, null);
        }
    };
    var enableTab = function (tabID) {
        hyf.util.enableComponent(tabID);

        var selectedTab = getTab(tabID);
        if (typeof selectedTab.postEnableTab === 'function') {
            selectedTab.postEnableTab();
        }

        var disabledComponents = $('#' + tabID).find('input, select, textarea');
        $.each(disabledComponents, function (index, component) {
            var alwaysDisabled = $(component).attr('alwaysDisabled');
            var alwaysReadonly = $(component).attr('alwaysReadonly');
            var donotsubmit = $(component).attr('donotsubmit');

            if (donotsubmit === 'true') {
                $(component).attr('disabled', true);
            }
            if (alwaysDisabled === 'true') {
                $(component).attr('disabled', true);
            }
            if (alwaysReadonly === 'true') {
                $(component).prop('readonly', 'true');
            }
        });
    };

    var disableTab = function (tabID) {
        hyf.util.disableComponent(tabID);
        var selectedTab = getTab(tabID);
        if (typeof selectedTab.postDisableTab === 'function') {
            selectedTab.postDisableTab();
        }
    };

    var clearTabContent = function (tabID) {
        $.each($('#' + tabID + ' input.checkbox'), function (component) {
            var value = $(this).prop('checked');
            if (value === true) {
                $(this).prop('checked', false);
                $(this).trigger('change');
            }
        });
        $.each($('#' + tabID + ' input.textbox'), function (component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
            }
        });

        // For Outreach tab
        $.each($('#' + tabID + ' input[type=checkbox]'), function (component) {
            $(this).prop('checked', false);
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).trigger('change');
            }
        });

        $.each($('#' + tabID + ' select'), function (component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
                $(this).trigger('change');
            }
        });
        $.each($('#' + tabID + ' textarea'), function (component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
            }
        });

        var selectedTab = getTab(tabID);
        if (typeof selectedTab.postClearTabContents === 'function') {
            selectedTab.postClearTabContents();
        }
    };
    var enableTabHeader = function (tabID) {
        var tab = getTab(tabID);
        if (tab != null) {
            tab.disabledHeader = false;
            var anchorID = getAnchorID(tabID);
            $('#' + anchorID).removeClass('disabledTab');
            $('#' + anchorID).addClass('unselectedTab');
        } else {
            BFLog.log('DEBUG', 'TabManager.enableTabHeader - tabID is null');
        }
    };
    var disableTabHeader = function (tabID) {
        var tab = getTab(tabID);
        if (tab != null) {
            tab.disabledHeader = true;
            var anchorID = getAnchorID(tabID);
            $('#' + anchorID).removeClass('unselectedTab');
            $('#' + anchorID).addClass('disabledTab');
        } else {
            BFLog.log('DEBUG', 'TabManager.disableTabHeader - tabID is null');
        }
    };
    // var allPreviousTabCompleted = function (tabID) {
    //     for (var index = 0; index < tabList.length; index++) {
    //         if (tabList[index].id === tabID) {
    //             break;
    //         }
    //         if (tabList[index].completed === false) {
    //             return false;
    //         }
    //     }
    //     return true;
    // };
    var validateTab = function (tabID) {
        if (BFUtility.isReadOnly() === false) {
            var tabOption = getTab(tabID);
            var validationResult = hyf.validation.validateContainer(document.getElementById(tabID));
            var extraValidationResult = true;

            if (typeof tabOption.validator === 'function') {
                extraValidationResult = tabOption.validator();
            }
            return validationResult && extraValidationResult === true;
        } else {
            return true;
        }
    };

    // PETER - nextTabID is redeclared.. CHECK THIS
    var loadNextTab = function () {
        var currentTabID = getSelectedTabID();
        if (currentTabID != null) {
            var nextTabID = BFActivityOption.getNextTabID(currentTabID);
            if (nextTabID != null) {
                var currentTabOption = getTab(currentTabID);
                if ((typeof(currentTabOption.validationOnLoadNextTab) != 'undefined' && currentTabOption.validationOnLoadNextTab === false)) {
                    nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    enableTabHeader(nextTabID);
                    $('#' + getAnchorID(nextTabID)).click();
                }else{
                    if (validateTab(currentTabID) === true) {
                        nextTabID = BFActivityOption.getNextTabID(currentTabID);
                        while (nextTabID != null) {
                            enableTabHeader(nextTabID);
                            if (isTabCompleted(nextTabID) === true) {
                                nextTabID = BFActivityOption.getNextTabID(nextTabID);
                            } else {
                                break;
                            }
                        }
                        nextTabID = BFActivityOption.getNextTabID(currentTabID);
                        $('#' + getAnchorID(nextTabID)).click();
                    } else {
                        nextTabID = BFActivityOption.getNextTabID(currentTabID);
                        while (nextTabID != null) {
                            if (_.includes(activeTabIDList, nextTabID)) {
                                nextTabID = null; // All the tabs in the activeTabIDList should be at the end of tabs
                            } else {
                                disableTabHeader(nextTabID);
                                nextTabID = BFActivityOption.getNextTabID(nextTabID);
                            }
                        }
                    }
                }
            }
        }
    };
    var loadPreviousTab = function () {
        var currentTabID = getSelectedTabID();
        if (currentTabID != null) {
            var previousTabID = BFActivityOption.getPreviousTabID(currentTabID);
            while (previousTabID != null) {
                var tab = getTab(previousTabID);
                if (tab.disabledHeader === false) {
                    $('#' + getAnchorID(previousTabID)).click();
                    break;
                } else {
                    previousTabID = BFActivityOption.getPreviousTabID(previousTabID);
                }
            }
        }
    };
    var getSelectedTabID = function () {
        var currentTabs = $('#tab_control_container a.selectedTab');
        if (currentTabs.length > 0) {
            var tabAnchorID = currentTabs[0].attributes['id'].value;
            var tabID = getTabIDFromAnchorID(tabAnchorID);
            return tabID;
        }
        return null;
    };
    var isTabCompleted = function (tabID) {
        var tab = getTab(tabID);
        var container = document.getElementById(tabID);
        var fv = hyf.FMAction.getFormValidator();
        var errors = fv.checkContainer(container);

        if (errors.length > 0) {
            tab.completed = false;
        } else {
            tab.completed = true;
        }
        return tab.completed;
    };

    var disableTabBasedOnActivityName = function (tabID, activityName) {
        // Disable tab based on BFActivityOption
        var readonlyTabs = BFActivityOption.getReadOnlyTabList(activityName);
        if (readonlyTabs !== null && readonlyTabs.length > 0) {
            for (var index = 0; index < readonlyTabs.length; index++) {
                if (readonlyTabs[index] === tabID) {
                    disableTab(tabID);
                    break;
                }
            }
        }
    };

    // This function will be called after each tab is loaded.
    var initTabAfterLoad = function (totalTabCount, tabID, activityName) {
        disableTabBasedOnActivityName(tabID, activityName);

        var tab = getTab(tabID);
        if (tab.onInit != null) {
            tab.onInit();
        }

        tab.completed = isTabCompleted(tabID);

        totalLoadedTabCount += 1;
        if (totalLoadedTabCount === totalTabCount) {
            initTabsAfterAllTabLoaded();
        }
    };
    var resetTabs = function () {
        var activeTabID = getSelectedTabID();
        hyf.util.setFieldValue('tab_control', activeTabID);

        var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
        var leftTabNotCompleted = false;
        for (var index = 0; index < activeTabs.length; index++) {
            var currentTabCompleted = isTabCompleted(activeTabs[index]);
            // var previousTabCompleted = (index > 0) ? isTabCompleted(activeTabs[index - 1]) : true;

            if (index === 0) {
                enableTabHeader(activeTabs[index]);
                document.getElementById(getAnchorID(activeTabs[index])).className = 'selectedTab';
            } else {
                if (leftTabNotCompleted === true) {
                    if (_.includes(activeTabIDList, activeTabs[index])) {
                        enableTabHeader(activeTabs[index]);
                    } else {
                        disableTabHeader(activeTabs[index]);
                    }
                } else {
                    enableTabHeader(activeTabs[index]);
                }
            }
            if (currentTabCompleted === false) {
                leftTabNotCompleted = true;
            }
        }
    };
    // var enableTabsForModification = function() {
    //     BFLog.log('DEBUG', '##### TabManager.enableTabsForModification START #####');
    //     var activityName = BFActivityOption.getActivityName();
    //     var readonlyTabs = BFActivityOption.getReadOnlyTabList(activityName);
    //     readonlyTabs = [];

    //     var currentTabID = getSelectedTabID();
    //     enableATabForSubmission(currentTabID);
    //     BFUtility.disableComponents(["btnApproveClsSpc","btnCancelReq_3", "btnModifyWorksheet"]);

    //     $('#h_modifyRequested').val('true');
    // };
    // This function will be called after all tabs are loaded.
    var initTabsAfterAllTabLoaded = function () {
        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);

        if (typeof _loadFormFunction === 'function') {
            _loadFormFunction();
        }

        tabs.forEach(function (tab) {
            disableTabBasedOnActivityName(tab, activityName);
        });
        resetTabs();

        // keep the current tab selection
        var storedTabID = $('#h_currentTabID').val();
        if (storedTabID) {
            var tab = getTab(storedTabID);
            if (tab.disabledHeader === false) {
                tabChanger(storedTabID);
                // showHidePreNextButtons();

                $('#' + getAnchorID(storedTabID)).focus();
            }
            $('#currentTabId').val(''); // clear current tab for closing page
        }

        BFUtility.greyOutScreen(false);

        $(document).trigger('HHS_ALL_TAB_LOADED');
        BFLog.log('INFO', 'HHS_ALL_TAB_LOADED triggered.');
    };
    // This function should be called before loading tabs.
    // This function is to add TabManager.initTabAFterLoad function to each tabs so that inittabAFterLoad can be called.
    var initResponseHandler = function (totalTabCount) {
        if (window != null) {
            var activityName = BFActivityOption.getActivityName();
            tabList.forEach(function (tab) {
                window[tab.targetGroup + 'ManipulateResponse'] = function (content, flag) {
                    content = content + '<div><script type="text/javascript">function ' + tab.targetGroup +
                        '_processAfterLoad() {TabManager.initTabAfterLoad(' + totalTabCount + ',"' + tab.id + '","' + activityName + '" );};' +
                        'hyf.attachEventHandler(window, "onload",' + tab.targetGroup + '_processAfterLoad);</script></div>';
                    return content;
                }
            });
        } else {
            BFLog.log('DEBUG', 'HHS_COMMON - initResponseHandler - window is null.');
        }
    };
    // Sometimes webmaker loses _hyfCondDisplayIds property that affects tab behavior.
    // If it is not found, this property should be reinitialized to have the array of numbers from 0 to 8.
    var ensureTabControlPropertyPopulated = function () {
        try {
            var hyfCondDisplayIDs = $('#tab_control')[0]._hyfCondDisplayIds;
            if (!hyfCondDisplayIDs) {
                $('#tab_control')[0]._hyfCondDisplayIds = _tabIDList;
            } else {
                if (hyfCondDisplayIDs.length <= 0) {
                    $('#tab_control')[0]._hyfCondDisplayIds = _tabIDList;
                }
            }
        } catch (e) {
        }
    };

    // This function is called whenever webmaker tab is clicked.
    // WebMaker form has default tabChanger function and this is custom one.
    var tabChanger = function (value) {
        if (_currentTab === value) {
            return;
        };
        _currentTab = value;

        ensureTabControlPropertyPopulated();
        resetTabs();

        var currentTabID = getSelectedTabID();
        // var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
        if (isTabCompleted(currentTabID) === true) {
            hyf.util.setFieldValue('tab_control', value);
            tabList.forEach(function (tab) {
                if (tab.disabledHeader === false) {
                    document.getElementById(getAnchorID(tab.id)).className = 'unselectedTab';
                }
            });

            document.getElementById(getAnchorID(value)).className = 'selectedTab';
        } else {
            if (BFUtility.isReadOnly() === false) {
                var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                while (nextTabID != null) {
                    if (_.includes(activeTabIDList, nextTabID) === false) {
                        disableTabHeader(nextTabID);
                        nextTabID = BFActivityOption.getNextTabID(nextTabID);
                    } else {
                        hyf.util.setFieldValue('tab_control', value);
                        tabList.forEach(function (tab) {
                            if (tab.disabledHeader !== true) {
                                document.getElementById(getAnchorID(tab.id)).className = 'unselectedTab';
                            }
                        });
                        document.getElementById(getAnchorID(value)).className = 'selectedTab';
                        nextTabID = null;
                    }
                }
                // If destination tab is in left side
                if (value < currentTabID) {
                    hyf.util.setFieldValue('tab_control', value);
                    tabList.forEach(function (tab) {
                        if (tab.disabledHeader === false) {
                            document.getElementById(getAnchorID(tab.id)).className = 'unselectedTab';
                        }
                    });
                    document.getElementById(getAnchorID(value)).className = 'selectedTab';
                } else {
                    if (typeof event !== 'undefined' && event != null) {
                        event.preventDefault();
                    }
                }
            }
        }

        // Broadcast ON_TAB_CHANGE event.
        // Attachment controller in document tab is using this event to update mandatory document type list.
        $(document).trigger('ON_TAB_CHANGE');
        return false;
    };
    var originalTabChanger = null;
    var installCustomTabChanger = function () {
        if (window.tab_controlTabChange != null) {
            TabManager.originalTabChanger = window.tab_controlTabChange;
            window.tab_controlTabChange = function (value) {
                var tab = getTab(value);
                if (tab.disabledHeader === false) {
                    tabChanger(value);
                }
            }
        }
    };
    var setTabListOption = function (tabListOption) {
        if (tabListOption != null && tabListOption.length > 0) {
            tabList = tabListOption;
            tabList.forEach(function (tab, index) {
                _tabIDList.push(index);
            });
        } else {
            BFLog.log('DEBUG', 'Tab list is null or empty.')
        }
    };
    var initTab = function (tabListOption, loadFormFunction) {
        installCustomTabChanger();
        setTabListOption(tabListOption);
        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        initResponseHandler(tabList.length);

        _loadFormFunction = loadFormFunction;

        totalLoadedTabCount = 0;
        tabList.forEach(function (tab, index) {
            $('#' + getAnchorID(tab.id)).attr('tabindex', index + 1);
            if (index === 0) {
                hyf.util.setFieldValue('tab_control', tab.id);
            } else {
                // Enable document tab always
                if (_.includes(activeTabIDList, tab.id) === false) {
                    disableTabHeader(tab.id);
                }
            }
            setTimeout(loadTab(tab.id), 0);
        });

        var firstTab = true;
        // Hide Tabs
        tabList.forEach(function (item) {
            var showTab = false;
            for (var index = 0; index < tabs.length; index++) {
                if (tabs[index] === item.id) {
                    showTab = true;
                    break;
                }
            }

            if (showTab === false) {
                hideTabHeader(item.id);
            } else {
                showTabHeader(item.id);
                if (firstTab === true) {
                    firstTab = false;
                    document.getElementById(getAnchorID(item.id)).className = 'selectedTab';
                    if (item.id !== 'tab1') {
                        document.getElementById(getAnchorID('tab1')).className = 'unselectedTab';
                    }
                } else {
                    document.getElementById(getAnchorID(item.id)).className = 'unselectedTab';
                }
            }
        });

        $('.tabContainer a').off('click').click(function (e) {
            e.preventDefault();
            TabManager.loadTabFromAnchor(this);
        });
    };

    return {
        getAnchorID: getAnchorID,
        loadTabFromAnchor: loadTabFromAnchor,
        enableTabHeader: enableTabHeader,
        disableTabHeader: disableTabHeader,
        showTabHeader: showTabHeader,
        hideTabHeader: hideTabHeader,
        enableTab: enableTab,
        disableTab: disableTab,
        clearTabContent: clearTabContent,
        validateTab: validateTab,
        loadNextTab: loadNextTab,
        loadPreviousTab: loadPreviousTab,
        getSelectedTabID: getSelectedTabID,
        isTabCompleted: isTabCompleted,
        initTabAfterLoad: initTabAfterLoad,
        resetTabs: resetTabs,
        initTab: initTab,
        tabList: tabList
    }
}();
