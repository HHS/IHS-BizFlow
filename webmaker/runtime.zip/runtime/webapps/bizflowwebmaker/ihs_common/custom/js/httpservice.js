// this constructor function will be used main for backend calls
/*var httpService =function(){
	var httpGet = function(url,columns){//only url and columns will vary
			var records = [];
			$.ajax({
					url: url,
					dataType: 'xml',
					cache: false,	
					success: function (xmlResponse){
						var data = $('record', xmlResponse ).map(function(){
							var record = {};
							if(columns && Array.isArray(columns)){
								columns.forEach(function(value){
									record[value] = $(value, this ).text();
								});
							}
							return record;
						}).get();
						records = data;
					}
				});
	}
	return {get:httpGet};
}();