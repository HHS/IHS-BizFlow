var TRACK_TAB = {
    initialized: false,
    track_request_details: {},
    init: function () {
        TRACK_TAB.setJobNumberAutoComplete();
        $('#interface_approvalComments, #interface_remarks').prop('readonly','true');
        $('.positionNumberGroup, .announcementInfoGrid, .newHireInfoGrid, #USAStaffingCert, #USAStaffingNewHire .groupLabelBackground, #USAStaffingAnnouncement .groupLabelBackground').hide();
    },
    render: function () {
        if (!TRACK_TAB.initialized) {
            var job_codeNumber = FormState.getState('interface_job_requisitionNumber');
            if (job_codeNumber && job_codeNumber.dirty) {
                TRACK_TAB.getJobDetail(job_codeNumber.value);
            }
            hyf.util.hideComponent('re_ann_reason_group');
            TRACK_TAB.initialized = true;
        }
    },
    loadJobNumberDetails: function (request, response) {
        $.ajax({
            url: '/bizflowwebmaker/ihsrec_track/lookUpJobOpeningNumber.do',
            data: {searchString: $('#interface_job_requisitionNumber').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        JOB_OPEN_NUMBER: $('HRS_JOB_OPENING_ID', this).text()
                    };
                }).get();
                response(data);
            }
        });
    },
    setJobNumberAutoComplete: function () {
        $('#interface_job_requisitionNumber').autocomplete({
            source: function (request, response) {
                TRACK_TAB.loadJobNumberDetails(request, response);
            },
            minLength: 1,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var dl = ui.item.JOB_OPEN_NUMBER;
                $('#interface_job_requisitionNumber').val(dl);
                $('.positionNumberGroup, .announcementInfoGrid, .newHireInfoGrid, #USAStaffingNewHire .groupLabelBackground, #USAStaffingAnnouncement .groupLabelBackground').hide();
                TRACK_TAB.getJobDetail(dl);
                FormState.doAction(StateAction.changeText('interface_job_requisitionNumber', dl), false);
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>' + item.JOB_OPEN_NUMBER + '</a>')
                .appendTo(ul);
        };
    }
    ,
    populatePageData: function (inputData) {
        if (inputData && Array.isArray(inputData) && inputData.length > 0) {
            $('#pv_ehrpStatus').val(inputData[0].STATUS_CODE);
			FormState.doActionNoRender(StateAction.changeText('pv_ehrpStatus', inputData[0].STATUS_CODE));			
            $('#interface_adminCode_desc').text(inputData[0].ADMIN_CODE);
            $('#interface_approverName').text(inputData[0].APPROVER_NAME);
            $('#interface_authorizeDate').text(inputData[0].AUTHORIZATION_DATE);
            $('#interface_number_of_vacancies').text(inputData[0].NUMBER_OF_VACANCIES);
            $('#can_numb').text(inputData[0].CAN);

            var remarks = inputData[0].REMARKS;
            if(0<remarks.length){
                $('#interface_remarks').val(remarks);
            }else{
                $('#interface_remarks').hide();
            }

            var s = inputData[0].APPROVAL_COMMENTS;
            var startTagName = '<CommentBody>';
            var endTagName = '</CommentBody>';
            var p = s.indexOf(startTagName);
            if(-1<p){
                s = s.substring(p+startTagName.length);
                p = s.indexOf(endTagName);
                if(-1<p){
                    s = s.substring(0, p);
                }
            }
            if(0<s.length){
                $('#interface_approvalComments').val(s);
            }else{
                $('#interface_approvalComments').hide();
            }
        }
    },
    populateCertificateTable: function (cellObjArray) {
        if (cellObjArray && Array.isArray(cellObjArray)) {
            $('#USAStaffingCert').show();
            $('#interface_certificatesTbody').html('');
            if (cellObjArray.length > 0) {
                $('#certificate_grid').show();
                $('#certificate_grid_label').html("<span class='greyColor'>USA Staffing Certificate Information Last Updated</span> " + cellObjArray[0].LAST_UPDATE_DATE);
                cellObjArray.forEach(function (el, index) {
                    var row = '<tr>'
                        + '<td>' + cellObjArray[index].REQUEST_NUMBER + '</td>'
                        + '<td>' + cellObjArray[index].CERTIFICATE_NUMBER + '</td>'
                        + '<td>' + cellObjArray[index].ISSUE_DATE + '</td>'
                        + '<td>' + cellObjArray[index].REVIEW_DUE_DATE + '</td>'
                        + '<td>' + cellObjArray[index].REVIEW_RETURN_DATE + '</td>'
                        + '<td>' + cellObjArray[index].ANNOUNCEMENT_NUMBER + '</td>'
                        + '</tr>';
                    $('#interface_certificatesTbody').append(row);
                });
            }else{
                $('#certificate_grid').hide();
                $('#certificate_grid_label').html("<span class='greyColor'>No Data Found</span>");
            }
        }
    },
    populateOpeningLocations: function (cellObjArray) {
        if (cellObjArray && Array.isArray(cellObjArray) && 0<cellObjArray.length) {
            $('#interface_openingLocation_container').html('<div><table id="interface_openingLocationTable" class="table"><thead><tr>' +
                '<th></th><th>Geo Location Code</th><th>Description</th></tr></thead>' +
                '<tbody id="interface_openingLocationTbody" />' +
                '</table></div>');
            var count = cellObjArray.length;
            cellObjArray.forEach(function (el, index) {
                var description = cellObjArray[index].DESCR;
                if(0<$.trim(cellObjArray[index].STATE).length){
                    description += ', ' + cellObjArray[index].STATE;
                }
                if(0<$.trim(cellObjArray[index].COUNTRY) && cellObjArray[index].COUNTRY !== 'USA'){
                    description += ', ' + cellObjArray[index].COUNTRY;
                }
                var row = '<tr><td>' + (1<count && cellObjArray[index].PRIMARY==='Y'?'Primary':'') + '</td>'
                    + '<td>' + cellObjArray[index].LOCATION + '</td>'
                    + '<td>' + description + '</td>'
                    + '</tr>';
                $('#interface_openingLocationTbody').append(row);
            });
        }
    },
    populateNewHire: function (cellObjArray) {
        if (cellObjArray && Array.isArray(cellObjArray)) {
            if (cellObjArray.length > 0) {
                cellObjArray.forEach(function (el, index) {
                    var count = index + 1;
                    $('#newHireName_' + count).text(cellObjArray[index].NEW_HIRE_NAME);
                    $('#interface_positionTitle_' + count).text(cellObjArray[index].POSITION_TITLE);
                    $('#interface_dutyLoc_' + count).text(cellObjArray[index].DUTY_LOCATION);
                    $('#interface_sendOffer_' + count).text(cellObjArray[index].SEND_OFFR_DATE);
                    $('#interface_effectiveDate_' + count).text(cellObjArray[index].EFFECTIVE_DATE);
                    $('#interface_newHireNo_' + count).text(cellObjArray[index].NEW_HIRE_NUMBER);
                    $('#interface_pplanSeries_grade_' + count).text(cellObjArray[index].PAYPLAN_SERIES_GRADE);
                    $('#newhire_'+count+'_label').html("<span class='greyColor'>USA Staffing New Hire Information Last Updated</span> " + cellObjArray[index].LAST_UPDATE_DATE);
                    $('#newhire_'+count+'_label_container').show();
                    hyf.util.showComponent('newhire_'+count);
                });
            }else{
                $('#newhire_1_label_container').show();
                $('#newhire_1_label').html("<span class='greyColor'>No Data Found</span>");
            }
        }
    },
    populateAnnouncement: function (cellObjArray) {
        if (cellObjArray && Array.isArray(cellObjArray)) {
            if (cellObjArray.length > 0) {
                cellObjArray.forEach(function (el, index) {
                    var count = index + 1;
                    $('#interface_req_number_'+count).text(cellObjArray[index].REQUEST_NUMBER);
                    $('#interface_ann_status_'+count).text(cellObjArray[index].ANNOUNCEMENT_STATUS);
                    $('#interface_usajobsJobTitle_'+count).text(cellObjArray[index].JOB_TITLE);
                    $('#interface_psg_'+count).text(cellObjArray[index].PSG);
                    $('#interface_vacancyType_'+count).text(cellObjArray[index].VACANCY_TYPE);
                    $('#interface_annNumber_'+count).text(cellObjArray[index].ANNOUNCEMENT_NUMBER);
                    $('#interface_DAYS_REVIEW_JOA_'+count).text(cellObjArray[index].DAYS_REVIEW_JOA);
                    $('#interface_annDate_'+count).text(cellObjArray[index].OPEN_DATE);
                    $('#interface_announceCloseDate_'+count).text(cellObjArray[index].CLOSE_DATE);
                    $('#interface_annType_'+count).text(cellObjArray[index].ANNOUNCEMENT_TYPE);
                    TRACK_TAB.populateAnnouncementLocations(count, cellObjArray[index].LOCATION);
                    $('#announcement_grid_'+count+'_label').html("<span class='greyColor'>USA Staffing Announcement Information Last Updated</span> " + cellObjArray[index].LAST_UPDATE_DATE);
                    $('#interface_usajobsLink_'+count).prop('href', cellObjArray[index].USAJOBSLINK).text(cellObjArray[index].USAJOBSLINK);
                    $('#announcement_grid_'+count+'_label_container').show();
                    hyf.util.showComponent('announcement_grid_' + count);
                });
            }else{
                $('#announcement_grid_1_label_container').show();
                $('#announcement_grid_1_label').html("<span class='greyColor'>No Data Found</span>");
            }
        }
    },
    populateAnnouncementPSG: function (psgs) {
        if (typeof psgs !== 'undefined') {
            psgs = psgs.replace(/;/g, '<br>');
            $('#interface_psg').html(psgs);
        }
    },
    populateAnnouncementLocations: function (index, locations) {
        if (typeof locations !== 'undefined') {
            locations = locations.replace(/;/g, '<br>');
            $('#interface_location_' + index).html(locations);
        }
    },
    populatePositions2: function (cellObjArray) {
        var id = 1;
        $('#interface_postingTitle').text(cellObjArray[0].POSTING_TITLE);
        cellObjArray.forEach(function (el, index) {
            if (index < 5) {
                hyf.util.showComponent('positionNumberGroup_' + id);
                $('#interface_positionNumber_' + id).text(el.POSITION_NBR);
                $('#interface_postingTitle_' + id).text(el.POSTING_TITLE);
                $('#interface_jobCode_' + id).text(el.JOBCODE);
                // todo: set primary
                //el.PRIMARY
                id++;
            }
        });
    },
    populatePositions: function (cellObjArray) {
        if (cellObjArray && Array.isArray(cellObjArray) && 0<cellObjArray.length) {
            $('#interface_positionsTbody').html('');
            cellObjArray.forEach(function (el, index) {
                var row = '<tr><td>' + cellObjArray[index].POSITION_NBR + '</td>'
                    + '<td>' + cellObjArray[index].POSTING_TITLE + '</td>'
                    + '<td>' + cellObjArray[index].JOBCODE + '</td>'
                    + '</tr>';
                $('#interface_positionsTbody').append(row);
            });
        }
    },
    getOpeningLocations: function (jobOpeningNumber) {
        $.ajax({
            url: '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do',
            data: {loc: jobOpeningNumber},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return TRACK_TAB.toObject(this);
                }).get();
                TRACK_TAB.populateOpeningLocations(data);
            }
        });
    },
    getCertificates: function () {
        $.ajax({
            url: '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do',
            data: {cert: $('#h_procid').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return TRACK_TAB.toObject(this);
                }).get();
                TRACK_TAB.populateCertificateTable(data);
            }
        });
    },


    getNewHire: function () {
        $.ajax({
            url: '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do',
            data: {newHire: $('#h_procid').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return TRACK_TAB.toObject(this);
                }).get();
                TRACK_TAB.populateNewHire(data);
            }
        });

    },
    getAnnouncement: function () {
        $.ajax({
            url: '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do',
            data: {ann: $('#h_procid').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return TRACK_TAB.toObject(this);
                }).get();
                TRACK_TAB.populateAnnouncement(data);
            }
        });
    },
    getJobDetail: function (number) {
        var url = '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do?jobId=';
        if (number != undefined) {
            url += number;
        }
        $.ajax({
            url: url,
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return TRACK_TAB.toObject(this);
                }).get();
                if (data.length > 0) {
                    var jobOpeningNumber = $('#interface_job_requisitionNumber').val();
                    TRACK_TAB.populatePageData(data);
                    TRACK_TAB.getPosDetail(jobOpeningNumber);
                    TRACK_TAB.getOpeningLocations(jobOpeningNumber);
                    TRACK_TAB.getAnnouncement();
                    TRACK_TAB.getCertificates();
                    TRACK_TAB.getNewHire();
                } else {
                    bootbox.alert('No record matched the Job Opening number entered. Please try again.');
                }

            }
        });
    },
    getPosDetail: function (number) {
        var url = '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do?pos=';
        if (number != undefined) {
            url += number;
        }
        $.ajax({
            url: url,
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return TRACK_TAB.toObject(this);
                }).get();
                if (data.length > 0) {
                    TRACK_TAB.populatePositions(data);

                }

            }
        });
    },

    toObject: function (e) {
        var obj = {};
        $.each($(e).children(), function (i, v) {
            obj[v.tagName] = $(v).text();
        });
        return obj;
    }
};