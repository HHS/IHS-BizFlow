var TRACK_REQ_TAB = {
    initialized: false,
    init: function () {        
    },
    render: function () {
        TRACK_REQ_TAB.initialized = true;
    }
};